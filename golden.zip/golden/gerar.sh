#!/usr/bin/env bash
# GENERADOR DE KEYS - GOLDEN SYSTEM PRO
# REV26: UI moderna + paquete rápido opcional, conservando fallback estable 43/43.
# UI adaptativa y compatibilidad Bash 4+ para Ubuntu/Debian antiguos y modernos.

set -u
shopt -s extglob nullglob
umask 077

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

SCPT_DIR="${GOLDEN_SCRIPT_DIR:-/etc/SCRIPT}"
KEY_ROOT="${GOLDEN_KEY_DIR:-/etc/http-shell}"
LIST_NAME="${GOLDEN_LIST_NAME:-orp-nedlog}"
TOOL_LIST_NAME="${GOLDEN_TOOL_LIST_NAME:-lista-arq}"
HTTP_PORT="${GOLDEN_HTTP_PORT:-8888}"
COUNTER_FILE="${GOLDEN_COUNTER_FILE:-/etc/http-instas}"
LAST_FIXED_FILE="/etc/key-gerador"
ACCESS_LOG="/etc/gerar-sh-log"
REPO_DEFAULT="https://raw.githubusercontent.com/satanas66666/golden-system2/main"
BUNDLE_NAME="golden-bundle.tgz"
BUNDLE_META="golden-bundle.meta"

BASICINST=(
  menu PGet.py ports.sh badvpn.sh ADMbot.sh message.txt usercodes websocket.sh
  POpen.py PPriv.py PPub.py PDirect.py speedtest.py speed.sh utils.sh
  dropbear.sh apacheon.sh openvpn.sh shadowsocks.sh ssl.sh squid.sh dados.sh
  Crear-Demo.sh squidpass.sh htop.sh gestor.sh proxygo.sh
  cambiarpass.sh Proxy-Publico.py Proxy-Privado.py haproxy.sh hysteria.sh
  hora.sh panelweb.sh optimizar.sh v2ray.sh passvulrt.sh nload.sh bbr.sh
  ban_iptables.sh slowdns.sh proxy_manager.sh compat.sh
)

C_RESET=$'\033[0m'
C_DIM=$'\033[2m'
C_BOLD=$'\033[1m'
C_RED=$'\033[1;31m'
C_GREEN=$'\033[1;32m'
C_YELLOW=$'\033[1;33m'
C_BLUE=$'\033[1;34m'
C_MAGENTA=$'\033[1;35m'
C_CYAN=$'\033[1;36m'

require_root() {
    if [[ "$(id -u)" -ne 0 ]]; then
        echo "ERROR: ejecuta este comando como root." >&2
        exit 1
    fi
}

init_dirs() {
    mkdir -p "$SCPT_DIR" "$KEY_ROOT" /etc/newadm/ger-user /etc/ger-frm /etc/ger-inst /etc/nanotxz
    [[ -f "$COUNTER_FILE" ]] || printf '0\n' >"$COUNTER_FILE"
    touch "$ACCESS_LOG"
    chmod 700 "$SCPT_DIR" "$KEY_ROOT" 2>/dev/null || true
    chmod 600 "$COUNTER_FILE" "$ACCESS_LOG" 2>/dev/null || true
}

supports_color() {
    [[ -t 1 ]] || return 1
    [[ "${TERM:-}" != "dumb" ]]
}

term_cols() {
    local c
    c=$(tput cols 2>/dev/null || true)
    [[ "$c" =~ ^[0-9]+$ ]] || c=80
    (( c < 60 )) && c=60
    (( c > 140 )) && c=140
    printf '%s' "$c"
}

repeat_char() {
    local count="$1" char="$2" out=""
    while (( count > 0 )); do out+="$char"; count=$((count - 1)); done
    printf '%s' "$out"
}

hr() {
    local cols="${1:-$(term_cols)}"
    printf '%s\n' "$(repeat_char "$cols" '=')"
}

box_line() {
    local text="$1" cols="${2:-$(term_cols)}"
    local clean pad
    clean=$(strip_ansi "$text")
    (( ${#clean} > cols-4 )) && text="$(fit_text "$text" $((cols-4)))"
    clean=$(strip_ansi "$text")
    pad=$(( cols - 4 - ${#clean} ))
    (( pad < 0 )) && pad=0
    printf '%b\n' "| $text$(repeat_char "$pad" ' ') |"
}

strip_ansi() {
    printf '%s' "$1" | sed -r 's/\x1B\[[0-9;]*[A-Za-z]//g'
}

fit_text() {
    local text="$1" width="$2"
    local clean
    clean=$(strip_ansi "$text")
    (( width < 4 )) && width=4
    if (( ${#clean} <= width )); then
        printf '%s' "$text"
    else
        printf '%s...' "${clean:0:$((width-3))}"
    fi
}

status_badge() {
    case "$1" in
        ONLINE|ACTIVA|OK) printf '%b' "${C_GREEN}$1${C_RESET}" ;;
        OFF|ERROR|INVALIDA) printf '%b' "${C_RED}$1${C_RESET}" ;;
        USADA*) printf '%b' "${C_YELLOW}$1${C_RESET}" ;;
        *) printf '%s' "$1" ;;
    esac
}

pause_back() {
    echo
    read -r -p "Presiona Enter para volver al menú..." _
}

is_ipv4() {
    local ip="$1" IFS=. octets octet
    [[ "$ip" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] || return 1
    read -r -a octets <<<"$ip"
    for octet in "${octets[@]}"; do
        (( 10#$octet >= 0 && 10#$octet <= 255 )) || return 1
    done
}

is_ipv6() {
    local ip="$1" rest colons group
    local -a groups=()
    [[ -n "$ip" && "$ip" =~ ^[0-9A-Fa-f:]+$ ]] || return 1
    [[ "$ip" != *:::* ]] || return 1
    [[ "$ip" != :* || "$ip" == ::* ]] || return 1
    [[ "$ip" != *: || "$ip" == *:: ]] || return 1

    colons="${ip//[^:]/}"
    if [[ "$ip" == *::* ]]; then
        rest="${ip#*::}"
        [[ "$rest" != *::* ]] || return 1
        (( ${#colons} >= 2 && ${#colons} <= 7 )) || return 1
    else
        (( ${#colons} == 7 )) || return 1
    fi

    IFS=: read -r -a groups <<<"$ip"
    for group in "${groups[@]}"; do
        [[ -z "$group" || ( ${#group} -ge 1 && ${#group} -le 4 && "$group" =~ ^[0-9A-Fa-f]+$ ) ]] || return 1
    done
}

valid_ip() {
    is_ipv4 "$1" || is_ipv6 "$1"
}

local_ip() {
    local ip=""
    ip=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
    [[ -n "$ip" ]] || ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    printf '%s' "$ip"
}

public_ip() {
    local ip=""
    if command -v curl >/dev/null 2>&1; then
        ip=$(curl -4fsS --connect-timeout 3 --max-time 6 https://api.ipify.org 2>/dev/null || true)
        [[ -n "$ip" ]] || ip=$(curl -4fsS --connect-timeout 3 --max-time 6 https://ipv4.icanhazip.com 2>/dev/null || true)
    elif command -v wget >/dev/null 2>&1; then
        ip=$(timeout 7 wget -qO- https://ipv4.icanhazip.com 2>/dev/null || true)
    fi
    ip="${ip//$'\r'/}"
    ip="${ip//$'\n'/}"
    valid_ip "$ip" || ip=$(local_ip)
    printf '%s' "$ip"
}

server_ip() {
    if [[ -n "${GOLDEN_SERVER_IP:-}" ]] && valid_ip "$GOLDEN_SERVER_IP"; then
        printf '%s' "$GOLDEN_SERVER_IP"
        return
    fi
    if [[ -s /etc/MEUIPADM ]]; then
        local saved
        saved=$(tr -d '\r\n ' </etc/MEUIPADM)
        if valid_ip "$saved"; then
            printf '%s' "$saved"
            return
        fi
    fi
    public_ip
}

ofus() {
    local input="$1" out="" ch i
    for ((i=0; i<${#input}; i++)); do
        ch="${input:i:1}"
        case "$ch" in
            ".") ch="+" ;;
            "+") ch="." ;;
            "1") ch="@" ;;
            "@") ch="1" ;;
            "2") ch="?" ;;
            "?") ch="2" ;;
            "3") ch="%" ;;
            "%") ch="3" ;;
            "/") ch="K" ;;
            "K") ch="/" ;;
        esac
        out+="$ch"
    done
    printf '%s' "$out" | rev
}

is_basic_file() {
    local name="$1" f
    for f in "${BASICINST[@]}"; do
        [[ "$f" == "$name" ]] && return 0
    done
    return 1
}

new_key_id() {
    local key
    while :; do
        if command -v openssl >/dev/null 2>&1; then
            key=$(openssl rand -hex 8 2>/dev/null || true)
        else
            key="$(date +%s)$RANDOM$RANDOM"
            key=$(printf '%s' "$key" | sha256sum | cut -c1-16)
        fi
        [[ "$key" =~ ^[A-Za-z0-9._-]+$ ]] || continue
        [[ ! -e "$KEY_ROOT/$key" ]] && {
            printf '%s' "$key"
            return
        }
    done
}

copy_to_key() {
    local key_dir="$1" list_file="$2" name="$3"
    if [[ ! -f "$SCPT_DIR/$name" ]]; then
        echo -e "${C_YELLOW}AVISO: falta $name; se omitió.${C_RESET}"
        return 1
    fi
    cp -f -- "$SCPT_DIR/$name" "$key_dir/$name" || return 1
    chmod 0755 "$key_dir/$name" 2>/dev/null || true
    printf '%s\n' "$name" >>"$list_file"
    return 0
}

extra_files() {
    local p name
    for p in "$SCPT_DIR"/*; do
        [[ -f "$p" ]] || continue
        name="${p##*/}"
        is_basic_file "$name" && continue
        printf '%s\n' "$name"
    done | LC_ALL=C sort
}


create_fast_bundle() {
    local key_dir="$1" list_file="$2" bundle meta hash size count
    local -a files=()

    bundle="$key_dir/$BUNDLE_NAME"
    meta="$key_dir/$BUNDLE_META"
    rm -f -- "$bundle" "$meta"

    command -v tar >/dev/null 2>&1 || return 1
    command -v sha256sum >/dev/null 2>&1 || return 1

    while IFS= read -r name || [[ -n "$name" ]]; do
        [[ -n "$name" ]] || continue
        [[ "$name" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$ && "$name" != "." && "$name" != ".." ]] || return 1
        [[ -f "$key_dir/$name" && ! -L "$key_dir/$name" ]] || return 1
        files+=("$name")
    done <"$list_file"

    ((${#files[@]} > 0)) || return 1

    # Un único paquete reduce 43 conexiones HTTP a una. Si algo falla, el
    # instalador conserva el flujo individual REV26 sin cambios.
    tar -czf "$bundle.tmp" -C "$key_dir" -- "${files[@]}" 2>/dev/null || {
        rm -f -- "$bundle.tmp"
        return 1
    }
    mv -f -- "$bundle.tmp" "$bundle"
    chmod 0600 "$bundle"

    hash=$(sha256sum "$bundle" | awk '{print $1}')
    size=$(wc -c <"$bundle" | tr -d ' ')
    count=${#files[@]}
    [[ "$hash" =~ ^[0-9a-fA-F]{64}$ && "$size" =~ ^[0-9]+$ ]] || {
        rm -f -- "$bundle"
        return 1
    }

    {
        printf 'sha256=%s\n' "$hash"
        printf 'size=%s\n' "$size"
        printf 'count=%s\n' "$count"
    } >"$meta"
    chmod 0600 "$meta"
    return 0
}

create_key() {
    local key key_dir list_file list_name choice owner fixed_answer fixed_ip="" ip decoded encoded cols
    local -a extras=() selected=()
    local idx token name copied=0

    key=$(new_key_id)
    key_dir="$KEY_ROOT/$key"
    mkdir -p "$key_dir"
    mapfile -t extras < <(extra_files)
    cols=$(term_cols)

    clear 2>/dev/null || true
    hr "$cols"
    box_line "${C_BOLD}${C_CYAN}GENERAR NUEVA KEY${C_RESET}" "$cols"
    hr "$cols"
    if ((${#extras[@]})); then
        box_line "Herramientas adicionales disponibles:" "$cols"
        idx=1
        for name in "${extras[@]}"; do
            printf '[%d] %s\n' "$idx" "$name"
            idx=$((idx + 1))
        done
    else
        box_line "No hay herramientas adicionales." "$cols"
    fi
    echo "[x] Todas las herramientas adicionales"
    echo "[b] Instalación completa Golden ADM PRO"
    hr "$cols"

    read -r -p "Escoge [b/x/números separados por espacio] (b): " choice
    choice="${choice:-b}"
    read -r -p "Nombre de usuario (unnamed): " owner
    owner="${owner:-unnamed}"
    owner="${owner//$'\n'/ }"
    owner="${owner//$'\r'/ }"

    if [[ "$choice" == @(b|B) ]]; then
        list_name="$LIST_NAME"
    else
        list_name="$TOOL_LIST_NAME"
    fi
    list_file="$key_dir/$list_name"
    : >"$list_file"

    read -r -p "¿Key fija por IP? [S/N] (N): " fixed_answer
    fixed_answer="${fixed_answer:-n}"
    if [[ "$fixed_answer" == @(s|S|y|Y) ]]; then
        while :; do
            read -r -p "IP fija autorizada: " fixed_ip
            fixed_ip="${fixed_ip//[[:space:]]/}"
            valid_ip "$fixed_ip" && break
            echo -e "${C_RED}IP inválida. Intenta nuevamente.${C_RESET}"
        done
        printf '%s\n' "$fixed_ip" >"$key_dir/keyfixa"
        owner+=" [FIXA]"
    fi

    case "$choice" in
        b|B)
            for name in "${BASICINST[@]}"; do
                copy_to_key "$key_dir" "$list_file" "$name" && copied=$((copied + 1))
            done
            printf 'INSTALL\n' >"$key_dir/.type"
            ;;
        x|X)
            for name in "${extras[@]}"; do
                copy_to_key "$key_dir" "$list_file" "$name" && copied=$((copied + 1))
            done
            printf 'TOOL\n' >"$key_dir/.type"
            touch "$key_dir/HERRAMIENTA" "$key_dir/FERRAMENTA"
            ;;
        *)
            local -a choice_tokens=()
            IFS=$' \t' read -r -a choice_tokens <<<"$choice"
            for token in "${choice_tokens[@]}"; do
                [[ "$token" =~ ^[0-9]+$ ]] || continue
                (( token >= 1 && token <= ${#extras[@]} )) || continue
                name="${extras[token-1]}"
                selected+=("$name")
            done
            if ((${#selected[@]} == 0)); then
                echo -e "${C_RED}No se seleccionó ningún archivo válido.${C_RESET}"
                rm -rf -- "$key_dir"
                return 1
            fi
            for name in "${selected[@]}"; do
                copy_to_key "$key_dir" "$list_file" "$name" && copied=$((copied + 1))
            done
            printf 'TOOL\n' >"$key_dir/.type"
            touch "$key_dir/HERRAMIENTA" "$key_dir/FERRAMENTA"
            ;;
    esac

    if (( copied == 0 )); then
        echo -e "${C_RED}No se pudo copiar ningún archivo. KEY cancelada.${C_RESET}"
        rm -rf -- "$key_dir"
        return 1
    fi

    printf '%s\n' "$owner" >"$KEY_ROOT/$key.name"
    printf '%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" >"$key_dir/.created"

    if create_fast_bundle "$key_dir" "$list_file"; then
        : >"$key_dir/.fast"
    else
        rm -f -- "$key_dir/.fast" "$key_dir/$BUNDLE_NAME" "$key_dir/$BUNDLE_META"
    fi

    ip=$(server_ip)
    if [[ -z "$ip" ]]; then
        echo -e "${C_RED}No se pudo detectar la IP del servidor.${C_RESET}"
        rm -rf -- "$key_dir" "$KEY_ROOT/$key.name"
        return 1
    fi

    if is_ipv6 "$ip"; then
        decoded="[$ip]:$HTTP_PORT/$key/$list_name"
    else
        decoded="$ip:$HTTP_PORT/$key/$list_name"
    fi
    encoded=$(ofus "$decoded")

    if [[ -n "$fixed_ip" ]]; then
        printf '%s\n' "$encoded" >"$LAST_FIXED_FILE"
        chmod 600 "$LAST_FIXED_FILE"
    fi

    hr "$cols"
    box_line "$(status_badge OK) Key activa y lista para instalación" "$cols"
    box_line "KEY: $(fit_text "$encoded" $((cols-10)))" "$cols"
    box_line "URL real: http://$(fit_text "$decoded" $((cols-16)))" "$cols"
    box_line "Archivos incluidos: $copied" "$cols"
    if [[ -f "$key_dir/$BUNDLE_NAME" ]]; then
        box_line "Modo rápido: LISTO (paquete único + SHA-256)" "$cols"
    else
        box_line "Modo rápido: no disponible; fallback individual activo" "$cols"
    fi
    [[ -n "$fixed_ip" ]] && box_line "IP fija: $fixed_ip" "$cols"
    hr "$cols"
}

collect_keys() {
    local d
    KEY_IDS=()
    for d in "$KEY_ROOT"/*; do
        [[ -d "$d" ]] || continue
        KEY_IDS+=("${d##*/}")
    done
    if ((${#KEY_IDS[@]})); then
        IFS=$'\n' KEY_IDS=($(printf '%s\n' "${KEY_IDS[@]}" | LC_ALL=C sort))
        unset IFS
    fi
}

key_state() {
    local key="$1"
    if [[ -s "$KEY_ROOT/$key/.used" ]]; then
        printf 'USADA %s' "$(cut -d'|' -f1 "$KEY_ROOT/$key/.used")"
    else
        printf 'ACTIVA'
    fi
}

key_owner() {
    cat "$KEY_ROOT/$1.name" 2>/dev/null || printf 'sin-nombre'
}

key_fixed() {
    cat "$KEY_ROOT/$1/keyfixa" 2>/dev/null || printf '-'
}

key_type() {
    cat "$KEY_ROOT/$1/.type" 2>/dev/null || printf '-'
}

key_created() {
    cat "$KEY_ROOT/$1/.created" 2>/dev/null || printf '-'
}

key_table() {
    local i=1 key cols compact
    collect_keys
    if ((${#KEY_IDS[@]} == 0)); then
        echo "No existen keys."
        return 1
    fi
    cols=$(term_cols)
    compact=0
    (( cols < 105 )) && compact=1

    if (( compact )); then
        for key in "${KEY_IDS[@]}"; do
            hr "$cols"
            printf '%b\n' "${C_BOLD}[${i}]${C_RESET} $(status_badge "$(key_state "$key")")"
            printf 'Key      : %s\n' "$key"
            printf 'Usuario  : %s\n' "$(key_owner "$key")"
            printf 'IP fija  : %s\n' "$(key_fixed "$key")"
            printf 'Tipo     : %s\n' "$(key_type "$key")"
            printf 'Creada   : %s\n' "$(key_created "$key")"
            i=$((i + 1))
        done
        hr "$cols"
    else
        local w_n=4 w_key=18 w_user=24 w_fixed=18 w_state=22
        printf "%-${w_n}s %-${w_key}s %-${w_user}s %-${w_fixed}s %-${w_state}s\n" \
            "N" "KEY" "USUARIO" "IP-FIJA" "ESTADO"
        hr "$cols"
        for key in "${KEY_IDS[@]}"; do
            printf "%-${w_n}s %-${w_key}s %-${w_user}.${w_user}s %-${w_fixed}.${w_fixed}s %-${w_state}.${w_state}s\n" \
                "$i" "$key" "$(key_owner "$key")" "$(key_fixed "$key")" "$(key_state "$key")"
            i=$((i + 1))
        done
    fi
}

remove_key() {
    local sel key cols
    cols=$(term_cols)
    hr "$cols"
    box_line "VER / BORRAR KEYS" "$cols"
    hr "$cols"
    key_table || return 0
    read -r -p "Número de key, [a] todas, [0] cancelar: " sel
    case "$sel" in
        0|"") return 0 ;;
        a|A)
            read -r -p "Confirma borrar TODAS? [S/N]: " sel
            [[ "$sel" == @(s|S|y|Y) ]] || return 0
            for key in "${KEY_IDS[@]}"; do
                rm -rf -- "$KEY_ROOT/$key" "$KEY_ROOT/$key.name"
            done
            rm -f "$LAST_FIXED_FILE"
            echo -e "${C_GREEN}Todas las keys fueron borradas.${C_RESET}"
            ;;
        *)
            [[ "$sel" =~ ^[0-9]+$ ]] || { echo "Selección inválida."; return 1; }
            (( sel >= 1 && sel <= ${#KEY_IDS[@]} )) || { echo "Selección fuera de rango."; return 1; }
            key="${KEY_IDS[sel-1]}"
            rm -rf -- "$KEY_ROOT/$key" "$KEY_ROOT/$key.name"
            echo -e "${C_GREEN}Key $key borrada.${C_RESET}"
            ;;
    esac
}

remove_used_keys() {
    local key count=0 answer
    collect_keys
    for key in "${KEY_IDS[@]}"; do
        [[ -s "$KEY_ROOT/$key/.used" ]] && count=$((count + 1))
    done
    if (( count == 0 )); then
        echo "No hay keys usadas."
        return 0
    fi
    read -r -p "Se borrarán $count keys usadas. Confirmar [S/N]: " answer
    [[ "$answer" == @(s|S|y|Y) ]] || return 0
    for key in "${KEY_IDS[@]}"; do
        [[ -s "$KEY_ROOT/$key/.used" ]] || continue
        rm -rf -- "$KEY_ROOT/$key" "$KEY_ROOT/$key.name"
    done
    echo -e "${C_GREEN}Keys usadas eliminadas: $count${C_RESET}"
}

update_fixed_key() {
    local -a fixed_keys=()
    local key i=1 sel new_ip owner cols
    cols=$(term_cols)
    collect_keys
    for key in "${KEY_IDS[@]}"; do
        [[ -s "$KEY_ROOT/$key/keyfixa" ]] && fixed_keys+=("$key")
    done
    if ((${#fixed_keys[@]} == 0)); then
        echo "No existen keys con IP fija."
        return 0
    fi
    hr "$cols"
    box_line "ACTUALIZAR IP DE KEY FIJA" "$cols"
    hr "$cols"
    for key in "${fixed_keys[@]}"; do
        printf '[%d] %s\n' "$i" "$key"
        printf '    Usuario : %s\n' "$(cat "$KEY_ROOT/$key.name" 2>/dev/null)"
        printf '    IP fija : %s\n' "$(cat "$KEY_ROOT/$key/keyfixa" 2>/dev/null)"
        i=$((i + 1))
    done
    hr "$cols"
    read -r -p "Seleccione key [0 cancelar]: " sel
    [[ "$sel" =~ ^[0-9]+$ ]] || return 1
    (( sel >= 1 && sel <= ${#fixed_keys[@]} )) || return 0
    key="${fixed_keys[sel-1]}"
    while :; do
        read -r -p "Nueva IP fija (vacío = quitar restricción): " new_ip
        new_ip="${new_ip//[[:space:]]/}"
        [[ -z "$new_ip" ]] && break
        valid_ip "$new_ip" && break
        echo "IP inválida."
    done
    if [[ -z "$new_ip" ]]; then
        rm -f "$KEY_ROOT/$key/keyfixa"
        owner=$(cat "$KEY_ROOT/$key.name" 2>/dev/null)
        owner="${owner// \[FIXA\]/}"
        printf '%s\n' "$owner" >"$KEY_ROOT/$key.name"
        echo "Restricción IP eliminada."
    else
        printf '%s\n' "$new_ip" >"$KEY_ROOT/$key/keyfixa"
        echo "IP fija actualizada a $new_ip."
    fi
}

server_health() {
    local srv="/usr/local/lib/golden/http-server.sh"
    [[ -x "$srv" ]] || srv="/bin/http-server.sh"
    [[ -x "$srv" ]] || return 1
    "$srv" --health >/dev/null 2>&1
}

service_status() {
    # Respeta un apagado manual; el watchdog tampoco lo volverá a encender.
    [[ -f /etc/golden/server-disabled ]] && { printf 'OFF'; return; }

    # ONLINE significa que el puerto realmente responde, no solo que existe un PID.
    if server_health; then
        printf 'ONLINE'
        return
    fi

    # Si systemd cree que está activo pero el listener no responde, lo repara
    # automáticamente al abrir el generador.
    if command -v systemctl >/dev/null 2>&1 && [[ -f /etc/systemd/system/golden-http.service || -f /lib/systemd/system/golden-http.service ]]; then
        if systemctl is-active --quiet golden-http.service; then
            systemctl restart golden-http.service >/dev/null 2>&1 || true
            sleep 1
            server_health && printf 'ONLINE' || printf 'OFF'
        else
            printf 'OFF'
        fi
        return
    fi

    # Compatibilidad con init/screen: si hay proceso pero está trabado, reinícialo.
    if pgrep -f '[h]ttp-server.sh.*(--listen|-start)' >/dev/null 2>&1; then
        pkill -f '[h]ttp-server.sh.*(--listen|-start)' 2>/dev/null || true
        screen -S generador -X quit >/dev/null 2>&1 || true
        if [[ -x /etc/init.d/golden-http ]]; then
            /etc/init.d/golden-http restart >/dev/null 2>&1 || true
        elif command -v screen >/dev/null 2>&1; then
            screen -dmS generador /bin/http-server.sh --listen
        else
            nohup /bin/http-server.sh --listen >/var/log/golden-http-console.log 2>&1 &
        fi
        sleep 1
        server_health && printf 'ONLINE' || printf 'OFF'
    else
        printf 'OFF'
    fi
}

toggle_server() {
    if command -v systemctl >/dev/null 2>&1 && [[ -f /etc/systemd/system/golden-http.service || -f /lib/systemd/system/golden-http.service ]]; then
        if systemctl is-active --quiet golden-http.service; then
            mkdir -p /etc/golden
            touch /etc/golden/server-disabled
            systemctl stop golden-http.service
            echo "Servidor detenido."
        else
            rm -f /etc/golden/server-disabled
            systemctl daemon-reload >/dev/null 2>&1 || true
            systemctl enable --now golden-http.service
            echo "Servidor iniciado."
        fi
        return
    fi

    if pgrep -f '[h]ttp-server.sh.*(--listen|-start)' >/dev/null 2>&1; then
        mkdir -p /etc/golden
        touch /etc/golden/server-disabled
        pkill -f '[h]ttp-server.sh.*(--listen|-start)' 2>/dev/null || true
        screen -S generador -X quit >/dev/null 2>&1 || true
        echo "Servidor detenido."
    else
        rm -f /etc/golden/server-disabled
        if command -v screen >/dev/null 2>&1; then
            screen -dmS generador /bin/http-server.sh --listen
        else
            nohup /bin/http-server.sh --listen >/var/log/golden-http-console.log 2>&1 &
        fi
        sleep 1
        pgrep -f '[h]ttp-server.sh.*(--listen|-start)' >/dev/null 2>&1 &&
            echo "Servidor iniciado." || echo "No se pudo iniciar; revisa /var/log/golden-http.log"
    fi
}

change_message() {
    local msg
    read -r -p "Nuevo mensaje: " msg
    printf '%s\n' "$msg" >"$SCPT_DIR/message.txt"
    chmod 0644 "$SCPT_DIR/message.txt"
    echo "Mensaje actualizado."
}

update_generator() {
    local repo="${GOLDEN_REPO:-$REPO_DEFAULT}" tmp
    [[ -s /etc/golden/repo ]] && repo=$(cat /etc/golden/repo)
    tmp=$(mktemp /tmp/goldengen.XXXXXX.sh)
    echo "Descargando actualizador desde $repo ..."
    if command -v curl >/dev/null 2>&1; then
        curl -fL --retry 3 --connect-timeout 10 "$repo/goldengen.sh" -o "$tmp" || {
            rm -f "$tmp"; echo "No se pudo descargar la actualización."; return 1;
        }
    else
        wget -O "$tmp" "$repo/goldengen.sh" || {
            rm -f "$tmp"; echo "No se pudo descargar la actualización."; return 1;
        }
    fi
    chmod 0700 "$tmp"
    if ! bash -n "$tmp"; then
        rm -f "$tmp"
        echo "El actualizador descargado contiene errores de sintaxis."
        return 1
    fi
    bash "$tmp"
    local rc=$?
    rm -f "$tmp"
    return "$rc"
}


key_stats() {
    local key active=0 used=0 fixed=0 total=0
    collect_keys
    total=${#KEY_IDS[@]}
    for key in "${KEY_IDS[@]}"; do
        if [[ -s "$KEY_ROOT/$key/.used" ]]; then
            used=$((used + 1))
        else
            active=$((active + 1))
        fi
        [[ -s "$KEY_ROOT/$key/keyfixa" ]] && fixed=$((fixed + 1))
    done
    printf '%s %s %s %s' "$total" "$active" "$used" "$fixed"
}

show_header() {
    clear 2>/dev/null || true
    local count status cols lastkey ip total active used fixed
    cols=$(term_cols)
    count=$(cat "$COUNTER_FILE" 2>/dev/null || printf '0')
    status=$(service_status)
    ip=$(server_ip 2>/dev/null || true)
    read -r total active used fixed <<<"$(key_stats)"
    [[ -s "$LAST_FIXED_FILE" ]] && lastkey=$(cat "$LAST_FIXED_FILE") || lastkey="-"

    hr "$cols"
    box_line "${C_BOLD}${C_CYAN}GOLDEN ADM PRO${C_RESET}  ${C_DIM}| REV26 FAST + ESTABLE${C_RESET}" "$cols"
    box_line "Servidor: $(status_badge "$status")  | Puerto: ${HTTP_PORT}  | Instalaciones: ${count}" "$cols"
    [[ -n "$ip" ]] && box_line "IP pública: $ip" "$cols"
    box_line "Keys: ${total} total  | ${C_GREEN}${active} activas${C_RESET}  | ${C_YELLOW}${used} usadas${C_RESET}  | ${fixed} IP fija" "$cols"
    if [[ "$lastkey" != "-" ]]; then
        box_line "Última FixKey: $(fit_text "$lastkey" $((cols-20)))" "$cols"
    fi
    hr "$cols"
}

show_log() {
    local cols
    cols=$(term_cols)
    hr "$cols"
    box_line "REGISTRO DE ACCESO" "$cols"
    hr "$cols"
    if [[ -s "$ACCESS_LOG" ]]; then
        tail -n 200 "$ACCESS_LOG"
    else
        echo "NO HAY REGISTROS."
    fi
}

show_diagnostics() {
    local cols rev os arch disk port81 port8888 apache
    cols=$(term_cols)
    rev="sin-respuesta"
    if command -v curl >/dev/null 2>&1; then
        rev=$(curl -fsS --connect-timeout 2 --max-time 4 "http://127.0.0.1:${HTTP_PORT}/__golden_version" 2>/dev/null || printf 'sin-respuesta')
    elif command -v wget >/dev/null 2>&1; then
        rev=$(wget -qO- --timeout=4 "http://127.0.0.1:${HTTP_PORT}/__golden_version" 2>/dev/null || printf 'sin-respuesta')
    fi
    os=$(awk -F= '/^PRETTY_NAME=/{gsub(/^"|"$/, "", $2); print $2; exit}' /etc/os-release 2>/dev/null || true)
    [[ -n "$os" ]] || os="Linux"
    arch=$(uname -m 2>/dev/null || printf '?')
    disk=$(df -h / 2>/dev/null | awk 'NR==2{print $4 " libres de " $2}' || true)
    port81="CERRADO"; port8888="CERRADO"
    if command -v ss >/dev/null 2>&1; then
        ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq '(^|:)81$' && port81="ESCUCHANDO" || true
        ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq '(^|:)8888$' && port8888="ESCUCHANDO" || true
    fi
    apache="N/D"
    if command -v apache2ctl >/dev/null 2>&1; then
        apache2ctl configtest >/dev/null 2>&1 && apache="OK" || apache="ERROR"
    fi

    hr "$cols"
    box_line "${C_BOLD}DIAGNOSTICO GOLDEN${C_RESET}" "$cols"
    hr "$cols"
    printf 'Sistema       : %s\n' "$os"
    printf 'Arquitectura  : %s\n' "$arch"
    printf 'Servidor keys : %s | versión: %s\n' "$(service_status)" "$rev"
    printf 'TCP 8888      : %s\n' "$port8888"
    printf 'TCP 81        : %s\n' "$port81"
    printf 'Apache config : %s\n' "$apache"
    [[ -n "$disk" ]] && printf 'Disco /       : %s\n' "$disk"
    if [[ -x "$SCPT_DIR/compat.sh" ]]; then
        echo
        bash "$SCPT_DIR/compat.sh" 2>/dev/null || true
    fi
    hr "$cols"
}

main_menu() {
    local option cols
    while :; do
        show_header
        cols=$(term_cols)
        box_line "${C_BOLD}KEYS${C_RESET}" "$cols"
        box_line "[1] Crear nueva key" "$cols"
        box_line "[2] Ver / borrar keys" "$cols"
        box_line "[3] Limpiar keys ya usadas" "$cols"
        box_line "${C_BOLD}SERVIDOR${C_RESET}" "$cols"
        box_line "[4] Iniciar / detener servidor de keys" "$cols"
        box_line "[5] Ver registro de accesos" "$cols"
        box_line "${C_BOLD}CONFIGURACION${C_RESET}" "$cols"
        box_line "[6] Cambiar mensaje" "$cols"
        box_line "[7] Cambiar IP de una key fija" "$cols"
        box_line "[8] Actualizar Golden ADM PRO" "$cols"
        box_line "[9] Diagnóstico del sistema" "$cols"
        box_line "[0] Salir" "$cols"
        hr "$cols"
        read -r -p "Selecciona una opción: " option
        hr "$cols"
        case "$option" in
            1) create_key ; pause_back ;;
            2) remove_key ; pause_back ;;
            3) remove_used_keys ; pause_back ;;
            4) toggle_server ; pause_back ;;
            5) show_log ; pause_back ;;
            6) change_message ; pause_back ;;
            7) update_fixed_key ; pause_back ;;
            8) update_generator ; pause_back ;;
            9) show_diagnostics ; pause_back ;;
            0) exit 0 ;;
            *) echo "Opción inválida."; pause_back ;;
        esac
    done
}

require_root
init_dirs

case "${1:-}" in
    --create) create_key ;;
    --start-server) toggle_server ;;
    --list) key_table ;;
    --remove-used) remove_used_keys ;;
    --self-test)
        bash -n "$0" &&
        [[ -x /bin/http-server.sh ]] &&
        /bin/http-server.sh --check
        ;;
    --help|-h)
        echo "Uso: gerar [--create|--list|--remove-used|--start-server|--self-test]"
        ;;
    *) main_menu ;;
esac
