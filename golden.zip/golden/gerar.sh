#!/usr/bin/env bash
# GENERADOR DE KEYS - GOLDEN SYSTEM PRO
# Versión corregida para Ubuntu/Debian antiguos y modernos (Bash 4+).

set -u
shopt -s extglob nullglob
umask 077

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

SCPT_DIR="${GOLDEN_SCRIPT_DIR:-/etc/SCRIPT}"
KEY_ROOT="${GOLDEN_KEY_DIR:-/etc/http-shell}"
LIST_NAME="${GOLDEN_LIST_NAME:-orp-nedlog}"
TOOL_LIST_NAME="${GOLDEN_TOOL_LIST_NAME:-lista-arq}"
HTTP_PORT="${GOLDEN_HTTP_PORT:-8888}"
COUNTER_FILE="${GOLDEN_COUNTER_FILE:-/etc/http-instas}"
LAST_FIXED_FILE="/etc/key-gerador"
ACCESS_LOG="/etc/gerar-sh-log"
REPO_DEFAULT="https://raw.githubusercontent.com/satanas66666/golden-system/main"

BASICINST=(
  menu PGet.py ports.sh budp.sh ADMbot.sh message.txt usercodes sockspy.sh
  POpen.py PPriv.py PPub.py PDirect.py speedtest.py speed.sh utils.sh
  dropbear.sh apacheon.sh openvpn.sh shadowsocks.sh ssl.sh squid.sh dados.sh
  Crear-Demo.sh squidpass.sh htop.sh gestor.sh shadowsocksLive.sh
  cambiarpass.sh Proxy-Publico.py Proxy-Privado.py ssrrmu.sh shadown.sh
  hora.sh panelweb.sh optimizar.sh v2ray.sh passvulrt.sh nload.sh bbr.sh
  ban_iptables.sh shadowsock.sh proxy_manager.sh compat.sh
)

C_RESET=$'\033[0m'
C_RED=$'\033[1;31m'
C_GREEN=$'\033[1;32m'
C_YELLOW=$'\033[1;33m'
C_CYAN=$'\033[1;36m'
BAR="${C_CYAN}--------------------------------------------------------------------${C_RESET}"

require_root() {
    if [[ "$(id -u)" -ne 0 ]]; then
        echo "ERROR: ejecuta este comando como root." >&2
        exit 1
    fi
}

init_dirs() {
    mkdir -p "$SCPT_DIR" "$KEY_ROOT" /etc/newadm/ger-user /etc/ger-frm /etc/ger-inst /etc/nanotxz
    [[ -f "$COUNTER_FILE" ]] || printf '0\n' >"$COUNTER_FILE"
    touch "$ACCESS_LOG"
    chmod 700 "$SCPT_DIR" "$KEY_ROOT" 2>/dev/null || true
    chmod 600 "$COUNTER_FILE" "$ACCESS_LOG" 2>/dev/null || true
}

is_ipv4() {
    local ip="$1" IFS=. octets octet
    [[ "$ip" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] || return 1
    read -r -a octets <<<"$ip"
    for octet in "${octets[@]}"; do
        (( 10#$octet >= 0 && 10#$octet <= 255 )) || return 1
    done
}

is_ipv6() {
    local ip="$1" rest colons group
    local -a groups=()
    [[ -n "$ip" && "$ip" =~ ^[0-9A-Fa-f:]+$ ]] || return 1
    [[ "$ip" != *:::* ]] || return 1
    [[ "$ip" != :* || "$ip" == ::* ]] || return 1
    [[ "$ip" != *: || "$ip" == *:: ]] || return 1

    colons="${ip//[^:]/}"
    if [[ "$ip" == *::* ]]; then
        rest="${ip#*::}"
        [[ "$rest" != *::* ]] || return 1
        (( ${#colons} >= 2 && ${#colons} <= 7 )) || return 1
    else
        (( ${#colons} == 7 )) || return 1
    fi

    IFS=: read -r -a groups <<<"$ip"
    for group in "${groups[@]}"; do
        [[ -z "$group" || ( ${#group} -ge 1 && ${#group} -le 4 && "$group" =~ ^[0-9A-Fa-f]+$ ) ]] || return 1
    done
}

valid_ip() {
    is_ipv4 "$1" || is_ipv6 "$1"
}

local_ip() {
    local ip=""
    ip=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
    [[ -n "$ip" ]] || ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    printf '%s' "$ip"
}

public_ip() {
    local ip=""
    if command -v curl >/dev/null 2>&1; then
        ip=$(curl -4fsS --connect-timeout 3 --max-time 6 https://api.ipify.org 2>/dev/null || true)
        [[ -n "$ip" ]] || ip=$(curl -4fsS --connect-timeout 3 --max-time 6 https://ipv4.icanhazip.com 2>/dev/null || true)
    elif command -v wget >/dev/null 2>&1; then
        ip=$(timeout 7 wget -qO- https://ipv4.icanhazip.com 2>/dev/null || true)
    fi
    ip="${ip//$'\r'/}"
    ip="${ip//$'\n'/}"
    valid_ip "$ip" || ip=$(local_ip)
    printf '%s' "$ip"
}

server_ip() {
    if [[ -n "${GOLDEN_SERVER_IP:-}" ]] && valid_ip "$GOLDEN_SERVER_IP"; then
        printf '%s' "$GOLDEN_SERVER_IP"
        return
    fi
    if [[ -s /etc/MEUIPADM ]]; then
        local saved
        saved=$(tr -d '\r\n ' </etc/MEUIPADM)
        if valid_ip "$saved"; then
            printf '%s' "$saved"
            return
        fi
    fi
    public_ip
}

ofus() {
    local input="$1" out="" ch i
    for ((i=0; i<${#input}; i++)); do
        ch="${input:i:1}"
        case "$ch" in
            ".") ch="+" ;;
            "+") ch="." ;;
            "1") ch="@" ;;
            "@") ch="1" ;;
            "2") ch="?" ;;
            "?") ch="2" ;;
            "3") ch="%" ;;
            "%") ch="3" ;;
            "/") ch="K" ;;
            "K") ch="/" ;;
        esac
        out+="$ch"
    done
    printf '%s' "$out" | rev
}

is_basic_file() {
    local name="$1" f
    for f in "${BASICINST[@]}"; do
        [[ "$f" == "$name" ]] && return 0
    done
    return 1
}

new_key_id() {
    local key
    while :; do
        if command -v openssl >/dev/null 2>&1; then
            key=$(openssl rand -hex 8 2>/dev/null || true)
        else
            key="$(date +%s)$RANDOM$RANDOM"
            key=$(printf '%s' "$key" | sha256sum | cut -c1-16)
        fi
        [[ "$key" =~ ^[A-Za-z0-9._-]+$ ]] || continue
        [[ ! -e "$KEY_ROOT/$key" ]] && {
            printf '%s' "$key"
            return
        }
    done
}

copy_to_key() {
    local key_dir="$1" list_file="$2" name="$3"
    if [[ ! -f "$SCPT_DIR/$name" ]]; then
        echo -e "${C_YELLOW}AVISO: falta $name; se omitió.${C_RESET}"
        return 1
    fi
    cp -f -- "$SCPT_DIR/$name" "$key_dir/$name" || return 1
    chmod 0755 "$key_dir/$name" 2>/dev/null || true
    printf '%s\n' "$name" >>"$list_file"
    return 0
}

extra_files() {
    local p name
    for p in "$SCPT_DIR"/*; do
        [[ -f "$p" ]] || continue
        name="${p##*/}"
        is_basic_file "$name" && continue
        printf '%s\n' "$name"
    done | LC_ALL=C sort
}

create_key() {
    local key key_dir list_file list_name choice owner fixed_answer fixed_ip="" ip decoded encoded
    local -a extras=() selected=()
    local idx token name copied=0

    key=$(new_key_id)
    key_dir="$KEY_ROOT/$key"
    mkdir -p "$key_dir"
    mapfile -t extras < <(extra_files)

    echo -e "$BAR"
    if ((${#extras[@]})); then
        echo -e "${C_CYAN}HERRAMIENTAS ADICIONALES DISPONIBLES:${C_RESET}"
        idx=1
        for name in "${extras[@]}"; do
            printf '[%d] -> %s\n' "$idx" "$name"
            idx=$((idx + 1))
        done
    else
        echo "No hay herramientas adicionales."
    fi
    echo "[x] -> TODAS LAS HERRAMIENTAS ADICIONALES"
    echo -e "[b] -> ${C_YELLOW}INSTALACION COMPLETA GOLDEN ADM PRO${C_RESET}"
    echo -e "$BAR"

    read -r -p "ESCOJA [b/x/numeros separados por espacio] (b): " choice
    choice="${choice:-b}"
    read -r -p "NOMBRE DE USUARIO (unnamed): " owner
    owner="${owner:-unnamed}"
    owner="${owner//$'\n'/ }"
    owner="${owner//$'\r'/ }"

    if [[ "$choice" == @(b|B) ]]; then
        list_name="$LIST_NAME"
    else
        list_name="$TOOL_LIST_NAME"
    fi
    list_file="$key_dir/$list_name"
    : >"$list_file"

    read -r -p "KEY FIJA POR IP? [S/N] (N): " fixed_answer
    fixed_answer="${fixed_answer:-n}"
    if [[ "$fixed_answer" == @(s|S|y|Y) ]]; then
        while :; do
            read -r -p "IP FIJA autorizada: " fixed_ip
            fixed_ip="${fixed_ip//[[:space:]]/}"
            valid_ip "$fixed_ip" && break
            echo -e "${C_RED}IP inválida. Intenta nuevamente.${C_RESET}"
        done
        printf '%s\n' "$fixed_ip" >"$key_dir/keyfixa"
        owner+=" [FIXA]"
    fi

    case "$choice" in
        b|B)
            for name in "${BASICINST[@]}"; do
                copy_to_key "$key_dir" "$list_file" "$name" && copied=$((copied + 1))
            done
            printf 'INSTALL\n' >"$key_dir/.type"
            ;;
        x|X)
            for name in "${extras[@]}"; do
                copy_to_key "$key_dir" "$list_file" "$name" && copied=$((copied + 1))
            done
            printf 'TOOL\n' >"$key_dir/.type"
            touch "$key_dir/HERRAMIENTA" "$key_dir/FERRAMENTA"
            ;;
        *)
            local -a choice_tokens=()
            IFS=$' \t' read -r -a choice_tokens <<<"$choice"
            for token in "${choice_tokens[@]}"; do
                [[ "$token" =~ ^[0-9]+$ ]] || continue
                (( token >= 1 && token <= ${#extras[@]} )) || continue
                name="${extras[token-1]}"
                selected+=("$name")
            done
            if ((${#selected[@]} == 0)); then
                echo -e "${C_RED}No se seleccionó ningún archivo válido.${C_RESET}"
                rm -rf -- "$key_dir"
                return 1
            fi
            for name in "${selected[@]}"; do
                copy_to_key "$key_dir" "$list_file" "$name" && copied=$((copied + 1))
            done
            printf 'TOOL\n' >"$key_dir/.type"
            touch "$key_dir/HERRAMIENTA" "$key_dir/FERRAMENTA"
            ;;
    esac

    if (( copied == 0 )); then
        echo -e "${C_RED}No se pudo copiar ningún archivo. KEY cancelada.${C_RESET}"
        rm -rf -- "$key_dir"
        return 1
    fi

    printf '%s\n' "$owner" >"$KEY_ROOT/$key.name"
    printf '%s\n' "$(date '+%Y-%m-%d %H:%M:%S')" >"$key_dir/.created"

    ip=$(server_ip)
    if [[ -z "$ip" ]]; then
        echo -e "${C_RED}No se pudo detectar la IP del servidor.${C_RESET}"
        rm -rf -- "$key_dir" "$KEY_ROOT/$key.name"
        return 1
    fi

    if is_ipv6 "$ip"; then
        decoded="[$ip]:$HTTP_PORT/$key/$list_name"
    else
        decoded="$ip:$HTTP_PORT/$key/$list_name"
    fi
    encoded=$(ofus "$decoded")

    if [[ -n "$fixed_ip" ]]; then
        printf '%s\n' "$encoded" >"$LAST_FIXED_FILE"
        chmod 600 "$LAST_FIXED_FILE"
    fi

    echo -e "$BAR"
    echo -e "${C_GREEN}KEY ACTIVA Y LISTA PARA INSTALACION${C_RESET}"
    echo -e "${C_YELLOW}KEY:${C_RESET} ${C_RED}${encoded}${C_RESET}"
    echo -e "${C_CYAN}URL REAL:${C_RESET} http://${decoded}"
    echo -e "${C_CYAN}ARCHIVOS:${C_RESET} $copied"
    [[ -n "$fixed_ip" ]] && echo -e "${C_CYAN}IP FIJA:${C_RESET} $fixed_ip"
    echo -e "$BAR"
}

collect_keys() {
    local d
    KEY_IDS=()
    for d in "$KEY_ROOT"/*; do
        [[ -d "$d" ]] || continue
        KEY_IDS+=("${d##*/}")
    done
}

key_table() {
    local i=1 key owner fixed used created
    collect_keys
    if ((${#KEY_IDS[@]} == 0)); then
        echo "No existen keys."
        return 1
    fi
    printf '%-4s %-18s %-24s %-16s %-19s\n' "N" "KEY" "USUARIO" "IP-FIJA" "ESTADO"
    printf '%s\n' "--------------------------------------------------------------------------------"
    for key in "${KEY_IDS[@]}"; do
        owner=$(cat "$KEY_ROOT/$key.name" 2>/dev/null || printf 'sin-nombre')
        fixed=$(cat "$KEY_ROOT/$key/keyfixa" 2>/dev/null || printf '-')
        if [[ -s "$KEY_ROOT/$key/.used" ]]; then
            used="USADA $(cut -d'|' -f1 "$KEY_ROOT/$key/.used")"
        else
            used="ACTIVA"
        fi
        printf '%-4s %-18s %-24.24s %-16.16s %-19.19s\n' "$i" "$key" "$owner" "$fixed" "$used"
        i=$((i + 1))
    done
}

remove_key() {
    local sel key
    echo -e "$BAR"
    key_table || return 0
    echo -e "$BAR"
    read -r -p "Número de key, [a] todas, [0] cancelar: " sel
    case "$sel" in
        0|"") return 0 ;;
        a|A)
            read -r -p "Confirma borrar TODAS? [S/N]: " sel
            [[ "$sel" == @(s|S|y|Y) ]] || return 0
            for key in "${KEY_IDS[@]}"; do
                rm -rf -- "$KEY_ROOT/$key" "$KEY_ROOT/$key.name"
            done
            rm -f "$LAST_FIXED_FILE"
            echo -e "${C_GREEN}Todas las keys fueron borradas.${C_RESET}"
            ;;
        *)
            [[ "$sel" =~ ^[0-9]+$ ]] || { echo "Selección inválida."; return 1; }
            (( sel >= 1 && sel <= ${#KEY_IDS[@]} )) || { echo "Selección fuera de rango."; return 1; }
            key="${KEY_IDS[sel-1]}"
            rm -rf -- "$KEY_ROOT/$key" "$KEY_ROOT/$key.name"
            echo -e "${C_GREEN}Key $key borrada.${C_RESET}"
            ;;
    esac
}

remove_used_keys() {
    local key count=0 answer
    collect_keys
    for key in "${KEY_IDS[@]}"; do
        [[ -s "$KEY_ROOT/$key/.used" ]] && count=$((count + 1))
    done
    if (( count == 0 )); then
        echo "No hay keys usadas."
        return 0
    fi
    read -r -p "Se borrarán $count keys usadas. Confirmar [S/N]: " answer
    [[ "$answer" == @(s|S|y|Y) ]] || return 0
    for key in "${KEY_IDS[@]}"; do
        [[ -s "$KEY_ROOT/$key/.used" ]] || continue
        rm -rf -- "$KEY_ROOT/$key" "$KEY_ROOT/$key.name"
    done
    echo -e "${C_GREEN}Keys usadas eliminadas: $count${C_RESET}"
}

update_fixed_key() {
    local -a fixed_keys=()
    local key i=1 sel new_ip owner
    collect_keys
    for key in "${KEY_IDS[@]}"; do
        [[ -s "$KEY_ROOT/$key/keyfixa" ]] && fixed_keys+=("$key")
    done
    if ((${#fixed_keys[@]} == 0)); then
        echo "No existen keys con IP fija."
        return 0
    fi
    echo -e "$BAR"
    for key in "${fixed_keys[@]}"; do
        printf '[%d] %s | %s | %s\n' "$i" "$key" \
            "$(cat "$KEY_ROOT/$key.name" 2>/dev/null)" \
            "$(cat "$KEY_ROOT/$key/keyfixa" 2>/dev/null)"
        i=$((i + 1))
    done
    echo -e "$BAR"
    read -r -p "Seleccione key [0 cancelar]: " sel
    [[ "$sel" =~ ^[0-9]+$ ]] || return 1
    (( sel >= 1 && sel <= ${#fixed_keys[@]} )) || return 0
    key="${fixed_keys[sel-1]}"
    while :; do
        read -r -p "Nueva IP fija (vacío = quitar restricción): " new_ip
        new_ip="${new_ip//[[:space:]]/}"
        [[ -z "$new_ip" ]] && break
        valid_ip "$new_ip" && break
        echo "IP inválida."
    done
    if [[ -z "$new_ip" ]]; then
        rm -f "$KEY_ROOT/$key/keyfixa"
        owner=$(cat "$KEY_ROOT/$key.name" 2>/dev/null)
        owner="${owner// \[FIXA\]/}"
        printf '%s\n' "$owner" >"$KEY_ROOT/$key.name"
        echo "Restricción IP eliminada."
    else
        printf '%s\n' "$new_ip" >"$KEY_ROOT/$key/keyfixa"
        echo "IP fija actualizada a $new_ip."
    fi
}

service_status() {
    if command -v systemctl >/dev/null 2>&1 && [[ -f /etc/systemd/system/golden-http.service || -f /lib/systemd/system/golden-http.service ]]; then
        systemctl is-active --quiet golden-http.service && printf 'ONLINE' || printf 'OFF'
    elif pgrep -f '[h]ttp-server.sh.*(--listen|-start)' >/dev/null 2>&1; then
        printf 'ONLINE'
    else
        printf 'OFF'
    fi
}

toggle_server() {
    if command -v systemctl >/dev/null 2>&1 && [[ -f /etc/systemd/system/golden-http.service || -f /lib/systemd/system/golden-http.service ]]; then
        if systemctl is-active --quiet golden-http.service; then
            systemctl stop golden-http.service
            echo "Servidor detenido."
        else
            systemctl daemon-reload >/dev/null 2>&1 || true
            systemctl enable --now golden-http.service
            echo "Servidor iniciado."
        fi
        return
    fi

    if pgrep -f '[h]ttp-server.sh.*(--listen|-start)' >/dev/null 2>&1; then
        pkill -f '[h]ttp-server.sh.*(--listen|-start)' 2>/dev/null || true
        screen -S generador -X quit >/dev/null 2>&1 || true
        echo "Servidor detenido."
    else
        if command -v screen >/dev/null 2>&1; then
            screen -dmS generador /bin/http-server.sh --listen
        else
            nohup /bin/http-server.sh --listen >/var/log/golden-http-console.log 2>&1 &
        fi
        sleep 1
        pgrep -f '[h]ttp-server.sh.*(--listen|-start)' >/dev/null 2>&1 &&
            echo "Servidor iniciado." || echo "No se pudo iniciar; revisa /var/log/golden-http.log"
    fi
}

change_message() {
    local msg
    read -r -p "NUEVO MENSAJE: " msg
    printf '%s\n' "$msg" >"$SCPT_DIR/message.txt"
    chmod 0644 "$SCPT_DIR/message.txt"
    echo "Mensaje actualizado."
}

update_generator() {
    local repo="${GOLDEN_REPO:-$REPO_DEFAULT}" tmp
    [[ -s /etc/golden/repo ]] && repo=$(cat /etc/golden/repo)
    tmp=$(mktemp /tmp/goldengen.XXXXXX.sh)
    echo "Descargando actualizador desde $repo ..."
    if command -v curl >/dev/null 2>&1; then
        curl -fL --retry 3 --connect-timeout 10 "$repo/goldengen.sh" -o "$tmp" || {
            rm -f "$tmp"; echo "No se pudo descargar la actualización."; return 1;
        }
    else
        wget -O "$tmp" "$repo/goldengen.sh" || {
            rm -f "$tmp"; echo "No se pudo descargar la actualización."; return 1;
        }
    fi
    chmod 0700 "$tmp"
    if ! bash -n "$tmp"; then
        rm -f "$tmp"
        echo "El actualizador descargado contiene errores de sintaxis."
        return 1
    fi
    bash "$tmp"
    local rc=$?
    rm -f "$tmp"
    return "$rc"
}

show_header() {
    clear 2>/dev/null || true
    local count status
    count=$(cat "$COUNTER_FILE" 2>/dev/null || printf '0')
    status=$(service_status)
    echo -e "$BAR"
    echo -e "${C_YELLOW}        GENERADOR DE KEYS [GOLDEN ADM PRO]${C_RESET}"
    echo -e "${C_CYAN}INSTALACIONES: ${count} | SERVIDOR: ${status}${C_RESET}"
    [[ -s "$LAST_FIXED_FILE" ]] && echo -e "${C_GREEN}ULTIMA FIXKEY: $(cat "$LAST_FIXED_FILE")${C_RESET}"
    echo -e "$BAR"
}

show_log() {
    if [[ -s "$ACCESS_LOG" ]]; then
        tail -n 200 "$ACCESS_LOG"
    else
        echo "NO HAY REGISTROS."
    fi
}

main_menu() {
    local option
    while :; do
        show_header
        echo -e "${C_RED}[1]${C_RESET} GENERAR KEY"
        echo -e "${C_CYAN}[2]${C_RESET} VER / BORRAR KEYS"
        echo -e "${C_CYAN}[3]${C_RESET} LIMPIAR KEYS USADAS"
        echo -e "${C_CYAN}[4]${C_RESET} INICIAR / PARAR SERVIDOR"
        echo -e "${C_CYAN}[5]${C_RESET} VER REGISTRO"
        echo -e "${C_CYAN}[6]${C_RESET} CAMBIAR MENSAJE"
        echo -e "${C_CYAN}[7]${C_RESET} ACTUALIZAR IP DE KEY FIJA"
        echo -e "${C_CYAN}[8]${C_RESET} ACTUALIZAR GENERADOR"
        echo -e "${C_RED}[0]${C_RESET} SALIR"
        echo -e "$BAR"
        read -r -p "Opción: " option
        echo -e "$BAR"
        case "$option" in
            1) create_key ;;
            2) remove_key ;;
            3) remove_used_keys ;;
            4) toggle_server ;;
            5) show_log ;;
            6) change_message ;;
            7) update_fixed_key ;;
            8) update_generator ;;
            0) exit 0 ;;
            *) echo "Opción inválida." ;;
        esac
        echo
        read -r -p "Presiona Enter para volver al menú..." _
    done
}

require_root
init_dirs

case "${1:-}" in
    --create) create_key ;;
    --start-server) toggle_server ;;
    --list) key_table ;;
    --remove-used) remove_used_keys ;;
    --self-test)
        bash -n "$0" &&
        [[ -x /bin/http-server.sh ]] &&
        /bin/http-server.sh --check
        ;;
    --help|-h)
        echo "Uso: gerar [--create|--list|--remove-used|--start-server|--self-test]"
        ;;
    *) main_menu ;;
esac
