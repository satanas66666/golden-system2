#!/usr/bin/env bash
set -Eeuo pipefail

PATH="/usr/sbin:/usr/bin:/sbin:/bin"
LC_ALL="C"
LANG="C"
export PATH LC_ALL LANG

MANAGER_VERSION="1.5.7"
SERVICE_NAME="hcr-server"
SYSTEMD_DIR="/etc/systemd/system"
DEFAULT_PORT="8880"
DEFAULT_TRANSPORT="plain"
DEFAULT_MAX_DOWNLOAD_FRAME="16384"
DEFAULT_DOWNLOAD_POLL_TIMEOUT="8s"

PORT="$DEFAULT_PORT"
TRANSPORT="$DEFAULT_TRANSPORT"
MAX_DOWNLOAD_FRAME="$DEFAULT_MAX_DOWNLOAD_FRAME"
DOWNLOAD_POLL_TIMEOUT="$DEFAULT_DOWNLOAD_POLL_TIMEOUT"
ACTION="menu"
TEMP_UNIT=""

# ANSI: solo si hay terminal real. Las barras HCR usan exactamente el slot
# COLOR[4] de NEW-GOLDEN (/etc/new-adm-color), con amarillo como fallback.
golden_panel_color_code() {
  case "${1:-4}" in
    1) printf '\033[1;37m' ;;
    2) printf '\033[31m' ;;
    3) printf '\033[32m' ;;
    4) printf '\033[33m' ;;
    5) printf '\033[34m' ;;
    6) printf '\033[35m' ;;
    7) printf '\033[1;36m' ;;
    *) printf '\033[33m' ;;
  esac
}
golden_panel_slot() {
  local slot="$1" def="$2" value=""
  if [ -s /etc/new-adm-color ]; then
    value="$(awk -v n="$((slot + 1))" '{for(i=1;i<=NF;i++){c++; if(c==n){print $i; exit}}}' /etc/new-adm-color 2>/dev/null || true)"
  fi
  [[ "$value" =~ ^[1-7]$ ]] || value="$def"
  golden_panel_color_code "$value"
}
if [ -t 1 ]; then
  C_GOLD="$(golden_panel_slot 4 4)"; C_GREEN='\033[1;32m'; C_RED='\033[1;31m'
  C_CYAN='\033[1;36m'; C_WHITE='\033[1;37m'; C_GRAY='\033[0;37m'; C_RESET='\033[0m'
else
  C_GOLD=''; C_GREEN=''; C_RED=''; C_CYAN=''; C_WHITE=''; C_GRAY=''; C_RESET=''
fi

BAR='=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×='

fail() {
  printf '%bError:%b %s\n' "$C_RED" "$C_RESET" "$*" >&2
  return 1
}

command -v readlink >/dev/null 2>&1 || { echo "Error: readlink was not found." >&2; exit 1; }
SCRIPT_PATH="$(readlink -f -- "${BASH_SOURCE[0]}")"
SCRIPT_DIR="$(dirname -- "$SCRIPT_PATH")"
BINARY_PATH="${SCRIPT_DIR}/hcr-server"
# Integración NEW-GOLDEN: todo el estado runtime vive fuera de /etc/ger-inst
# para que el menú principal no enumere .conf/.service como herramientas.
RUNTIME_DIR="/etc/newadm/hcr"
TLS_CERT_PATH="${RUNTIME_DIR}/fullchain.pem"
TLS_KEY_PATH="${RUNTIME_DIR}/privkey.pem"
UNIT_SOURCE_PATH="${RUNTIME_DIR}/${SERVICE_NAME}.service"
UNIT_LINK_PATH="${SYSTEMD_DIR}/${SERVICE_NAME}.service"
STATE_PATH="${RUNTIME_DIR}/hcr-manager.conf"
FIREWALL_STATE_PATH="${RUNTIME_DIR}/.hcr-manager-firewall"
EXTRA_STATE_PATH="${RUNTIME_DIR}/hcr-extra-ports.conf"
AUTOTUNE_STATE_PATH="${RUNTIME_DIR}/hcr-autotune.conf"

cleanup() {
  local rc=$?
  set +e
  [ -n "${TEMP_UNIT:-}" ] && rm -f -- "$TEMP_UNIT"
  return "$rc"
}
trap cleanup EXIT

prompt_read() {
  local __var="$1" __prompt="$2" __value=""
  if [ -r /dev/tty ] && [ -w /dev/tty ]; then
    printf '%s' "$__prompt" >/dev/tty
    IFS= read -r __value </dev/tty || return 1
  else
    printf '%s' "$__prompt"
    IFS= read -r __value || return 1
  fi
  printf -v "$__var" '%s' "$__value"
}

pause_menu() {
  local _tmp=""
  prompt_read _tmp "Presiona ENTER para continuar... " || true
}

clear_screen() {
  if [ -t 1 ]; then printf '\033[2J\033[H'; fi
}

usage() {
  cat <<EOF
HCR / NEW-GOLDEN ADM PRO Manager v${MANAGER_VERSION}

Uso interactivo:
  sudo /etc/ger-inst/hcr.sh
  sudo /etc/ger-inst/hcr.sh menu

MULTI-PORT:
  Instala primero el HCR principal y usa la opción [5] para crear listeners HCR
  adicionales reales en otros puertos. Cada puerto extra tiene su propio servicio systemd.

Uso directo:
  sudo /etc/ger-inst/hcr.sh --port <1-65535> --transport <plain|tls|auto> \\
    --max-download-frame <512-16384> --download-poll-timeout <duracion>
  sudo /etc/ger-inst/hcr.sh --uninstall

AUTO-TUNE:
  Ajusta automáticamente NOFILE, TasksMax, memoria y capacidad real HCR por
  listener según vCPU, RAM y cantidad de listeners. Usa opción [14] después
  de redimensionar la VPS.

Defaults NEW-GOLDEN / SpeiGo HCR:
  puerto: ${DEFAULT_PORT}
  transport: ${DEFAULT_TRANSPORT}
  MAX_DOWNLOAD_FRAME: ${DEFAULT_MAX_DOWNLOAD_FRAME}
  DOWNLOAD_POLL_TIMEOUT: ${DEFAULT_DOWNLOAD_POLL_TIMEOUT}
EOF
}

require_command() { command -v "$1" >/dev/null 2>&1 || fail "$1 no está instalado."; }

require_environment() {
  [ "$(id -u)" -eq 0 ] || fail "Ejecuta el manager como root (sudo)."
  [ "$(uname -s)" = "Linux" ] || fail "Este manager requiere Linux."
  mkdir -p "$RUNTIME_DIR" || fail "No se pudo crear $RUNTIME_DIR."
  chmod 0700 "$RUNTIME_DIR" || fail "No se pudieron asegurar permisos de $RUNTIME_DIR."
  local c
  for c in stat systemctl systemd-analyze flock ln mv mktemp sleep sed grep awk; do require_command "$c"; done
  systemctl show --property=Version --value >/dev/null 2>&1 || fail "systemd no está disponible."
  if [[ ! "$SCRIPT_DIR" =~ ^/[-A-Za-z0-9._/@+:]+$ ]]; then
    fail "La ruta del manager contiene caracteres no soportados: $SCRIPT_DIR"
  fi
}

acquire_install_lock() {
  exec 9<"${SYSTEMD_DIR}" || fail "No se pudo abrir el directorio de systemd para bloqueo."
  flock -n 9 || fail "Ya hay otro proceso de instalación HCR ejecutándose."
}

mode_is_writable_by_others() {
  local mode="${1:-}"
  [[ "$mode" =~ ^[0-7]{3,4}$ ]] || return 1
  (( (8#$mode & 8#022) != 0 ))
}

validate_secure_directory() {
  local current="$SCRIPT_DIR" mode
  while :; do
    [ -d "$current" ] && [ ! -L "$current" ] || fail "La ruta debe ser un directorio real: $current"
    [ "$(stat -c '%u' -- "$current")" = "0" ] || fail "La ruta debe pertenecer a root: $current"
    mode="$(stat -c '%a' -- "$current")"
    mode_is_writable_by_others "$mode" && fail "La ruta no puede ser escribible por grupo/otros: $current"
    [ "$current" = "/" ] && break
    current="$(dirname -- "$current")"
  done
}

validate_root_file() {
  local executable="$1" label="$2" path="$3" mode=""
  [ -f "$path" ] && [ ! -L "$path" ] || { fail "$label debe ser un archivo regular: $path"; return 1; }
  [ "$(stat -c '%u' -- "$path" 2>/dev/null)" = "0" ] || { fail "$label debe pertenecer a root: $path"; return 1; }
  mode="$(stat -c '%a' -- "$path" 2>/dev/null)" || { fail "No se pudieron leer permisos de $label: $path"; return 1; }
  [[ "$mode" =~ ^[0-7]{3,4}$ ]] || { fail "Permisos inválidos en $label: $path"; return 1; }
  if mode_is_writable_by_others "$mode"; then fail "$label no puede ser escribible por grupo/otros: $path"; return 1; fi
  if [ "$executable" = "true" ] && [ ! -x "$path" ]; then fail "$label debe ser ejecutable: $path"; return 1; fi
  return 0
}

validate_binary_identity() {
  local output
  output="$("$BINARY_PATH" -version 2>/dev/null)" || fail "El binario HCR no responde a -version."
  [[ "$output" =~ ^hcr-server\ version\ [0-9]+\.[0-9]+\.[0-9]+(\ -\ Patch\ [1-9][0-9]*)?$ ]] || fail "Versión de binario HCR no reconocida: $output"
}

tls_pair_matches() {
  local cert="$1" key="$2" cert_pub="" key_pub=""
  [ -r "$cert" ] && [ -r "$key" ] || return 1
  cert_pub="$(openssl x509 -in "$cert" -pubkey -noout 2>/dev/null)" || return 1
  key_pub="$(openssl pkey -in "$key" -passin pass: -pubout 2>/dev/null)" || return 1
  [ -n "$cert_pub" ] && [ "$cert_pub" = "$key_pub" ]
}

validate_tls_pair() {
  require_command openssl || return 1
  local key_mode=""
  validate_root_file false "Certificado TLS" "$TLS_CERT_PATH" || return 1
  validate_root_file false "Clave TLS" "$TLS_KEY_PATH" || return 1
  key_mode="$(stat -c '%a' -- "$TLS_KEY_PATH" 2>/dev/null)" || { fail "No se pudieron leer permisos de privkey.pem."; return 1; }
  [[ "$key_mode" =~ ^[0-7]{3,4}$ ]] || { fail "Permisos inválidos en privkey.pem."; return 1; }
  (( (8#$key_mode & 8#077) == 0 )) || { fail "privkey.pem debe tener permisos privados (por ejemplo 600)."; return 1; }
  tls_pair_matches "$TLS_CERT_PATH" "$TLS_KEY_PATH" || { fail "fullchain.pem y privkey.pem no son legibles o no corresponden."; return 1; }
  return 0
}

install_tls_pair_from() {
  local cert="$1" key="$2" label="${3:-certificado existente}" tmp_cert="" tmp_key=""
  require_command openssl || return 1
  tls_pair_matches "$cert" "$key" || return 1
  mkdir -p "$RUNTIME_DIR" || return 1
  tmp_cert="$(mktemp "${RUNTIME_DIR}/.fullchain.XXXXXX")" || return 1
  tmp_key="$(mktemp "${RUNTIME_DIR}/.privkey.XXXXXX")" || { rm -f -- "$tmp_cert"; return 1; }
  if ! cp -L -- "$cert" "$tmp_cert" || ! cp -L -- "$key" "$tmp_key"; then
    rm -f -- "$tmp_cert" "$tmp_key"
    return 1
  fi
  chown root:root "$tmp_cert" "$tmp_key" 2>/dev/null || true
  chmod 0644 "$tmp_cert" || { rm -f -- "$tmp_cert" "$tmp_key"; return 1; }
  chmod 0600 "$tmp_key" || { rm -f -- "$tmp_cert" "$tmp_key"; return 1; }
  mv -f -- "$tmp_cert" "$TLS_CERT_PATH" || { rm -f -- "$tmp_cert" "$tmp_key"; return 1; }
  mv -f -- "$tmp_key" "$TLS_KEY_PATH" || { rm -f -- "$tmp_key"; return 1; }
  if validate_tls_pair; then
    printf '%b[OK]%b TLS HCR reutiliza %s.\n' "$C_GREEN" "$C_RESET" "$label"
    return 0
  fi
  return 1
}

find_and_import_existing_tls_pair() {
  local d="" cert="" key=""
  # Primero certificados administrados por otros módulos NEW-GOLDEN.
  for d in /etc/superflash-h2connect/tls /etc/superflash-xhttp/tls; do
    [ -d "$d" ] || continue
    cert="$d/fullchain.pem"
    if [ -s "$d/key.pem" ]; then key="$d/key.pem"; else key="$d/privkey.pem"; fi
    if [ -s "$cert" ] && [ -s "$key" ] && install_tls_pair_from "$cert" "$key" "$d"; then return 0; fi
  done
  # Let's Encrypt / certbot. Los archivos live suelen ser symlinks; cp -L los materializa.
  for d in /etc/letsencrypt/live/*; do
    [ -d "$d" ] || continue
    cert="$d/fullchain.pem"; key="$d/privkey.pem"
    if [ -s "$cert" ] && [ -s "$key" ] && install_tls_pair_from "$cert" "$key" "$d"; then return 0; fi
  done
  # Certificados Xray ya instalados por Golden.
  for d in /usr/local/etc/xray/cert/*; do
    [ -d "$d" ] || continue
    cert="$d/cert.crt"; key="$d/private.key"
    if [ -s "$cert" ] && [ -s "$key" ] && install_tls_pair_from "$cert" "$key" "$d"; then return 0; fi
  done
  # Certificados acme.sh ECC/RSA existentes.
  for d in /root/.acme.sh/*_ecc /root/.acme.sh/*; do
    [ -d "$d" ] || continue
    cert="$d/fullchain.cer"
    [ -s "$cert" ] || continue
    for key in "$d"/*.key; do
      [ -s "$key" ] || continue
      if install_tls_pair_from "$cert" "$key" "$d"; then return 0; fi
    done
  done
  return 1
}

create_local_hcr_tls_pair() {
  local name="hcr.local" tmp_cert="" tmp_key=""
  require_command openssl || return 1
  mkdir -p "$RUNTIME_DIR" || return 1
  tmp_cert="$(mktemp "${RUNTIME_DIR}/.selfcert.XXXXXX.pem")" || return 1
  tmp_key="$(mktemp "${RUNTIME_DIR}/.selfkey.XXXXXX.pem")" || { rm -f -- "$tmp_cert"; return 1; }
  name="$(hostname -f 2>/dev/null || hostname 2>/dev/null || printf 'hcr.local')"
  [ -n "$name" ] || name="hcr.local"
  if ! openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 825 \
      -subj "/CN=${name}" -keyout "$tmp_key" -out "$tmp_cert" >/dev/null 2>&1; then
    rm -f -- "$tmp_cert" "$tmp_key"
    fail "No se pudo crear el certificado TLS local HCR."
    return 1
  fi
  chmod 0644 "$tmp_cert"; chmod 0600 "$tmp_key"
  mv -f -- "$tmp_cert" "$TLS_CERT_PATH"
  mv -f -- "$tmp_key" "$TLS_KEY_PATH"
  validate_tls_pair || return 1
  printf '%b[OK]%b Certificado TLS local HCR creado.\n' "$C_GREEN" "$C_RESET"
  printf '%b[AVISO]%b Es autofirmado: en el cliente HCR usa "Permitir inseguro" o instala/reutiliza un certificado público válido.\n' "$C_GOLD" "$C_RESET"
  return 0
}

ensure_tls_material() {
  local opt="" cert="" key=""
  if validate_tls_pair >/dev/null 2>&1; then return 0; fi
  rm -f -- "$TLS_CERT_PATH" "$TLS_KEY_PATH" 2>/dev/null || true
  if find_and_import_existing_tls_pair; then return 0; fi
  printf '%bTLS HCR:%b no se encontró un certificado existente reutilizable.\n' "$C_GOLD" "$C_RESET"
  if [ ! -r /dev/tty ] || [ ! -w /dev/tty ]; then
    fail "TLS/Auto requiere un certificado. Coloca fullchain.pem y privkey.pem en $RUNTIME_DIR o ejecuta el menú interactivo."
    return 1
  fi
  printf '  [1] Crear certificado local autofirmado (usar Permitir inseguro en el cliente)\n'
  printf '  [2] Importar certificado existente indicando rutas\n'
  printf '  [0] Cancelar\n'
  prompt_read opt "TLS [0-2]: " || return 1
  case "$opt" in
    1) create_local_hcr_tls_pair ;;
    2)
      prompt_read cert "Ruta fullchain/certificado: " || return 1
      prompt_read key "Ruta privkey/clave: " || return 1
      install_tls_pair_from "$cert" "$key" "rutas indicadas" || { fail "El certificado y la clave indicados no son válidos o no corresponden."; return 1; }
      ;;
    0) echo "Cancelado."; return 1 ;;
    *) fail "Opción TLS inválida."; return 1 ;;
  esac
}

validate_port() {
  local value="$1"
  case "$value" in ''|*[!0-9]*) return 1 ;; esac
  # Evitar desbordamientos aritméticos con entradas demasiado largas.
  [ "${#value}" -le 5 ] || return 1
  [ "$((10#$value))" -ge 1 ] && [ "$((10#$value))" -le 65535 ]
}

# systemd bloquea CAP_NET_BIND_SERVICE si CapabilityBoundingSet está vacío.
# Puertos <1024 requieren SOLAMENTE esta capacidad; puertos altos no reciben
# capacidades adicionales. Se conserva NoNewPrivileges y el aislamiento actual.
hcr_bind_capability() {
  local p="$1"
  if [ "$p" -lt 1024 ]; then
    printf 'CAP_NET_BIND_SERVICE'
  fi
}

validate_frame() {
  local value="$1"
  case "$value" in ''|*[!0-9]*) return 1 ;; esac
  [ "$((10#$value))" -ge 512 ] && [ "$((10#$value))" -le 16384 ]
}

validate_timeout() { [[ "$1" =~ ^[1-9][0-9]*(ms|s|m)$ ]]; }

validate_transport() { case "$1" in plain|tls|auto) return 0 ;; *) return 1 ;; esac; }


# -----------------------------------------------------------------------------
# AUTO-TUNE v1.5.0
# Ajusta límites por listener usando CPU, RAM y cantidad total de listeners HCR.
# No toca sysctl globales ni parámetros de SSH para no perjudicar otros servicios.
# -----------------------------------------------------------------------------
AT_CPU=1
AT_MEM_MB=1024
AT_LISTENERS=1
AT_CPU_SHARE=1
AT_MEM_SHARE_MB=1024
AT_NOFILE=16384
AT_TASKS=512
AT_MEMORY_HIGH_MB=512
AT_MEMORY_MAX_MB=768
# Capacidad real del binario HCR. El servidor 0.0.3 Patch 1 usa por defecto
# solo 32 sesiones globales / 2048 conexiones / 16 sesiones por IP si estas
# banderas no se especifican. Para VPS de producción eso provoca rechazos
# aunque CPU, RAM y NOFILE estén holgados. AUTO-TUNE calcula límites por
# listener conservando la relación oficial de 64 conexiones por sesión.
AT_MAX_SESSIONS=32
AT_MAX_CONNECTIONS=2048
AT_MAX_SESSIONS_PER_IP=16
AT_PROFILE="BALANCED"

clamp_int() {
  local v="$1" lo="$2" hi="$3"
  [ "$v" -lt "$lo" ] && v="$lo"
  [ "$v" -gt "$hi" ] && v="$hi"
  printf '%s' "$v"
}

detect_cpu_count() {
  local n=""
  if command -v nproc >/dev/null 2>&1; then n="$(nproc 2>/dev/null || true)"; fi
  if ! [[ "$n" =~ ^[1-9][0-9]*$ ]] && command -v getconf >/dev/null 2>&1; then
    n="$(getconf _NPROCESSORS_ONLN 2>/dev/null || true)"
  fi
  [[ "$n" =~ ^[1-9][0-9]*$ ]] || n=1
  printf '%s' "$n"
}

detect_mem_mb() {
  local kb=""
  kb="$(awk '/^MemTotal:/ {print $2; exit}' /proc/meminfo 2>/dev/null || true)"
  [[ "$kb" =~ ^[1-9][0-9]*$ ]] || kb=1048576
  printf '%s' "$((kb / 1024))"
}

extra_port_count() {
  local p t f d n=0
  if [ -f "$EXTRA_STATE_PATH" ]; then
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      validate_transport "${t:-}" || continue
      validate_frame "${f:-}" || continue
      validate_timeout "${d:-}" || continue
      n=$((n + 1))
    done < "$EXTRA_STATE_PATH"
  fi
  printf '%s' "$n"
}

managed_listener_count() {
  local n=0 extras
  extras="$(extra_port_count)"
  if [ -L "$UNIT_LINK_PATH" ] || [ -f "$UNIT_SOURCE_PATH" ]; then n=1; fi
  n=$((n + extras))
  [ "$n" -ge 1 ] || n=1
  printf '%s' "$n"
}

calculate_autotune() {
  local listeners="${1:-1}" cpu mem cpu_share mem_share fd_cpu fd_mem nofile tasks
  local reserve budget per_max per_high profile
  [[ "$listeners" =~ ^[1-9][0-9]*$ ]] || listeners=1
  cpu="$(detect_cpu_count)"
  mem="$(detect_mem_mb)"
  cpu_share=$(((cpu + listeners - 1) / listeners))
  [ "$cpu_share" -ge 1 ] || cpu_share=1
  mem_share=$((mem / listeners))
  [ "$mem_share" -ge 128 ] || mem_share=128

  fd_cpu=$((cpu_share * 16384))
  fd_mem=$((mem_share * 16))
  nofile="$fd_cpu"
  [ "$fd_mem" -lt "$nofile" ] && nofile="$fd_mem"
  nofile="$(clamp_int "$nofile" 8192 262144)"

  tasks=$((cpu_share * 512))
  tasks="$(clamp_int "$tasks" 512 8192)"

  if [ "$mem" -le 2048 ]; then
    reserve=$((mem / 4)); [ "$reserve" -ge 384 ] || reserve=384
  elif [ "$mem" -le 4096 ]; then
    reserve=768
  else
    reserve=$((mem / 5)); [ "$reserve" -ge 1024 ] || reserve=1024
  fi
  budget=$((mem - reserve)); [ "$budget" -ge 512 ] || budget=512
  per_max=$((budget / listeners)); [ "$per_max" -ge 256 ] || per_max=256
  per_high=$((per_max * 75 / 100)); [ "$per_high" -ge 192 ] || per_high=192

  if [ "$cpu" -ge 8 ] && [ "$mem" -ge 8192 ]; then profile="HIGH-CAPACITY"
  elif [ "$cpu" -ge 4 ] && [ "$mem" -ge 4096 ]; then profile="BALANCED+"
  elif [ "$cpu" -ge 2 ] && [ "$mem" -ge 2048 ]; then profile="BALANCED"
  else profile="SMALL-VPS"
  fi

  AT_CPU="$cpu"; AT_MEM_MB="$mem"; AT_LISTENERS="$listeners"
  AT_CPU_SHARE="$cpu_share"; AT_MEM_SHARE_MB="$mem_share"
  AT_NOFILE="$nofile"; AT_TASKS="$tasks"
  AT_MEMORY_HIGH_MB="$per_high"; AT_MEMORY_MAX_MB="$per_max"

  # Capacidad HCR por host/listener. Mantiene un techo conservador de 1024
  # sesiones por VPS y divide el presupuesto entre listeners reales para no
  # multiplicar accidentalmente la carga al abrir puertos adicionales.
  # CPU: hasta 96 sesiones por vCPU. RAM: hasta 1 sesión por ~20 MiB.
  local total_sessions_cpu total_sessions_mem total_sessions sessions connections per_ip
  total_sessions_cpu=$((cpu * 96))
  total_sessions_mem=$((mem / 20))
  total_sessions="$total_sessions_cpu"
  [ "$total_sessions_mem" -lt "$total_sessions" ] && total_sessions="$total_sessions_mem"
  total_sessions="$(clamp_int "$total_sessions" 64 1024)"
  # Redondear a bloques de 32 para que el reparto sea predecible.
  total_sessions=$(((total_sessions / 32) * 32))
  [ "$total_sessions" -ge 64 ] || total_sessions=64

  sessions=$((total_sessions / listeners))
  [ "$sessions" -ge 32 ] || sessions=32
  sessions=$(((sessions / 32) * 32))
  [ "$sessions" -ge 32 ] || sessions=32

  connections=$((sessions * 64))
  connections="$(clamp_int "$connections" 2048 65536)"

  # Evita el falso cuello de botella de 16 sesiones por IP del binario,
  # importante con usuarios móviles detrás de CGNAT, sin dejar el límite
  # por origen completamente abierto.
  per_ip=$((sessions / 2))
  per_ip="$(clamp_int "$per_ip" 32 512)"
  [ "$per_ip" -le "$sessions" ] || per_ip="$sessions"

  AT_MAX_SESSIONS="$sessions"
  AT_MAX_CONNECTIONS="$connections"
  AT_MAX_SESSIONS_PER_IP="$per_ip"
  AT_PROFILE="$profile"
}

save_autotune_state() {
  umask 077
  cat > "$AUTOTUNE_STATE_PATH" <<EOF
CPU=$AT_CPU
MEM_MB=$AT_MEM_MB
LISTENERS=$AT_LISTENERS
CPU_SHARE=$AT_CPU_SHARE
MEM_SHARE_MB=$AT_MEM_SHARE_MB
LIMIT_NOFILE=$AT_NOFILE
TASKS_MAX=$AT_TASKS
MEMORY_HIGH_MB=$AT_MEMORY_HIGH_MB
MEMORY_MAX_MB=$AT_MEMORY_MAX_MB
MAX_SESSIONS=$AT_MAX_SESSIONS
MAX_CONNECTIONS=$AT_MAX_CONNECTIONS
MAX_SESSIONS_PER_IP=$AT_MAX_SESSIONS_PER_IP
PROFILE=$AT_PROFILE
EOF
  chmod 0600 "$AUTOTUNE_STATE_PATH"
}

show_autotune_summary() {
  local count="${1:-$(managed_listener_count)}"
  calculate_autotune "$count"
  printf ' AUTO-TUNE: %b%s%b | CPU %b%s vCPU%b | RAM %b%s MB%b | Listeners %b%s%b\n' \
    "$C_GREEN" "$AT_PROFILE" "$C_RESET" "$C_CYAN" "$AT_CPU" "$C_RESET" \
    "$C_CYAN" "$AT_MEM_MB" "$C_RESET" "$C_CYAN" "$AT_LISTENERS" "$C_RESET"
  printf ' Recursos/listener: NOFILE %b%s%b | Tasks %b%s%b | MemoryHigh %b%sM%b | MemoryMax %b%sM%b\n' \
    "$C_CYAN" "$AT_NOFILE" "$C_RESET" "$C_CYAN" "$AT_TASKS" "$C_RESET" \
    "$C_CYAN" "$AT_MEMORY_HIGH_MB" "$C_RESET" "$C_CYAN" "$AT_MEMORY_MAX_MB" "$C_RESET"
  printf ' Capacidad HCR/listener: Sessions %b%s%b | Connections %b%s%b | Per-IP %b%s%b\n' \
    "$C_CYAN" "$AT_MAX_SESSIONS" "$C_RESET" "$C_CYAN" "$AT_MAX_CONNECTIONS" "$C_RESET" \
    "$C_CYAN" "$AT_MAX_SESSIONS_PER_IP" "$C_RESET"
}

save_state() {
  umask 077
  cat > "$STATE_PATH" <<EOF
PORT=$PORT
TRANSPORT=$TRANSPORT
MAX_DOWNLOAD_FRAME=$MAX_DOWNLOAD_FRAME
DOWNLOAD_POLL_TIMEOUT=$DOWNLOAD_POLL_TIMEOUT
EOF
  chmod 0600 "$STATE_PATH"
}

load_state() {
  local p="" t="" f="" d=""
  if [ -f "$STATE_PATH" ] && [ ! -L "$STATE_PATH" ]; then
    p="$(sed -n 's/^PORT=//p' "$STATE_PATH" | tail -n1)"
    t="$(sed -n 's/^TRANSPORT=//p' "$STATE_PATH" | tail -n1)"
    f="$(sed -n 's/^MAX_DOWNLOAD_FRAME=//p' "$STATE_PATH" | tail -n1)"
    d="$(sed -n 's/^DOWNLOAD_POLL_TIMEOUT=//p' "$STATE_PATH" | tail -n1)"
    validate_port "$p" && PORT="$((10#$p))"
    validate_transport "$t" && TRANSPORT="$t"
    validate_frame "$f" && MAX_DOWNLOAD_FRAME="$((10#$f))"
    validate_timeout "$d" && DOWNLOAD_POLL_TIMEOUT="$d"
  elif [ -f "$UNIT_SOURCE_PATH" ]; then
    local line
    line="$(grep '^ExecStart=' "$UNIT_SOURCE_PATH" 2>/dev/null | head -n1 || true)"
    p="$(printf '%s\n' "$line" | sed -n 's/.*--listen :\([0-9][0-9]*\).*/\1/p')"
    t="$(printf '%s\n' "$line" | sed -n 's/.*--transport \([^ ]*\).*/\1/p')"
    f="$(printf '%s\n' "$line" | sed -n 's/.*--max-download-frame \([0-9][0-9]*\).*/\1/p')"
    d="$(printf '%s\n' "$line" | sed -n 's/.*--download-poll-timeout \([^ ]*\).*/\1/p')"
    validate_port "$p" && PORT="$((10#$p))"
    validate_transport "$t" && TRANSPORT="$t"
    validate_frame "$f" && MAX_DOWNLOAD_FRAME="$((10#$f))"
    validate_timeout "$d" && DOWNLOAD_POLL_TIMEOUT="$d"
  fi
}


extra_service_name() { printf 'hcr-server-extra-%s' "$1"; }
extra_unit_source_path() { printf '%s/hcr-server-extra-%s.service' "$RUNTIME_DIR" "$1"; }
extra_unit_link_path() { printf '%s/hcr-server-extra-%s.service' "$SYSTEMD_DIR" "$1"; }

extra_port_exists() {
  local p="$1"
  [ -f "$EXTRA_STATE_PATH" ] && grep -Eq "^${p}[[:space:]]" "$EXTRA_STATE_PATH" 2>/dev/null
}

extra_state_add() {
  local p="$1" t="$2" f="$3" d="$4" tmp
  umask 077
  tmp="$(mktemp "${RUNTIME_DIR}/.extra.XXXXXX")"
  if [ -f "$EXTRA_STATE_PATH" ]; then
    grep -Ev "^${p}[[:space:]]" "$EXTRA_STATE_PATH" > "$tmp" || true
  fi
  printf '%s %s %s %s\n' "$p" "$t" "$f" "$d" >> "$tmp"
  sort -n -k1,1 "$tmp" -o "$tmp"
  mv -f "$tmp" "$EXTRA_STATE_PATH"
  chmod 0600 "$EXTRA_STATE_PATH"
}

extra_state_remove() {
  local p="$1" tmp
  [ -f "$EXTRA_STATE_PATH" ] || return 0
  tmp="$(mktemp "${RUNTIME_DIR}/.extra.XXXXXX")"
  grep -Ev "^${p}[[:space:]]" "$EXTRA_STATE_PATH" > "$tmp" || true
  if [ -s "$tmp" ]; then
    mv -f "$tmp" "$EXTRA_STATE_PATH"
    chmod 0600 "$EXTRA_STATE_PATH"
  else
    rm -f "$tmp" "$EXTRA_STATE_PATH"
  fi
}

extra_get_line() {
  local p="$1"
  [ -f "$EXTRA_STATE_PATH" ] || return 1
  grep -E "^${p}[[:space:]]" "$EXTRA_STATE_PATH" | tail -n1
}

extra_service_is_active() {
  local p="$1"
  systemctl is-active --quiet "$(extra_service_name "$p").service" 2>/dev/null
}

port_has_listener() {
  local p="$1"
  if command -v ss >/dev/null 2>&1; then
    # No usar el filtro `sport = :PORT`: algunas versiones antiguas de ss lo
    # interpretan distinto. Parsear la lista completa es más portable.
    ss -ltnH 2>/dev/null | awk -v p="$p" '
      $4 ~ (":" p "$") { found=1; exit }
      END { exit(found ? 0 : 1) }
    '
    return $?
  fi
  if command -v netstat >/dev/null 2>&1; then
    netstat -ltn 2>/dev/null | awk -v p="$p" '
      NR > 2 && $4 ~ (":" p "$") { found=1; exit }
      END { exit(found ? 0 : 1) }
    '
    return $?
  fi
  return 1
}

validate_extra_unit_link() {
  local p="$1" src link
  src="$(extra_unit_source_path "$p")"
  link="$(extra_unit_link_path "$p")"
  if [ -L "$link" ]; then
    [ "$(readlink -- "$link")" = "$src" ] || fail "Ya existe otra unidad systemd para el puerto HCR $p."
  elif [ -e "$link" ]; then
    fail "Ya existe una unidad systemd ajena: $link"
  fi
}

render_extra_unit() {
  local p="$1" t="$2" f="$3" d="$4" listener_count="${5:-$(managed_listener_count)}" tls_args="" src bind_cap=""
  calculate_autotune "$listener_count"
  bind_cap="$(hcr_bind_capability "$p")"
  src="$(extra_unit_source_path "$p")"
  if [ "$t" = "tls" ] || [ "$t" = "auto" ]; then
    tls_args=" --tls-cert ${TLS_CERT_PATH} --tls-key ${TLS_KEY_PATH}"
  fi
  TEMP_UNIT="$(mktemp "${RUNTIME_DIR}/.hcr-extra-${p}.XXXXXX.service")" || { fail "No se pudo crear la unidad temporal para TCP $p."; return 1; }
  chmod 0600 "$TEMP_UNIT" || { fail "No se pudieron aplicar permisos a la unidad temporal TCP $p."; return 1; }
  cat > "$TEMP_UNIT" <<EOF
[Unit]
Description=NEW-GOLDEN ADM PRO HCR relay extra TCP ${p}
Documentation=file:${SCRIPT_DIR}/hcr.sh
Wants=network-online.target
After=network-online.target ssh.service sshd.service
StartLimitIntervalSec=60
StartLimitBurst=10

[Service]
Type=exec
User=root
Group=root
WorkingDirectory=${SCRIPT_DIR}
ExecStart=${BINARY_PATH} --listen :${p} --target 127.0.0.1:22 --transport ${t}${tls_args} --max-sessions ${AT_MAX_SESSIONS} --max-connections ${AT_MAX_CONNECTIONS} --max-sessions-per-ip ${AT_MAX_SESSIONS_PER_IP} --max-download-frame ${f} --download-poll-timeout ${d}
Restart=always
RestartSec=2s
TimeoutStopSec=15s
KillSignal=SIGTERM
UMask=0077
NoNewPrivileges=true
CapabilityBoundingSet=${bind_cap}
AmbientCapabilities=${bind_cap}
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=read-only
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
RestrictNamespaces=true
MemoryDenyWriteExecute=false
ReadOnlyPaths=${SCRIPT_DIR}
LimitNOFILE=${AT_NOFILE}
LimitCORE=0
TasksMax=${AT_TASKS}
MemoryHigh=${AT_MEMORY_HIGH_MB}M
MemoryMax=${AT_MEMORY_MAX_MB}M
StandardOutput=journal
StandardError=journal
SyslogIdentifier=hcr-server-extra-${p}

[Install]
WantedBy=multi-user.target
EOF
  chmod 0644 "$TEMP_UNIT" || { fail "No se pudieron aplicar permisos a la unidad TCP $p."; return 1; }
  # systemd-analyze puede imprimir warnings de unidades AJENAS ya instaladas
  # (como BADVPN). systemctl + listener TCP son la validación real de este HCR.
  systemd-analyze verify "$TEMP_UNIT" >/dev/null 2>&1 || true
  mv -f -- "$TEMP_UNIT" "$src" || { fail "No se pudo instalar la unidad systemd extra TCP $p."; return 1; }
  TEMP_UNIT=""
}

show_extra_failure_diagnostics() {
  local p="$1" svc
  svc="$(extra_service_name "$p").service"
  printf '%b[DIAGNÓSTICO]%b Estado de %s:\n' "$C_GOLD" "$C_RESET" "$svc" >&2
  systemctl status --no-pager --full "$svc" 2>/dev/null | sed -n '1,18p' >&2 || true
  printf '%b[DIAGNÓSTICO]%b Últimas líneas del journal:\n' "$C_GOLD" "$C_RESET" >&2
  journalctl -u "$svc" -n 18 --no-pager 2>/dev/null >&2 || true
}

verify_extra_health() {
  local p="$1" svc pid="" last_pid="" stable=0 i
  svc="$(extra_service_name "$p").service"

  # Espera de asentamiento: el listener debe estar active, tener PID válido y
  # escuchar realmente en TCP p durante 3 comprobaciones consecutivas con el
  # mismo PID. Esto evita tanto falsos OK como falsos errores por arranque.
  for i in 1 2 3 4 5 6 7 8 9 10 11 12; do
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
      pid="$(systemctl show --property=MainPID --value "$svc" 2>/dev/null || true)"
      if [[ "$pid" =~ ^[1-9][0-9]*$ ]] && port_has_listener "$p"; then
        if [ "$pid" = "$last_pid" ]; then
          stable=$((stable + 1))
        else
          last_pid="$pid"
          stable=1
        fi
        [ "$stable" -ge 3 ] && return 0
      else
        stable=0
        last_pid=""
      fi
    else
      stable=0
      last_pid=""
    fi
    sleep 1
  done

  fail "El listener HCR extra TCP $p no logró permanecer activo y escuchando de forma estable."
  show_extra_failure_diagnostics "$p"
  return 1
}

cleanup_failed_extra_install() {
  local p="$1" svc src link
  svc="$(extra_service_name "$p")"
  src="$(extra_unit_source_path "$p")"
  link="$(extra_unit_link_path "$p")"
  systemctl disable --now "${svc}.service" >/dev/null 2>&1 || true
  if [ -L "$link" ] && [ "$(readlink -- "$link" 2>/dev/null || true)" = "$src" ]; then
    rm -f -- "$link"
  fi
  rm -f -- "$src"
  systemctl daemon-reload >/dev/null 2>&1 || true
  systemctl reset-failed "${svc}.service" >/dev/null 2>&1 || true
}

retune_all_services() {
  local count="${1:-$(managed_listener_count)}" p t f d
  local main_external="false" main_expected_port="" main_runtime_ok="false"
  [[ "$count" =~ ^[1-9][0-9]*$ ]] || count=1
  calculate_autotune "$count"

  # Autoridad del principal: el servicio realmente cargado por systemd.
  # Si pertenece a otro manager, no tocar su unidad ni reiniciarlo.
  if read_main_runtime_profile; then
    main_runtime_ok="true"
    main_expected_port="$MAIN_RUNTIME_PORT"
    local own_resolved="" runtime_resolved=""
    own_resolved="$(readlink -f -- "$UNIT_SOURCE_PATH" 2>/dev/null || true)"
    runtime_resolved="$(readlink -f -- "$MAIN_RUNTIME_FRAGMENT" 2>/dev/null || true)"
    [ -n "$runtime_resolved" ] || runtime_resolved="$MAIN_RUNTIME_FRAGMENT"
    if [ -z "$own_resolved" ] || [ "$runtime_resolved" != "$own_resolved" ]; then
      main_external="true"
    fi
    PORT="$MAIN_RUNTIME_PORT"
    TRANSPORT="$MAIN_RUNTIME_TRANSPORT"
    MAX_DOWNLOAD_FRAME="$MAIN_RUNTIME_FRAME"
    DOWNLOAD_POLL_TIMEOUT="$MAIN_RUNTIME_POLL"
    save_state
  fi

  if [ "$main_external" != "true" ] && { [ -L "$UNIT_LINK_PATH" ] || [ -f "$UNIT_SOURCE_PATH" ]; }; then
    load_state
    render_unit "$count" || return 1
    mv -f -- "$TEMP_UNIT" "$UNIT_SOURCE_PATH" || { fail "No se pudo actualizar AUTO-TUNE del HCR principal."; return 1; }
    TEMP_UNIT=""
  fi

  if [ -f "$EXTRA_STATE_PATH" ]; then
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      validate_transport "${t:-}" || continue
      validate_frame "${f:-}" || continue
      validate_timeout "${d:-}" || continue
      render_extra_unit "$p" "$t" "$f" "$d" "$count" || return 1
    done < "$EXTRA_STATE_PATH"
  fi

  systemctl daemon-reload >/dev/null 2>&1 || { fail "systemd no pudo aplicar AUTO-TUNE."; return 1; }

  if [ "$main_external" = "true" ]; then
    # No interrumpir un principal externo/estable: solo comprobar que sigue sano.
    [ "$main_runtime_ok" = "true" ] || { fail "No se pudo identificar el HCR principal real."; return 1; }
    verify_service_health_port "$main_expected_port" || return 1
  elif [ -L "$UNIT_LINK_PATH" ] || [ -f "$UNIT_SOURCE_PATH" ]; then
    systemctl restart "${SERVICE_NAME}.service" || { fail "No se pudo reiniciar HCR principal tras AUTO-TUNE."; return 1; }
    verify_service_health || return 1
  fi

  if [ -f "$EXTRA_STATE_PATH" ]; then
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      systemctl restart "$(extra_service_name "$p").service" || { fail "No se pudo reiniciar HCR extra TCP $p tras AUTO-TUNE."; return 1; }
      verify_extra_health "$p" || return 1
    done < "$EXTRA_STATE_PATH"
  fi

  calculate_autotune "$count"
  save_autotune_state
  return 0
}

manual_autotune() {
  service_is_installed || { fail "HCR principal aún no está instalado."; return 1; }
  local count
  count="$(managed_listener_count)"
  printf 'Recalculando AUTO-TUNE con CPU/RAM actuales y %s listener(s)...\n' "$count"
  if ! retune_all_services "$count"; then
    printf '%b[ERROR]%b AUTO-TUNE no pudo aplicarse completamente. Revisa Estado/Logs.\n' "$C_RED" "$C_RESET"
    return 1
  fi
  printf '%b[OK]%b AUTO-TUNE aplicado y listeners validados.\n' "$C_GREEN" "$C_RESET"
  show_autotune_summary "$count"
}

install_extra_service() {
  local p="$1" t="$2" f="$3" d="$4" planned_count="${5:-$(( $(managed_listener_count) + 1 ))}" svc src link
  validate_port "$p" || { fail "Puerto extra inválido: $p"; return 1; }
  validate_transport "$t" || { fail "Transport extra inválido: $t"; return 1; }
  validate_frame "$f" || { fail "Frame extra inválido: $f"; return 1; }
  validate_timeout "$d" || { fail "Poll extra inválido: $d"; return 1; }
  validate_secure_directory || return 1
  validate_root_file true "Manager" "$SCRIPT_PATH" || return 1
  validate_root_file true "Binario HCR" "$BINARY_PATH" || return 1
  validate_binary_identity || return 1
  if [ "$t" = "tls" ] || [ "$t" = "auto" ]; then
    ensure_tls_material || return 1
    validate_tls_pair || return 1
  fi
  validate_extra_unit_link "$p" || return 1

  svc="$(extra_service_name "$p")"
  src="$(extra_unit_source_path "$p")"
  link="$(extra_unit_link_path "$p")"

  render_extra_unit "$p" "$t" "$f" "$d" "$planned_count" || return 1
  if [ ! -L "$link" ]; then
    ln -s -- "$src" "$link" || { fail "No se pudo enlazar la unidad extra TCP $p."; cleanup_failed_extra_install "$p"; return 1; }
  fi
  systemctl daemon-reload || { fail "systemd no pudo recargar unidades para TCP $p."; cleanup_failed_extra_install "$p"; return 1; }
  systemctl enable "${svc}.service" >/dev/null || { fail "No se pudo habilitar ${svc}.service."; cleanup_failed_extra_install "$p"; return 1; }
  systemctl reset-failed "${svc}.service" >/dev/null 2>&1 || true

  if ! systemctl restart "${svc}.service"; then
    fail "El listener HCR extra TCP $p no pudo iniciar."
    show_extra_failure_diagnostics "$p"
    cleanup_failed_extra_install "$p"
    return 1
  fi
  if ! verify_extra_health "$p"; then
    cleanup_failed_extra_install "$p"
    return 1
  fi
  if ! extra_state_add "$p" "$t" "$f" "$d"; then
    fail "El listener TCP $p inició, pero no se pudo guardar su estado."
    cleanup_failed_extra_install "$p"
    return 1
  fi
  return 0
}

remove_extra_service() {
  local p="$1" close_fw="${2:-true}" svc src link
  extra_port_exists "$p" || { fail "El puerto HCR extra $p no está registrado."; return 1; }
  svc="$(extra_service_name "$p")"
  src="$(extra_unit_source_path "$p")"
  link="$(extra_unit_link_path "$p")"
  systemctl disable --now "${svc}.service" >/dev/null 2>&1 || true
  if [ -L "$link" ] && [ "$(readlink -- "$link")" = "$src" ]; then rm -f -- "$link"; fi
  rm -f -- "$src"
  systemctl daemon-reload
  systemctl reset-failed "${svc}.service" >/dev/null 2>&1 || true
  extra_state_remove "$p"
  if [ "$close_fw" = "true" ] && [ -f "$FIREWALL_STATE_PATH" ] && grep -qx "$p" "$FIREWALL_STATE_PATH" 2>/dev/null; then
    firewall_close "$p" || true
  fi
}

show_extra_ports() {
  local found="false" p t f d state color
  printf ' Puertos HCR adicionales:\n'
  if [ -f "$EXTRA_STATE_PATH" ]; then
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      validate_transport "${t:-}" || continue
      validate_frame "${f:-}" || continue
      validate_timeout "${d:-}" || continue
      found="true"; state="OFF"; color="$C_RED"
      if extra_service_is_active "$p"; then state="ON"; color="$C_GREEN"; fi
      printf '   - TCP %b%s%b | %b%s%b | %s | Frame %s | Poll %s\n' "$C_CYAN" "$p" "$C_RESET" "$color" "$state" "$C_RESET" "$t" "$f" "$d"
    done < "$EXTRA_STATE_PATH"
  fi
  [ "$found" = "true" ] || printf '   - Ninguno\n'
}

add_extra_port_menu() {
  service_is_installed || systemctl cat "${SERVICE_NAME}.service" >/dev/null 2>&1 || { fail "Instala primero el HCR principal con la opción 1 o 2."; return 1; }
  load_state

  # FIX v1.5.5: antes de crear un extra, sincronizar con el principal REAL.
  if read_main_runtime_profile; then
    if [ "$MAIN_RUNTIME_PORT" != "$PORT" ] || [ "$MAIN_RUNTIME_FRAME" != "$MAX_DOWNLOAD_FRAME" ] || [ "$MAIN_RUNTIME_POLL" != "$DOWNLOAD_POLL_TIMEOUT" ]; then
      printf '%b[SYNC]%b Principal real detectado: TCP %s | %s | Frame %s | Poll %s\n' \
        "$C_GOLD" "$C_RESET" "$MAIN_RUNTIME_PORT" "$MAIN_RUNTIME_TRANSPORT" "$MAIN_RUNTIME_FRAME" "$MAIN_RUNTIME_POLL"
    fi
    PORT="$MAIN_RUNTIME_PORT"
    TRANSPORT="$MAIN_RUNTIME_TRANSPORT"
    MAX_DOWNLOAD_FRAME="$MAIN_RUNTIME_FRAME"
    DOWNLOAD_POLL_TIMEOUT="$MAIN_RUNTIME_POLL"
    save_state
  fi

  local main_port="$PORT" p="" et="$TRANSPORT" ef="$MAX_DOWNLOAD_FRAME" ed="$DOWNLOAD_POLL_TIMEOUT"
  local old_count planned_count profile_rc=0
  prompt_read p "Nuevo puerto HCR adicional: " || return 1
  validate_port "$p" || { fail "Puerto inválido."; return 1; }
  p="$((10#$p))"
  [ "$p" != "$main_port" ] || { fail "TCP $p ya es el puerto HCR principal."; return 1; }

  if extra_port_exists "$p"; then
    if extra_service_is_active "$p" && port_has_listener "$p"; then
      fail "TCP $p ya está registrado y funcionando como puerto HCR adicional."
      return 1
    fi
    printf '%b[REPARANDO]%b Registro HCR extra TCP %s incompleto/antiguo; se recreará.\n' "$C_GOLD" "$C_RESET" "$p"
    cleanup_failed_extra_install "$p"
    extra_state_remove "$p"
  fi
  if port_has_listener "$p"; then
    fail "TCP $p ya está ocupado por otro listener. Elige otro puerto."
    return 1
  fi

  printf '\n%bCONFIGURACIÓN DEL NUEVO PUERTO HCR%b\n' "$C_GOLD" "$C_RESET"
  choose_transport || return 1
  et="$TRANSPORT"

  # Reutiliza EXACTAMENTE los perfiles de [15], incluidos segundos numéricos.
  choose_existing_performance_profile "$MAX_DOWNLOAD_FRAME" "$DOWNLOAD_POLL_TIMEOUT" || profile_rc=$?
  [ "$profile_rc" -eq 2 ] && { echo "Cancelado."; return 0; }
  [ "$profile_rc" -eq 0 ] || return 1
  ef="$PERF_FRAME"
  ed="$PERF_POLL"

  printf ' Nuevo listener: TCP %s | %s | Frame %s | Poll %s\n' "$p" "$et" "$ef" "$ed"

  old_count="$(managed_listener_count)"
  planned_count=$((old_count + 1))
  if ! install_extra_service "$p" "$et" "$ef" "$ed" "$planned_count"; then
    load_state
    printf '%b[NO CREADO]%b TCP %s no se registró como listener HCR adicional.\n' "$C_RED" "$C_RESET" "$p"
    return 1
  fi

  printf '%b[AUTO-TUNE]%b Repartiendo recursos entre %s listeners HCR...\n' "$C_GOLD" "$C_RESET" "$planned_count"
  if ! retune_all_services "$planned_count"; then
    printf '%b[ROLLBACK]%b El nuevo puerto inició, pero AUTO-TUNE no validó el conjunto. Se elimina TCP %s.\n' "$C_RED" "$C_RESET" "$p"
    remove_extra_service "$p" false || true
    retune_all_services "$old_count" || true
    load_state
    return 1
  fi

  firewall_open "$p" || true
  load_state
  printf '%b[OK]%b Listener HCR adicional TCP %s creado, estable, escuchando y AUTO-TUNED.\n' "$C_GREEN" "$C_RESET" "$p"
}

remove_extra_port_menu() {
  local p=""
  show_extra_ports
  [ -f "$EXTRA_STATE_PATH" ] || return 0
  prompt_read p "Puerto HCR adicional a eliminar: " || return 1
  validate_port "$p" || { fail "Puerto inválido."; return 1; }
  p="$((10#$p))"
  extra_port_exists "$p" || { fail "TCP $p no es un puerto HCR adicional administrado por este manager."; return 1; }
  remove_extra_service "$p" true
  local new_count
  new_count="$(managed_listener_count)"
  printf '%b[AUTO-TUNE]%b Recalculando recursos para %s listener(s)...\n' "$C_GOLD" "$C_RESET" "$new_count"
  if ! retune_all_services "$new_count"; then
    printf '%b[AVISO]%b El puerto fue eliminado, pero AUTO-TUNE no pudo revalidar todos los listeners. Usa la opción 14.\n' "$C_GOLD" "$C_RESET"
  fi
  printf '%b[OK]%b Listener HCR adicional TCP %s eliminado. El principal sigue intacto.\n' "$C_GREEN" "$C_RESET" "$p"
}

validate_bundle() {
  validate_secure_directory || return 1
  validate_root_file true "Manager" "$SCRIPT_PATH" || return 1
  validate_root_file true "Binario HCR" "$BINARY_PATH" || return 1
  validate_binary_identity || return 1
  if [ "$TRANSPORT" = "tls" ] || [ "$TRANSPORT" = "auto" ]; then validate_tls_pair || return 1; fi
  return 0
}

validate_unit_link() {
  if [ -L "$UNIT_LINK_PATH" ]; then
    [ "$(readlink -- "$UNIT_LINK_PATH")" = "$UNIT_SOURCE_PATH" ] || fail "Ya existe otro ${SERVICE_NAME}.service administrado desde otra ruta."
  elif [ -e "$UNIT_LINK_PATH" ]; then
    fail "Ya existe una unidad systemd ajena: $UNIT_LINK_PATH"
  fi
}

render_unit() {
  local listener_count="${1:-$(managed_listener_count)}" tls_args="" bind_cap=""
  calculate_autotune "$listener_count"
  bind_cap="$(hcr_bind_capability "$PORT")"
  if [ "$TRANSPORT" = "tls" ] || [ "$TRANSPORT" = "auto" ]; then
    tls_args=" --tls-cert ${TLS_CERT_PATH} --tls-key ${TLS_KEY_PATH}"
  fi
  TEMP_UNIT="$(mktemp "${RUNTIME_DIR}/.${SERVICE_NAME}.XXXXXX.service")"
  chmod 0600 "$TEMP_UNIT"
  cat > "$TEMP_UNIT" <<EOF
[Unit]
Description=NEW-GOLDEN ADM PRO HCR relay
Documentation=file:${SCRIPT_DIR}/hcr.sh
Wants=network-online.target
After=network-online.target ssh.service sshd.service
StartLimitIntervalSec=60
StartLimitBurst=10

[Service]
Type=exec
User=root
Group=root
WorkingDirectory=${SCRIPT_DIR}
ExecStart=${BINARY_PATH} --listen :${PORT} --target 127.0.0.1:22 --transport ${TRANSPORT}${tls_args} --max-sessions ${AT_MAX_SESSIONS} --max-connections ${AT_MAX_CONNECTIONS} --max-sessions-per-ip ${AT_MAX_SESSIONS_PER_IP} --max-download-frame ${MAX_DOWNLOAD_FRAME} --download-poll-timeout ${DOWNLOAD_POLL_TIMEOUT}
Restart=always
RestartSec=2s
TimeoutStopSec=15s
KillSignal=SIGTERM
UMask=0077
NoNewPrivileges=true
CapabilityBoundingSet=${bind_cap}
AmbientCapabilities=${bind_cap}
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ProtectHome=read-only
ProtectControlGroups=true
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
RestrictNamespaces=true
MemoryDenyWriteExecute=false
ReadOnlyPaths=${SCRIPT_DIR}
LimitNOFILE=${AT_NOFILE}
LimitCORE=0
TasksMax=${AT_TASKS}
MemoryHigh=${AT_MEMORY_HIGH_MB}M
MemoryMax=${AT_MEMORY_MAX_MB}M
StandardOutput=journal
StandardError=journal
SyslogIdentifier=hcr-server

[Install]
WantedBy=multi-user.target
EOF
  chmod 0644 "$TEMP_UNIT"
  systemd-analyze verify "$TEMP_UNIT" >/dev/null 2>&1 || true
}

verify_service_health_port() {
  local expected_port="$1" pid="" last_pid="" stable=0 i
  validate_port "$expected_port" || { fail "Puerto de health inválido: $expected_port"; return 1; }
  for i in 1 2 3 4 5 6 7 8 9 10 11 12; do
    if systemctl is-active --quiet "${SERVICE_NAME}.service" 2>/dev/null; then
      pid="$(systemctl show --property=MainPID --value "${SERVICE_NAME}.service" 2>/dev/null || true)"
      if [[ "$pid" =~ ^[1-9][0-9]*$ ]] && port_has_listener "$expected_port"; then
        if [ "$pid" = "$last_pid" ]; then stable=$((stable + 1)); else last_pid="$pid"; stable=1; fi
        [ "$stable" -ge 3 ] && return 0
      else
        stable=0; last_pid=""
      fi
    else
      stable=0; last_pid=""
    fi
    sleep 1
  done
  fail "HCR principal no logró permanecer activo y escuchando de forma estable en TCP $expected_port."
  systemctl status --no-pager --full "${SERVICE_NAME}.service" 2>/dev/null | sed -n '1,18p' >&2 || true
  journalctl -u "${SERVICE_NAME}.service" -n 18 --no-pager 2>/dev/null >&2 || true
  return 1
}

verify_service_health() {
  verify_service_health_port "$PORT"
}

# FIX v1.5.4: el NEW-GOLDEN puede convivir con un hcr-server.service que ya
# existía antes (por ejemplo /opt/hcr-production). En ese caso el estado local
# podía decir :8880, mientras systemd realmente reiniciaba :8080. Para editar
# Frame/Poll, la autoridad es el FragmentPath/ExecStart que systemd tiene cargado.
MAIN_RUNTIME_FRAGMENT=""
MAIN_RUNTIME_PORT=""
MAIN_RUNTIME_TRANSPORT=""
MAIN_RUNTIME_FRAME=""
MAIN_RUNTIME_POLL=""

read_main_runtime_profile() {
  local fragment="" resolved="" line="" p="" t="" f="" d=""
  MAIN_RUNTIME_FRAGMENT=""; MAIN_RUNTIME_PORT=""; MAIN_RUNTIME_TRANSPORT=""; MAIN_RUNTIME_FRAME=""; MAIN_RUNTIME_POLL=""
  fragment="$(systemctl show --property=FragmentPath --value "${SERVICE_NAME}.service" 2>/dev/null || true)"
  [ -n "$fragment" ] || return 1
  resolved="$(readlink -f -- "$fragment" 2>/dev/null || true)"
  [ -n "$resolved" ] || resolved="$fragment"
  [ -f "$resolved" ] || return 1
  line="$(grep -E '^[[:space:]]*ExecStart=' "$resolved" 2>/dev/null | head -n1 || true)"
  [ -n "$line" ] || return 1
  p="$(printf '%s
' "$line" | sed -n 's/.*--listen :\([0-9][0-9]*\).*/\1/p')"
  t="$(printf '%s
' "$line" | sed -n 's/.*--transport \([^ ]*\).*/\1/p')"
  f="$(printf '%s
' "$line" | sed -n 's/.*--max-download-frame \([0-9][0-9]*\).*/\1/p')"
  d="$(printf '%s
' "$line" | sed -n 's/.*--download-poll-timeout \([^ ]*\).*/\1/p')"
  validate_port "$p" || return 1
  validate_transport "$t" || return 1
  validate_frame "$f" || return 1
  validate_timeout "$d" || return 1
  MAIN_RUNTIME_FRAGMENT="$resolved"
  MAIN_RUNTIME_PORT="$((10#$p))"
  MAIN_RUNTIME_TRANSPORT="$t"
  MAIN_RUNTIME_FRAME="$((10#$f))"
  MAIN_RUNTIME_POLL="$d"
  return 0
}

# FIX v1.5.5: sincroniza el estado visible con el hcr-server.service REAL antes
# de operaciones multi-port/AUTO-TUNE. Si el principal pertenece a otro manager
# (por ejemplo /opt/hcr-production), NEW-GOLDEN no lo reescribe ni lo reinicia;
# solo usa su puerto/perfil reales para validar el conjunto.
MAIN_RUNTIME_EXTERNAL="false"

sync_main_runtime_state() {
  MAIN_RUNTIME_EXTERNAL="false"
  if ! read_main_runtime_profile; then
    return 1
  fi

  local own_resolved="" runtime_resolved=""
  own_resolved="$(readlink -f -- "$UNIT_SOURCE_PATH" 2>/dev/null || true)"
  runtime_resolved="$(readlink -f -- "$MAIN_RUNTIME_FRAGMENT" 2>/dev/null || true)"
  [ -n "$runtime_resolved" ] || runtime_resolved="$MAIN_RUNTIME_FRAGMENT"

  if [ -z "$own_resolved" ] || [ "$runtime_resolved" != "$own_resolved" ]; then
    MAIN_RUNTIME_EXTERNAL="true"
  fi

  PORT="$MAIN_RUNTIME_PORT"
  TRANSPORT="$MAIN_RUNTIME_TRANSPORT"
  MAX_DOWNLOAD_FRAME="$MAIN_RUNTIME_FRAME"
  DOWNLOAD_POLL_TIMEOUT="$MAIN_RUNTIME_POLL"
  save_state
  return 0
}

PROFILE_PATCH_TEMP=""
patch_unit_profile_copy() {
  local src="$1" new_frame="$2" new_poll="$3" dir="" tmp=""
  PROFILE_PATCH_TEMP=""
  [ -f "$src" ] || { fail "No existe la unidad systemd a editar: $src"; return 1; }
  grep -Eq -- '--max-download-frame[[:space:]]+[^[:space:]]+' "$src" || { fail "La unidad no contiene --max-download-frame."; return 1; }
  grep -Eq -- '--download-poll-timeout[[:space:]]+[^[:space:]]+' "$src" || { fail "La unidad no contiene --download-poll-timeout."; return 1; }
  dir="$(dirname -- "$src")"
  tmp="$(mktemp "${dir}/.hcr-profile-edit.XXXXXX.service")" || return 1
  cp -p -- "$src" "$tmp" || { rm -f "$tmp"; return 1; }
  sed -E -i     -e "s/(--max-download-frame[[:space:]]+)[^[:space:]]+/\1${new_frame}/"     -e "s/(--download-poll-timeout[[:space:]]+)[^[:space:]]+/\1${new_poll}/"     "$tmp" || { rm -f "$tmp"; return 1; }
  grep -Eq -- "--max-download-frame[[:space:]]+${new_frame}([[:space:]]|$)" "$tmp" || { rm -f "$tmp"; return 1; }
  grep -Eq -- "--download-poll-timeout[[:space:]]+${new_poll}([[:space:]]|$)" "$tmp" || { rm -f "$tmp"; return 1; }
  PROFILE_PATCH_TEMP="$tmp"
  return 0
}

install_service() {
  validate_port "$PORT" || { fail "Puerto inválido: $PORT"; return 1; }
  validate_transport "$TRANSPORT" || { fail "Transport inválido: $TRANSPORT"; return 1; }
  validate_frame "$MAX_DOWNLOAD_FRAME" || { fail "MAX_DOWNLOAD_FRAME debe estar entre 512 y 16384."; return 1; }
  validate_timeout "$DOWNLOAD_POLL_TIMEOUT" || { fail "DOWNLOAD_POLL_TIMEOUT inválido (ej. 8s)."; return 1; }
  PORT="$((10#$PORT))"; MAX_DOWNLOAD_FRAME="$((10#$MAX_DOWNLOAD_FRAME))"
  if extra_port_exists "$PORT"; then
    fail "TCP $PORT ya pertenece a un listener HCR adicional. Elimina ese extra antes de usarlo como puerto principal."
    return 1
  fi
  if [ "$TRANSPORT" = "tls" ] || [ "$TRANSPORT" = "auto" ]; then ensure_tls_material || return 1; fi
  validate_bundle || return 1
  validate_unit_link || return 1
  # Reinstalar en el mismo puerto del propio principal es válido. Nunca
  # sobrescribir/reiniciar el principal si otro daemon ocupa el puerto nuevo.
  local active_owned_port="" resolved_own="" resolved_main=""
  if read_main_runtime_profile; then
    resolved_own="$(readlink -f -- "$UNIT_SOURCE_PATH" 2>/dev/null || true)"
    resolved_main="$(readlink -f -- "$MAIN_RUNTIME_FRAGMENT" 2>/dev/null || true)"
    if [ -n "$resolved_own" ] && [ "$resolved_own" = "$resolved_main" ]; then
      active_owned_port="$MAIN_RUNTIME_PORT"
    fi
  fi
  if [ "$PORT" != "$active_owned_port" ] && port_has_listener "$PORT"; then
    fail "TCP $PORT ya está ocupado. No se ha modificado el servicio HCR existente."
    return 1
  fi
  local planned_count old_unit_backup="" old_was_active="false" start_failed="false"
  planned_count=$((1 + $(extra_port_count)))
  # Respaldo ANTES de reemplazar el principal: un puerto ocupado o un arranque
  # fallido nunca debe dejar fuera de línea una configuración que sí funcionaba.
  if [ -f "$UNIT_SOURCE_PATH" ]; then
    old_unit_backup="$(mktemp "${RUNTIME_DIR}/.hcr-main-before-install.XXXXXX.bak")" || return 1
    cp -p -- "$UNIT_SOURCE_PATH" "$old_unit_backup" || { rm -f "$old_unit_backup"; return 1; }
  fi
  if service_is_active; then old_was_active="true"; fi
  if ! render_unit "$planned_count" || ! mv -f -- "$TEMP_UNIT" "$UNIT_SOURCE_PATH"; then
    [ -z "$old_unit_backup" ] || rm -f -- "$old_unit_backup"
    fail "No se pudo preparar la unidad principal."
    return 1
  fi
  TEMP_UNIT=""
  if [ ! -L "$UNIT_LINK_PATH" ]; then
    ln -s -- "$UNIT_SOURCE_PATH" "$UNIT_LINK_PATH" || start_failed="true"
  fi
  if [ "$start_failed" = "false" ]; then
    systemctl daemon-reload || start_failed="true"
  fi
  if [ "$start_failed" = "false" ]; then
    systemctl enable "${SERVICE_NAME}.service" >/dev/null || start_failed="true"
  fi
  if [ "$start_failed" = "false" ]; then
    systemctl reset-failed "${SERVICE_NAME}.service" >/dev/null 2>&1 || true
    systemctl restart "${SERVICE_NAME}.service" || start_failed="true"
  fi
  if [ "$start_failed" = "false" ]; then
    verify_service_health || start_failed="true"
  fi
  if [ "$start_failed" = "true" ]; then
    printf '%b[ROLLBACK]%b El puerto TCP %s no quedó activo; restaurando HCR anterior.\n' "$C_RED" "$C_RESET" "$PORT" >&2
    if [ -n "$old_unit_backup" ]; then
      cp -p -- "$old_unit_backup" "$UNIT_SOURCE_PATH" || fail "No se pudo restaurar el respaldo HCR."
      if [ "$old_was_active" = "true" ]; then
        systemctl daemon-reload >/dev/null 2>&1 || true
        systemctl restart "${SERVICE_NAME}.service" >/dev/null 2>&1 || true
      else
        systemctl stop "${SERVICE_NAME}.service" >/dev/null 2>&1 || true
        systemctl daemon-reload >/dev/null 2>&1 || true
      fi
    else
      systemctl disable --now "${SERVICE_NAME}.service" >/dev/null 2>&1 || true
      if [ -L "$UNIT_LINK_PATH" ] && [ "$(readlink -- "$UNIT_LINK_PATH" 2>/dev/null || true)" = "$UNIT_SOURCE_PATH" ]; then
        rm -f -- "$UNIT_LINK_PATH"
      fi
      rm -f -- "$UNIT_SOURCE_PATH"
      systemctl daemon-reload >/dev/null 2>&1 || true
    fi
    [ -z "$old_unit_backup" ] || rm -f -- "$old_unit_backup"
    return 1
  fi
  [ -z "$old_unit_backup" ] || rm -f -- "$old_unit_backup"
  save_state || { fail "HCR inició, pero no se pudo guardar el estado del manager."; return 1; }
  calculate_autotune "$planned_count"
  save_autotune_state
  if [ "$(extra_port_count)" -gt 0 ]; then
    printf '%b[AUTO-TUNE]%b Rebalanceando HCR principal + extras...\n' "$C_GOLD" "$C_RESET"
    retune_all_services "$planned_count" || return 1
  fi
  return 0
}

service_is_active() { systemctl is-active --quiet "${SERVICE_NAME}.service" 2>/dev/null; }
service_is_installed() { [ -L "$UNIT_LINK_PATH" ] || [ -f "$UNIT_SOURCE_PATH" ]; }

record_firewall_port() {
  local p="$1"
  touch "$FIREWALL_STATE_PATH"; chmod 0600 "$FIREWALL_STATE_PATH"
  grep -qx "$p" "$FIREWALL_STATE_PATH" 2>/dev/null || printf '%s\n' "$p" >> "$FIREWALL_STATE_PATH"
}

forget_firewall_port() {
  local p="$1" tmp
  [ -f "$FIREWALL_STATE_PATH" ] || return 0
  tmp="$(mktemp "${RUNTIME_DIR}/.fw.XXXXXX")"
  grep -vx "$p" "$FIREWALL_STATE_PATH" > "$tmp" || true
  mv -f "$tmp" "$FIREWALL_STATE_PATH"; chmod 0600 "$FIREWALL_STATE_PATH"
}

firewall_open() {
  local p="$1"
  validate_port "$p" || fail "Puerto inválido: $p"
  p="$((10#$p))"
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
    ufw allow "${p}/tcp" >/dev/null
    record_firewall_port "$p"
    printf '%b[OK]%b Puerto TCP %s abierto en UFW.\n' "$C_GREEN" "$C_RESET" "$p"
  elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
    firewall-cmd --permanent --add-port="${p}/tcp" >/dev/null
    firewall-cmd --reload >/dev/null
    record_firewall_port "$p"
    printf '%b[OK]%b Puerto TCP %s abierto en firewalld.\n' "$C_GREEN" "$C_RESET" "$p"
  else
    printf '%b[INFO]%b No hay UFW/firewalld activo. HCR ya escucha en TCP %s; revisa el firewall del proveedor VPS si aplica.\n' "$C_GOLD" "$C_RESET" "$p"
  fi
}

firewall_close() {
  local p="$1"
  validate_port "$p" || fail "Puerto inválido: $p"
  p="$((10#$p))"
  if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
    ufw --force delete allow "${p}/tcp" >/dev/null 2>&1 || true
    forget_firewall_port "$p"
    printf '%b[OK]%b Regla TCP %s eliminada de UFW.\n' "$C_GREEN" "$C_RESET" "$p"
  elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
    firewall-cmd --permanent --remove-port="${p}/tcp" >/dev/null 2>&1 || true
    firewall-cmd --reload >/dev/null 2>&1 || true
    forget_firewall_port "$p"
    printf '%b[OK]%b Regla TCP %s eliminada de firewalld.\n' "$C_GREEN" "$C_RESET" "$p"
  else
    printf '%b[INFO]%b No hay UFW/firewalld activo; no se modificó el firewall.\n' "$C_GOLD" "$C_RESET"
  fi
}


uninstall_service() {
  load_state
  local old_port="$PORT" p t f d snapshot=""

  # Primero retirar todos los listeners HCR adicionales administrados.
  if [ -f "$EXTRA_STATE_PATH" ]; then
    snapshot="$(mktemp "${RUNTIME_DIR}/.extra-uninstall.XXXXXX")"
    cp -f "$EXTRA_STATE_PATH" "$snapshot"
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      if extra_port_exists "$p"; then remove_extra_service "$p" true || true; fi
    done < "$snapshot"
    rm -f "$snapshot"
  fi

  if service_is_installed; then
    systemctl disable --now "${SERVICE_NAME}.service" >/dev/null 2>&1 || true
    if [ -L "$UNIT_LINK_PATH" ] && [ "$(readlink -- "$UNIT_LINK_PATH")" = "$UNIT_SOURCE_PATH" ]; then rm -f -- "$UNIT_LINK_PATH"; fi
    rm -f -- "$UNIT_SOURCE_PATH"
    systemctl daemon-reload
    systemctl reset-failed "${SERVICE_NAME}.service" >/dev/null 2>&1 || true
  fi
  rm -f -- "$STATE_PATH" "$EXTRA_STATE_PATH" "$AUTOTUNE_STATE_PATH"
  printf '%b[OK]%b HCR principal y todos los listeners HCR adicionales fueron desinstalados. El binario oficial y el manager se conservaron.\n' "$C_GREEN" "$C_RESET"
  if [ -f "$FIREWALL_STATE_PATH" ] && grep -qx "$old_port" "$FIREWALL_STATE_PATH" 2>/dev/null; then
    firewall_close "$old_port" || true
  fi
}


status_line() {
  load_state
  local svc="OFF" svc_color="$C_RED"
  if service_is_active; then svc="ON"; svc_color="$C_GREEN"; fi
  printf '%b%s%b\n' "$C_GOLD" "$BAR" "$C_RESET"
  printf ' Principal: %b%s%b | Puerto: %b%s%b | Transport: %b%s%b\n' "$svc_color" "$svc" "$C_RESET" "$C_CYAN" "$PORT" "$C_RESET" "$C_CYAN" "$TRANSPORT" "$C_RESET"
  printf ' Rendimiento principal: Frame %b%s%b | Poll %b%s%b\n' "$C_CYAN" "$MAX_DOWNLOAD_FRAME" "$C_RESET" "$C_CYAN" "$DOWNLOAD_POLL_TIMEOUT" "$C_RESET"
  show_extra_ports
  show_autotune_summary "$(managed_listener_count)"
  printf '%b%s%b\n' "$C_GOLD" "$BAR" "$C_RESET"
}


show_menu() {
  clear_screen
  load_state
  printf '%b%s%b\n' "$C_GOLD" "$BAR" "$C_RESET"
  printf '%b      HCR / NEW-GOLDEN ADM PRO  -  MENÚ DE INSTALACIONES%b\n' "$C_WHITE" "$C_RESET"
  printf '%b              Manager PRO v%s AUTO-TUNE MULTI-PORT%b\n' "$C_GRAY" "$MANAGER_VERSION" "$C_RESET"

  # Estado y capacidad siempre arriba, antes de las opciones del menú.
  status_line

  printf '  %b[1]%b Instalación rápida HCR Plain %b[PUERTO Y PERFIL A ELEGIR]%b (default :%s)\n' "$C_CYAN" "$C_RESET" "$C_GREEN" "$C_RESET" "$DEFAULT_PORT"
  printf '  %b[2]%b Instalación personalizada principal (Plain/TLS/Auto)\n' "$C_CYAN" "$C_RESET"
  printf '  %b[3]%b Cambiar puerto HCR principal\n' "$C_CYAN" "$C_RESET"
  printf '  %b[4]%b Cambiar transport HCR principal\n' "$C_CYAN" "$C_RESET"
  printf '  %b[5]%b Agregar puerto HCR adicional %b[LISTENER REAL]%b\n' "$C_CYAN" "$C_RESET" "$C_GREEN" "$C_RESET"
  printf '  %b[6]%b Eliminar puerto HCR adicional\n' "$C_CYAN" "$C_RESET"
  printf '  %b[7]%b Ver puertos HCR activos\n' "$C_CYAN" "$C_RESET"
  printf '  %b[8]%b Abrir puerto TCP solo en firewall\n' "$C_CYAN" "$C_RESET"
  printf '  %b[9]%b Cerrar puerto TCP solo en firewall\n' "$C_CYAN" "$C_RESET"
  printf ' %b[10]%b Estado completo HCR\n' "$C_CYAN" "$C_RESET"
  printf ' %b[11]%b Reiniciar HCR principal + extras\n' "$C_CYAN" "$C_RESET"
  printf ' %b[12]%b Ver registros HCR\n' "$C_CYAN" "$C_RESET"
  printf ' %b[13]%b Desinstalar HCR completo\n' "$C_CYAN" "$C_RESET"
  printf ' %b[14]%b Recalcular AUTO-TUNE CPU/RAM\n' "$C_CYAN" "$C_RESET"
  printf ' %b[15]%b Editar perfil Frame/Poll de puerto instalado\n' "$C_CYAN" "$C_RESET"
  printf '  %b[0]%b Salir\n' "$C_CYAN" "$C_RESET"
  printf '%b%s%b\n' "$C_GOLD" "$BAR" "$C_RESET"
}

install_quick() {
  local choice="" profile_rc=0
  load_state
  # Si ya hay principal, ofrecer su puerto real para evitar reinicios/sorpresas.
  if read_main_runtime_profile; then
    PORT="$MAIN_RUNTIME_PORT"
    MAX_DOWNLOAD_FRAME="$MAIN_RUNTIME_FRAME"
    DOWNLOAD_POLL_TIMEOUT="$MAIN_RUNTIME_POLL"
  fi
  printf '\n%bINSTALACIÓN RÁPIDA HCR PLAIN%b\n' "$C_GOLD" "$C_RESET"
  prompt_read choice "Puerto HCR Plain [${PORT}]: " || return 1
  if [ -n "$choice" ]; then
    validate_port "$choice" || { fail "Puerto inválido. Usa 1..65535."; return 1; }
    PORT="$((10#$choice))"
  fi
  TRANSPORT="plain"
  choose_existing_performance_profile "$MAX_DOWNLOAD_FRAME" "$DOWNLOAD_POLL_TIMEOUT" || profile_rc=$?
  [ "$profile_rc" -eq 2 ] && { echo "Cancelado, no se cambió el servicio."; return 0; }
  [ "$profile_rc" -eq 0 ] || return 1
  MAX_DOWNLOAD_FRAME="$PERF_FRAME"
  DOWNLOAD_POLL_TIMEOUT="$PERF_POLL"
  printf '\nInstalando HCR Plain en TCP %s con perfil %s / %s...\n' "$PORT" "$MAX_DOWNLOAD_FRAME" "$DOWNLOAD_POLL_TIMEOUT"
  if ! install_service; then
    printf '%b[ERROR]%b La instalación principal no pasó la comprobación de salud.\n' "$C_RED" "$C_RESET"
    return 1
  fi
  firewall_open "$PORT" || true
  printf '%b[OK]%b HCR instalado, activo y AUTO-TUNED.\n' "$C_GREEN" "$C_RESET"
  show_autotune_summary "$(managed_listener_count)"
}

choose_transport() {
  local opt=""
  printf '\n  [1] plain  - recomendado para NEW-GOLDEN / SpeiGo HCR Plain\n'
  printf '  [2] tls\n'
  printf '  [3] auto   - acepta Plain y TLS\n'
  prompt_read opt "Transport [1-3]: " || return 1
  case "$opt" in 1) TRANSPORT="plain" ;; 2) TRANSPORT="tls" ;; 3) TRANSPORT="auto" ;; *) fail "Opción inválida." ;; esac
}

choose_frame() {
  local opt="" custom=""
  printf '\n  [1] 16384  Máximo rendimiento / recomendado\n'
  printf '  [2] 12288  Balanceado\n'
  printf '  [3] 8192   Conservador\n'
  printf '  [4] 6144   Perfil anterior / rollback\n'
  printf '  [5] Manual (512-16384)\n'
  prompt_read opt "MAX_DOWNLOAD_FRAME [1-5]: " || return 1
  case "$opt" in
    1) MAX_DOWNLOAD_FRAME="16384" ;; 2) MAX_DOWNLOAD_FRAME="12288" ;; 3) MAX_DOWNLOAD_FRAME="8192" ;; 4) MAX_DOWNLOAD_FRAME="6144" ;;
    5) prompt_read custom "Valor [512-16384]: " || return 1; validate_frame "$custom" || fail "Frame inválido."; MAX_DOWNLOAD_FRAME="$((10#$custom))" ;;
    *) fail "Opción inválida." ;;
  esac
}

custom_install() {
  local value="" profile_rc=0
  load_state
  if read_main_runtime_profile; then
    PORT="$MAIN_RUNTIME_PORT"
    MAX_DOWNLOAD_FRAME="$MAIN_RUNTIME_FRAME"
    DOWNLOAD_POLL_TIMEOUT="$MAIN_RUNTIME_POLL"
  fi
  prompt_read value "Puerto HCR [${PORT}]: " || return 1
  [ -n "$value" ] && { validate_port "$value" || { fail "Puerto inválido."; return 1; }; PORT="$((10#$value))"; }
  choose_transport || return 1
  choose_existing_performance_profile "$MAX_DOWNLOAD_FRAME" "$DOWNLOAD_POLL_TIMEOUT" || profile_rc=$?
  [ "$profile_rc" -eq 2 ] && { echo "Cancelado, no se cambió el servicio."; return 0; }
  [ "$profile_rc" -eq 0 ] || return 1
  MAX_DOWNLOAD_FRAME="$PERF_FRAME"
  DOWNLOAD_POLL_TIMEOUT="$PERF_POLL"
  if [ "$TRANSPORT" = "tls" ] || [ "$TRANSPORT" = "auto" ]; then
    printf 'TLS/Auto: se reutilizará un certificado válido existente o se preparará uno de forma segura.\n'
  fi
  if ! install_service; then
    printf '%b[ERROR]%b La instalación personalizada no pasó la comprobación de salud.\n' "$C_RED" "$C_RESET"
    return 1
  fi
  firewall_open "$PORT" || true
  printf '%b[OK]%b Instalación personalizada completada.\n' "$C_GREEN" "$C_RESET"
}


change_port() {
  service_is_installed || { fail "HCR principal aún no está instalado."; return 1; }
  load_state
  local old="$PORT" value=""
  prompt_read value "Nuevo puerto HCR principal [actual ${PORT}]: " || return 1
  validate_port "$value" || { fail "Puerto inválido."; return 1; }
  PORT="$((10#$value))"
  [ "$PORT" = "$old" ] && { echo "El puerto principal ya es $PORT."; return 0; }
  if extra_port_exists "$PORT"; then
    fail "TCP $PORT ya pertenece a un listener HCR adicional. Elimina ese extra primero o elige otro puerto."
    PORT="$old"
    return 1
  fi
  if port_has_listener "$PORT"; then
    fail "TCP $PORT ya está ocupado por otro listener."
    PORT="$old"
    return 1
  fi
  if ! install_service; then
    PORT="$old"
    load_state
    printf '%b[ERROR]%b No se cambió el puerto principal porque el nuevo listener no quedó estable.\n' "$C_RED" "$C_RESET"
    return 1
  fi
  firewall_open "$PORT" || true
  printf '%b[OK]%b HCR principal cambió de TCP %s a TCP %s.\n' "$C_GREEN" "$C_RESET" "$old" "$PORT"
  if [ -f "$FIREWALL_STATE_PATH" ] && grep -qx "$old" "$FIREWALL_STATE_PATH" 2>/dev/null; then firewall_close "$old" || true; fi
}

change_transport() {
  service_is_installed || { fail "HCR aún no está instalado."; return 1; }
  load_state
  local old="$TRANSPORT"
  choose_transport || return 1
  [ "$TRANSPORT" = "$old" ] && { echo "El transport ya es $TRANSPORT."; return 0; }
  if ! install_service; then
    TRANSPORT="$old"
    load_state
    printf '%b[ERROR]%b No se cambió el transport porque el servicio no quedó estable.\n' "$C_RED" "$C_RESET"
    return 1
  fi
  printf '%b[OK]%b Transport cambiado: %s -> %s.\n' "$C_GREEN" "$C_RESET" "$old" "$TRANSPORT"
}

change_performance() {
  service_is_installed || { fail "HCR aún no está instalado."; return 1; }
  load_state
  local old_frame="$MAX_DOWNLOAD_FRAME" old_poll="$DOWNLOAD_POLL_TIMEOUT" value=""
  choose_frame || return 1
  prompt_read value "DOWNLOAD_POLL_TIMEOUT [actual ${DOWNLOAD_POLL_TIMEOUT}, recomendado 8s]: " || return 1
  [ -n "$value" ] && { validate_timeout "$value" || { fail "Timeout inválido."; return 1; }; DOWNLOAD_POLL_TIMEOUT="$value"; }
  if ! install_service; then
    MAX_DOWNLOAD_FRAME="$old_frame"
    DOWNLOAD_POLL_TIMEOUT="$old_poll"
    load_state
    printf '%b[ERROR]%b No se aplicó el perfil porque el servicio no quedó estable.\n' "$C_RED" "$C_RESET"
    return 1
  fi
  printf '%b[OK]%b Rendimiento actualizado: Frame %s -> %s | Poll %s -> %s.\n' "$C_GREEN" "$C_RESET" "$old_frame" "$MAX_DOWNLOAD_FRAME" "$old_poll" "$DOWNLOAD_POLL_TIMEOUT"
}


normalize_poll_input() {
  local raw="$1"
  if [[ "$raw" =~ ^[1-9][0-9]*$ ]]; then
    printf '%ss' "$raw"
  else
    printf '%s' "$raw"
  fi
}

choose_existing_performance_profile() {
  local current_frame="$1" current_poll="$2" opt="" value="" normalized=""
  PERF_FRAME="$current_frame"
  PERF_POLL="$current_poll"

  printf '\n%bPERFIL HCR DEL PUERTO%b\n' "$C_GOLD" "$C_RESET"
  printf ' Actual: Frame %s | Poll %s\n' "$current_frame" "$current_poll"
  printf '  [1] 16384 / 8s  · Referencia actual\n'
  printf '  [2] 16384 / 6s  · Móvil balanceado\n'
  printf '  [3] 16384 / 4s  · Móvil reactivo\n'
  printf '  [4] 12288 / 6s  · Balance intermedio\n'
  printf '  [5] 8192  / 6s  · Menor presión\n'
  printf '  [6] 6144  / 8s  · Baseline install.sh oficial\n'
  printf '  [7] 4000  / 6s  · Móvil ligero / laboratorio\n'
  printf '  [8] Manual       · Frame 512..16384 + Poll ms/s/m\n'
  printf '  [0] Cancelar\n'
  prompt_read opt "Perfil [0-8]: " || return 1

  case "$opt" in
    1) PERF_FRAME="16384"; PERF_POLL="8s" ;;
    2) PERF_FRAME="16384"; PERF_POLL="6s" ;;
    3) PERF_FRAME="16384"; PERF_POLL="4s" ;;
    4) PERF_FRAME="12288"; PERF_POLL="6s" ;;
    5) PERF_FRAME="8192";  PERF_POLL="6s" ;;
    6) PERF_FRAME="6144";  PERF_POLL="8s" ;;
    7) PERF_FRAME="4000";  PERF_POLL="6s" ;;
    8)
      prompt_read value "MAX_DOWNLOAD_FRAME [actual ${current_frame}]: " || return 1
      if [ -n "$value" ]; then
        validate_frame "$value" || { fail "Frame inválido. Usa 512..16384."; return 1; }
        PERF_FRAME="$((10#$value))"
      fi
      prompt_read value "DOWNLOAD_POLL_TIMEOUT [actual ${current_poll}; 6 también vale como 6s]: " || return 1
      if [ -n "$value" ]; then
        normalized="$(normalize_poll_input "$value")"
        validate_timeout "$normalized" || { fail "Poll inválido. Ejemplos: 1500ms, 4s, 6, 8s, 1m."; return 1; }
        PERF_POLL="$normalized"
      fi
      ;;
    0) return 2 ;;
    *) fail "Opción inválida."; return 1 ;;
  esac

  validate_frame "$PERF_FRAME" || { fail "Frame inválido."; return 1; }
  validate_timeout "$PERF_POLL" || { fail "Poll inválido."; return 1; }
  return 0
}

confirm_profile_restart() {
  local p="$1" ans=""
  printf '%bAVISO:%b se reiniciará SOLO el listener HCR TCP %s; las sesiones de ese puerto reconectarán.\n' "$C_GOLD" "$C_RESET" "$p"
  prompt_read ans "¿Aplicar el perfil? [s/N]: " || return 1
  case "$ans" in s|S|si|SI|sí|Sí) return 0 ;; *) echo "Cancelado."; return 1 ;; esac
}

edit_main_listener_profile() {
  load_state
  local saved_port="$PORT" saved_transport="$TRANSPORT" saved_frame="$MAX_DOWNLOAD_FRAME" saved_poll="$DOWNLOAD_POLL_TIMEOUT"
  local old_frame="" old_poll="" runtime_port="" runtime_transport="" unit_file=""
  local backup="" profile_rc=0

  if ! read_main_runtime_profile; then
    fail "No pude leer el ExecStart real de hcr-server.service. Revisa [10] Estado completo HCR."
    return 1
  fi

  runtime_port="$MAIN_RUNTIME_PORT"
  runtime_transport="$MAIN_RUNTIME_TRANSPORT"
  old_frame="$MAIN_RUNTIME_FRAME"
  old_poll="$MAIN_RUNTIME_POLL"
  unit_file="$MAIN_RUNTIME_FRAGMENT"

  if [ "$runtime_port" != "$saved_port" ] || [ "$old_frame" != "$saved_frame" ] || [ "$old_poll" != "$saved_poll" ]; then
    printf '%b[SYNC]%b El estado guardado decía TCP %s Frame %s/Poll %s, pero systemd REAL usa TCP %s Frame %s/Poll %s.\n' \
      "$C_GOLD" "$C_RESET" "$saved_port" "$saved_frame" "$saved_poll" "$runtime_port" "$old_frame" "$old_poll"
    printf ' Se editará el servicio que systemd realmente tiene cargado: %s\n' "$unit_file"
  fi

  choose_existing_performance_profile "$old_frame" "$old_poll" || profile_rc=$?
  [ "$profile_rc" -eq 2 ] && return 0
  [ "$profile_rc" -eq 0 ] || return 1
  [ "$PERF_FRAME" = "$old_frame" ] && [ "$PERF_POLL" = "$old_poll" ] && {
    echo "El HCR principal real ya usa Frame $old_frame / Poll $old_poll."
    return 0
  }
  confirm_profile_restart "$runtime_port" || return 0

  backup="$(mktemp "${RUNTIME_DIR}/.hcr-main-runtime-profile.XXXXXX.bak")" || { fail "No se pudo crear respaldo temporal."; return 1; }
  cp -p -- "$unit_file" "$backup" || { rm -f "$backup"; fail "No se pudo respaldar la unidad principal real."; return 1; }

  if ! patch_unit_profile_copy "$unit_file" "$PERF_FRAME" "$PERF_POLL"; then
    rm -f "$backup"
    fail "No se pudo preparar el cambio Frame/Poll sin alterar el resto de la unidad."
    return 1
  fi

  if ! mv -f -- "$PROFILE_PATCH_TEMP" "$unit_file"; then
    PROFILE_PATCH_TEMP=""
    cp -p -- "$backup" "$unit_file" || true
    rm -f "$backup"
    fail "No se pudo actualizar la unidad principal real."
    return 1
  fi
  PROFILE_PATCH_TEMP=""

  if ! systemctl daemon-reload >/dev/null 2>&1 ||
     ! systemctl restart "${SERVICE_NAME}.service" ||
     ! verify_service_health_port "$runtime_port"; then
    printf '%b[ROLLBACK]%b El nuevo perfil no quedó sano; restaurando Frame %s / Poll %s.\n' "$C_RED" "$C_RESET" "$old_frame" "$old_poll"
    cp -p -- "$backup" "$unit_file" || true
    systemctl daemon-reload >/dev/null 2>&1 || true
    systemctl restart "${SERVICE_NAME}.service" >/dev/null 2>&1 || true
    verify_service_health_port "$runtime_port" >/dev/null 2>&1 || true
    rm -f "$backup"
    PORT="$saved_port"; TRANSPORT="$saved_transport"; MAX_DOWNLOAD_FRAME="$saved_frame"; DOWNLOAD_POLL_TIMEOUT="$saved_poll"
    return 1
  fi

  rm -f "$backup"
  # Sincronizar el estado del submenú con el servicio real que quedó activo.
  PORT="$runtime_port"
  TRANSPORT="$runtime_transport"
  MAX_DOWNLOAD_FRAME="$PERF_FRAME"
  DOWNLOAD_POLL_TIMEOUT="$PERF_POLL"
  save_state
  printf '%b[OK]%b TCP %s actualizado: Frame %s -> %s | Poll %s -> %s.\n' \
    "$C_GREEN" "$C_RESET" "$PORT" "$old_frame" "$MAX_DOWNLOAD_FRAME" "$old_poll" "$DOWNLOAD_POLL_TIMEOUT"
  printf ' Se conservaron byte por byte todos los demás argumentos ExecStart (sesiones, conexiones, stats, target, etc.).\n'
}

edit_extra_listener_profile() {
  local target="$1" line="" p="" t="" old_frame="" old_poll="" count backup="" src="" svc="" profile_rc=0
  line="$(extra_get_line "$target" 2>/dev/null || true)"
  [ -n "$line" ] || { fail "TCP $target no está registrado como listener HCR adicional."; return 1; }
  read -r p t old_frame old_poll <<< "$line"
  validate_port "$p" && validate_transport "$t" && validate_frame "$old_frame" && validate_timeout "$old_poll" || {
    fail "El estado guardado de TCP $target no es válido."
    return 1
  }

  choose_existing_performance_profile "$old_frame" "$old_poll" || profile_rc=$?
  [ "$profile_rc" -eq 2 ] && return 0
  [ "$profile_rc" -eq 0 ] || return 1
  [ "$PERF_FRAME" = "$old_frame" ] && [ "$PERF_POLL" = "$old_poll" ] && {
    echo "TCP $p ya usa Frame $old_frame / Poll $old_poll."
    return 0
  }
  confirm_profile_restart "$p" || return 0

  count="$(managed_listener_count)"
  src="$(extra_unit_source_path "$p")"
  svc="$(extra_service_name "$p").service"
  [ -f "$src" ] || { fail "No existe la unidad administrada para TCP $p: $src"; return 1; }
  backup="$(mktemp "${RUNTIME_DIR}/.hcr-extra-${p}-profile.XXXXXX.bak")" || { fail "No se pudo crear respaldo temporal."; return 1; }
  cp -f -- "$src" "$backup" || { rm -f "$backup"; fail "No se pudo respaldar la unidad TCP $p."; return 1; }

  if ! render_extra_unit "$p" "$t" "$PERF_FRAME" "$PERF_POLL" "$count"; then
    cp -f -- "$backup" "$src" || true
    rm -f "$backup"
    return 1
  fi

  if ! systemctl daemon-reload >/dev/null 2>&1 ||
     ! systemctl restart "$svc" ||
     ! verify_extra_health "$p"; then
    printf '%b[ROLLBACK]%b TCP %s no quedó sano; restaurando Frame %s / Poll %s.\n' "$C_RED" "$C_RESET" "$p" "$old_frame" "$old_poll"
    cp -f -- "$backup" "$src" || true
    systemctl daemon-reload >/dev/null 2>&1 || true
    systemctl restart "$svc" >/dev/null 2>&1 || true
    verify_extra_health "$p" >/dev/null 2>&1 || true
    rm -f "$backup"
    return 1
  fi

  if ! extra_state_add "$p" "$t" "$PERF_FRAME" "$PERF_POLL"; then
    printf '%b[ROLLBACK]%b No se pudo guardar el nuevo perfil de TCP %s; restaurando.\n' "$C_RED" "$C_RESET" "$p"
    cp -f -- "$backup" "$src" || true
    systemctl daemon-reload >/dev/null 2>&1 || true
    systemctl restart "$svc" >/dev/null 2>&1 || true
    extra_state_add "$p" "$t" "$old_frame" "$old_poll" || true
    rm -f "$backup"
    return 1
  fi

  rm -f "$backup"
  printf '%b[OK]%b TCP %s actualizado: Frame %s -> %s | Poll %s -> %s.\n' \
    "$C_GREEN" "$C_RESET" "$p" "$old_frame" "$PERF_FRAME" "$old_poll" "$PERF_POLL"
  printf ' Los demás listeners HCR, firewall y AUTO-TUNE no fueron modificados.\n'
}

edit_installed_port_profile() {
  service_is_installed || { fail "HCR principal aún no está instalado."; return 1; }
  load_state
  local target="" saved_port="$PORT" saved_frame="$MAX_DOWNLOAD_FRAME" saved_poll="$DOWNLOAD_POLL_TIMEOUT"

  # Para la opción de edición, mostrar como principal el servicio que systemd
  # realmente está ejecutando. Esto evita el falso caso guardado :8880 vs real :8080.
  if read_main_runtime_profile; then
    if [ "$MAIN_RUNTIME_PORT" != "$PORT" ] || [ "$MAIN_RUNTIME_FRAME" != "$MAX_DOWNLOAD_FRAME" ] || [ "$MAIN_RUNTIME_POLL" != "$DOWNLOAD_POLL_TIMEOUT" ]; then
      printf '\n%b[SYNC]%b Estado local: TCP %s Frame %s/Poll %s · systemd REAL: TCP %s Frame %s/Poll %s\n' \
        "$C_GOLD" "$C_RESET" "$saved_port" "$saved_frame" "$saved_poll"         "$MAIN_RUNTIME_PORT" "$MAIN_RUNTIME_FRAME" "$MAIN_RUNTIME_POLL"
    fi
    PORT="$MAIN_RUNTIME_PORT"
    TRANSPORT="$MAIN_RUNTIME_TRANSPORT"
    MAX_DOWNLOAD_FRAME="$MAIN_RUNTIME_FRAME"
    DOWNLOAD_POLL_TIMEOUT="$MAIN_RUNTIME_POLL"
  fi

  printf '\n%bPUERTOS HCR ADMINISTRADOS%b\n' "$C_GOLD" "$C_RESET"
  printf '  Principal REAL TCP %s | %s | Frame %s | Poll %s\n' "$PORT" "$TRANSPORT" "$MAX_DOWNLOAD_FRAME" "$DOWNLOAD_POLL_TIMEOUT"
  show_extra_ports
  printf '\n'
  prompt_read target "Puerto HCR cuyo perfil quieres editar: " || return 1
  validate_port "$target" || { fail "Puerto inválido."; return 1; }
  target="$((10#$target))"

  if [ "$target" = "$PORT" ]; then
    edit_main_listener_profile
  elif extra_port_exists "$target"; then
    edit_extra_listener_profile "$target"
  else
    fail "TCP $target no es un listener HCR administrado/activo. Usa [7] para ver los puertos activos."
    return 1
  fi
}

manual_open_port() { local p=""; prompt_read p "Puerto TCP a abrir: " || return 1; firewall_open "$p"; }
manual_close_port() { local p=""; prompt_read p "Puerto TCP a cerrar: " || return 1; firewall_close "$p"; }


show_status() {
  load_state
  printf '\n'; status_line
  printf ' Binario: %s\n' "$("$BINARY_PATH" -version 2>/dev/null || echo desconocido)"
  if service_is_installed; then
    printf '\n%b--- HCR PRINCIPAL ---%b\n' "$C_GOLD" "$C_RESET"
    systemctl status --no-pager --full "${SERVICE_NAME}.service" 2>/dev/null | sed -n '1,12p' || true
  else
    echo ' HCR principal no está instalado.'
  fi
  local p t f d
  if [ -f "$EXTRA_STATE_PATH" ]; then
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      printf '\n%b--- HCR EXTRA TCP %s ---%b\n' "$C_GOLD" "$p" "$C_RESET"
      systemctl status --no-pager --full "$(extra_service_name "$p").service" 2>/dev/null | sed -n '1,10p' || true
    done < "$EXTRA_STATE_PATH"
  fi
}


restart_hcr() {
  service_is_installed || { fail "HCR principal aún no está instalado."; return 1; }
  load_state
  if ! systemctl restart "${SERVICE_NAME}.service"; then
    fail "No se pudo reiniciar HCR principal."
    return 1
  fi
  verify_service_health || return 1

  local p t f d
  if [ -f "$EXTRA_STATE_PATH" ]; then
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      if ! systemctl restart "$(extra_service_name "$p").service"; then
        fail "No se pudo reiniciar HCR extra TCP $p."
        return 1
      fi
      verify_extra_health "$p" || return 1
    done < "$EXTRA_STATE_PATH"
  fi
  printf '%b[OK]%b HCR principal y todos los puertos adicionales fueron reiniciados correctamente.\n' "$C_GREEN" "$C_RESET"
}

show_logs() {
  service_is_installed || { fail "HCR principal aún no está instalado."; return 1; }
  printf '%bÚltimas 80 líneas HCR principal:%b\n' "$C_GOLD" "$C_RESET"
  journalctl -u "${SERVICE_NAME}.service" -n 80 --no-pager || true
  local p t f d
  if [ -f "$EXTRA_STATE_PATH" ]; then
    while read -r p t f d; do
      validate_port "${p:-}" || continue
      printf '\n%bÚltimas 40 líneas HCR extra TCP %s:%b\n' "$C_GOLD" "$p" "$C_RESET"
      journalctl -u "$(extra_service_name "$p").service" -n 40 --no-pager || true
    done < "$EXTRA_STATE_PATH"
  fi
}


confirm_uninstall() {
  local ans=""
  prompt_read ans "¿Desinstalar HCR principal y TODOS los puertos HCR adicionales? [s/N]: " || return 1
  case "$ans" in s|S|si|SI|sí|Sí) uninstall_service ;; *) echo "Cancelado." ;; esac
}


menu_loop() {
  while :; do
    show_menu
    local opt=""
    prompt_read opt "Selecciona una opción: " || return 0
    printf '\n'
    case "$opt" in
      1) install_quick || true ;;
      2) custom_install || true ;;
      3) change_port || true ;;
      4) change_transport || true ;;
      5) add_extra_port_menu || true ;;
      6) remove_extra_port_menu || true ;;
      7) printf '\n'; show_extra_ports ;;
      8) manual_open_port || true ;;
      9) manual_close_port || true ;;
      10) show_status || true ;;
      11) restart_hcr || true ;;
      12) show_logs || true ;;
      13) confirm_uninstall || true ;;
      14) manual_autotune || true ;;
      15) edit_installed_port_profile || true ;;
      0) clear_screen; echo "Saliendo de HCR / NEW-GOLDEN ADM PRO Manager."; return 0 ;;
      *) printf '%bOpción inválida.%b\n' "$C_RED" "$C_RESET" ;;
    esac
    printf '\n'
    pause_menu
  done
}

parse_cli() {
  if [ "$#" -eq 0 ]; then ACTION="menu"; return 0; fi
  case "$1" in menu|--menu) ACTION="menu"; shift ;; esac
  [ "$ACTION" = "menu" ] && [ "$#" -eq 0 ] && return 0
  ACTION="install"
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --port) [ "$#" -ge 2 ] || { fail "--port requiere un valor."; return 1; }; PORT="$2"; shift 2 ;;
      --transport) [ "$#" -ge 2 ] || { fail "--transport requiere un valor."; return 1; }; TRANSPORT="$2"; shift 2 ;;
      --max-download-frame) [ "$#" -ge 2 ] || { fail "--max-download-frame requiere un valor."; return 1; }; MAX_DOWNLOAD_FRAME="$2"; shift 2 ;;
      --download-poll-timeout) [ "$#" -ge 2 ] || { fail "--download-poll-timeout requiere un valor."; return 1; }; DOWNLOAD_POLL_TIMEOUT="$2"; shift 2 ;;
      --uninstall) ACTION="uninstall"; shift ;;
      -h|--help) usage; exit 0 ;;
      *) fail "Opción desconocida: $1"; return 1 ;;
    esac
  done
}

main() {
  parse_cli "$@"
  require_environment
  acquire_install_lock
  case "$ACTION" in
    menu) menu_loop ;;
    uninstall) uninstall_service ;;
    install)
      validate_port "$PORT" || fail "Puerto inválido: $PORT"
      validate_transport "$TRANSPORT" || fail "Transport inválido: $TRANSPORT"
      validate_frame "$MAX_DOWNLOAD_FRAME" || fail "MAX_DOWNLOAD_FRAME inválido."
      validate_timeout "$DOWNLOAD_POLL_TIMEOUT" || fail "DOWNLOAD_POLL_TIMEOUT inválido."
      install_service
      printf '%b[OK]%b HCR instalado: TCP %s | %s | Frame %s | Poll %s\n' "$C_GREEN" "$C_RESET" "$PORT" "$TRANSPORT" "$MAX_DOWNLOAD_FRAME" "$DOWNLOAD_POLL_TIMEOUT"
      show_autotune_summary "$(managed_listener_count)"
      ;;
  esac
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
  main "$@"
fi
