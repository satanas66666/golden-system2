#!/usr/bin/env bash
set -Euo pipefail

MANAGER_VERSION="1.2.1-golden-portflow"
ENGINE_VERSION="1.0.0"
PROTOCOL_NAME="XHTTP TLS/H2"
SERVICE="superflash-h2connect.service"
BASE="/etc/superflash-h2connect"
TLS_DIR="$BASE/tls"
CONFIG="$BASE/config"
BIN="/usr/local/bin/superflash-h2connect-server"
UNIT="/etc/systemd/system/$SERVICE"
EXTRA_UNIT_PREFIX="/etc/systemd/system/superflash-h2connect-port"
ACME="/root/.acme.sh/acme.sh"
DEFAULT_PORT=""
DEFAULT_SSH_PORT=22
SHA_AMD64="41b298d658e156c1d04a02d50df709abac66e03906533543eba762ebd36ec03d"
SHA_ARM64="69d1265160f73b0a5a3fa9e7c1ebd18d5b2ed203e77fd150b2269b82614cb216"
GZ_SHA_AMD64="715e056a405acea3ee113ce625fe2467550737fdcb80686e0f7d77cd3c89b1e3"
GZ_SHA_ARM64="8226fb461771afdf747d8a6505f547d850866feac4633923b642c56b2e086857"
PAYLOAD_REPO="${SUPERFLASH_H2_REPO:-apksdemons/SSH-H2-CONNECT-NEW-GOLDEN}"
PAYLOAD_BRANCH="${SUPERFLASH_H2_BRANCH:-main}"
LEGACY_XHTTP_BASE="/etc/superflash-xhttp"
LEGACY_XHTTP_CONF="$LEGACY_XHTTP_BASE/config"
LEGACY_XHTTP_TLS="$LEGACY_XHTTP_BASE/tls"
COMPETITORS=("superflash-xhttp.service" "superflash-xhttp-native.service")

red='\033[1;31m'; green='\033[1;32m'; cyan='\033[1;36m'; yellow='\033[1;33m'; reset='\033[0m'

need_root(){ [ "${EUID:-$(id -u)}" -eq 0 ] || { echo -e "${red}Ejecuta como root.${reset}"; exit 1; }; }
interactive_tty_ready(){ [ -c /dev/tty ] && { : </dev/tty; } 2>/dev/null; }
require_interactive_tty(){ interactive_tty_ready || { echo -e "${red}Esta acción necesita /dev/tty.${reset}"; return 1; }; }
prompt_read(){ local __v="$1" __p="$2"; require_interactive_tty || return 1; IFS= read -r -p "$__p" "$__v" </dev/tty; }
pause(){ echo; prompt_read _ "Presiona ENTER para continuar..." || true; }
have(){ command -v "$1" >/dev/null 2>&1; }
valid_port(){ [[ "${1:-}" =~ ^[0-9]+$ ]] && [ "$1" -ge 1 ] && [ "$1" -le 65535 ]; }
valid_domain(){ [[ "${1:-}" =~ ^([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}$ ]]; }
normalize_ports(){ local raw="${1:-}" p out=""; raw="${raw//,/ }"; for p in $raw; do valid_port "$p" || continue; case " $out " in *" $p "*) ;; *) out="${out:+$out }$p";; esac; done; printf '%s' "$out"; }
list_has_port(){ case " ${1:-} " in *" $2 "*) return 0;; *) return 1;; esac; }
list_add_port(){ local l; l="$(normalize_ports "${1:-}")"; list_has_port "$l" "$2" && printf '%s' "$l" || printf '%s' "${l:+$l }$2"; }
list_remove_port(){ local l p out=""; l="$(normalize_ports "${1:-}")"; for p in $l; do [ "$p" = "$2" ] || out="${out:+$out }$p"; done; printf '%s' "$out"; }
extra_unit_path(){ printf '%s-%s.service' "$EXTRA_UNIT_PREFIX" "$1"; }
managed_ports(){ normalize_ports "${H2_PORT:-} ${EXTRA_PORTS:-}"; }
managed_ports_text(){ local p; p="$(managed_ports)"; [ -n "$p" ] && printf '%s' "${p// /, }" || printf 'ninguno'; }

expected_sha(){ case "$(uname -m)" in x86_64|amd64) echo "$SHA_AMD64";; aarch64|arm64) echo "$SHA_ARM64";; *) echo "";; esac; }
payload_name(){ case "$(uname -m)" in x86_64|amd64) echo "superflash-h2connect-server-amd64.gz";; aarch64|arm64) echo "superflash-h2connect-server-arm64.gz";; *) echo "";; esac; }
payload_gz_sha(){ case "$(uname -m)" in x86_64|amd64) echo "$GZ_SHA_AMD64";; aarch64|arm64) echo "$GZ_SHA_ARM64";; *) echo "";; esac; }
engine_hash(){ [ -f "$BIN" ] && sha256sum "$BIN" 2>/dev/null | awk '{print $1}' || true; }
engine_state(){ local e g; e="$(expected_sha)"; g="$(engine_hash)"; if [ -z "$g" ]; then echo "NO INSTALADO"; elif [ -n "$e" ] && [ "$g" = "$e" ]; then echo "ESTABLE v$ENGINE_VERSION"; else echo "ANTIGUO/OTRO"; fi; }

load_config(){
  H2_PORT=""; SSH_PORT="$DEFAULT_SSH_PORT"; DOMAIN=""; ACME_EMAIL=""
  UFW_RULE_ADDED=0; UFW_RULE_PORT=""; FIREWALLD_RULE_ADDED=0; FIREWALLD_RULE_PORT=""
  EXTRA_PORTS=""; EXTRA_UFW_PORTS=""; EXTRA_FIREWALLD_PORTS=""
  if [ -f "$CONFIG" ]; then . "$CONFIG"; fi
  # Compatibilidad: puede reutilizar dominio/certificado legacy, pero NUNCA inventa :443.
  if [ -z "$DOMAIN" ] && [ -f "$LEGACY_XHTTP_CONF" ]; then
    local hp="$H2_PORT" sp="$SSH_PORT"; . "$LEGACY_XHTTP_CONF" 2>/dev/null || true; DOMAIN="${DOMAIN:-}"; H2_PORT="$hp"; SSH_PORT="$sp"
  fi
  if [ -z "$DOMAIN" ] && [ -s "$LEGACY_XHTTP_TLS/fullchain.pem" ]; then DOMAIN="$(openssl x509 -in "$LEGACY_XHTTP_TLS/fullchain.pem" -noout -subject 2>/dev/null | sed -n 's/.*CN *= *\([^,]*\).*/\1/p' | head -1)"; fi
  if [ -n "${H2_PORT:-}" ] && ! valid_port "$H2_PORT"; then H2_PORT=""; fi
  valid_port "${SSH_PORT:-}" || SSH_PORT="$DEFAULT_SSH_PORT"
  EXTRA_PORTS="$(normalize_ports "${EXTRA_PORTS:-}")"; EXTRA_UFW_PORTS="$(normalize_ports "${EXTRA_UFW_PORTS:-}")"; EXTRA_FIREWALLD_PORTS="$(normalize_ports "${EXTRA_FIREWALLD_PORTS:-}")"
  [ -n "${H2_PORT:-}" ] && EXTRA_PORTS="$(list_remove_port "$EXTRA_PORTS" "$H2_PORT")" || true
}
save_config(){
  mkdir -p "$BASE" "$TLS_DIR"
  {
    printf 'H2_PORT=%q\n' "$H2_PORT"; printf 'SSH_PORT=%q\n' "$SSH_PORT"; printf 'DOMAIN=%q\n' "$DOMAIN"; printf 'ACME_EMAIL=%q\n' "$ACME_EMAIL"
    printf 'UFW_RULE_ADDED=%q\n' "$UFW_RULE_ADDED"; printf 'UFW_RULE_PORT=%q\n' "$UFW_RULE_PORT"
    printf 'FIREWALLD_RULE_ADDED=%q\n' "$FIREWALLD_RULE_ADDED"; printf 'FIREWALLD_RULE_PORT=%q\n' "$FIREWALLD_RULE_PORT"
    printf 'EXTRA_PORTS=%q\n' "$EXTRA_PORTS"; printf 'EXTRA_UFW_PORTS=%q\n' "$EXTRA_UFW_PORTS"; printf 'EXTRA_FIREWALLD_PORTS=%q\n' "$EXTRA_FIREWALLD_PORTS"
  } > "$CONFIG"; chmod 600 "$CONFIG"
}

pkg_install_fast(){ local pkgs=("$@"); if have apt-get; then if DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${pkgs[@]}" >/dev/null 2>&1; then return 0; fi; DEBIAN_FRONTEND=noninteractive apt-get update -y >/dev/null; DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "${pkgs[@]}" >/dev/null; elif have dnf; then dnf install -y "${pkgs[@]}" >/dev/null; elif have yum; then yum install -y "${pkgs[@]}" >/dev/null; else return 1; fi; }
ensure_core_deps(){ local miss=0 c; for c in curl gzip sha256sum systemctl ss openssl getent; do have "$c" || miss=1; done; [ "$miss" -eq 0 ] && return 0; if have apt-get; then pkg_install_fast curl ca-certificates coreutils gzip iproute2 openssl libc-bin; else pkg_install_fast curl ca-certificates coreutils gzip iproute openssl glibc; fi; }
ensure_tls_deps(){ ensure_core_deps || return 1; have socat || pkg_install_fast socat; }

install_engine(){
  ensure_core_deps || return 1
  local name exp gzexp tmpgz tmp got url
  name="$(payload_name)"; exp="$(expected_sha)"; gzexp="$(payload_gz_sha)"
  [ -n "$name" ] && [ -n "$exp" ] || { echo -e "${red}Arquitectura no soportada.${reset}"; return 1; }
  got="$(engine_hash)"; [ "$got" = "$exp" ] && { echo -e "${green}✔ Motor H2 ya está correcto.${reset}"; return 0; }
  tmpgz="$(mktemp /tmp/superflash-h2.XXXXXX.gz)"; tmp="${BIN}.tmp.$$"
  url="https://raw.githubusercontent.com/${PAYLOAD_REPO}/${PAYLOAD_BRANCH}/payload/${name}"
  echo "Descargando motor XHTTP TLS/H2 exacto..."
  curl -fL --retry 3 --connect-timeout 12 --max-time 180 "$url" -o "$tmpgz" || { rm -f "$tmpgz"; return 1; }
  [ "$(sha256sum "$tmpgz" | awk '{print $1}')" = "$gzexp" ] || { rm -f "$tmpgz"; echo -e "${red}SHA-256 del payload inválido.${reset}"; return 1; }
  gzip -dc "$tmpgz" > "$tmp"; rm -f "$tmpgz"
  [ "$(sha256sum "$tmp" | awk '{print $1}')" = "$exp" ] || { rm -f "$tmp"; echo -e "${red}Integridad del motor FAIL.${reset}"; return 1; }
  chmod 0755 "$tmp"; mv -f "$tmp" "$BIN"; echo -e "${green}✔ Motor XHTTP TLS/H2 v$ENGINE_VERSION instalado.${reset}"
}

cert_matches_domain(){ local cert="$1" d="$2"; [ -s "$cert" ] || return 1; openssl x509 -in "$cert" -noout -checkend 604800 >/dev/null 2>&1 || return 1; openssl x509 -in "$cert" -noout -text 2>/dev/null | grep -Fqi "DNS:$d" || openssl x509 -in "$cert" -noout -subject 2>/dev/null | grep -Fqi "CN = $d"; }
import_legacy_cert_if_valid(){ load_config; [ -n "$DOMAIN" ] || return 1; if cert_matches_domain "$LEGACY_XHTTP_TLS/fullchain.pem" "$DOMAIN" && [ -s "$LEGACY_XHTTP_TLS/key.pem" ]; then mkdir -p "$TLS_DIR"; cp -f "$LEGACY_XHTTP_TLS/fullchain.pem" "$TLS_DIR/fullchain.pem"; cp -f "$LEGACY_XHTTP_TLS/key.pem" "$TLS_DIR/key.pem"; chmod 644 "$TLS_DIR/fullchain.pem"; chmod 600 "$TLS_DIR/key.pem"; echo -e "${green}✔ Certificado existente importado.${reset}"; return 0; fi; return 1; }

port_in_use(){ ss -ltn "sport = :$1" 2>/dev/null | grep -q LISTEN; }
port_owner(){ ss -ltnp "sport = :$1" 2>/dev/null || true; }
stop_known_competitors(){ local s; for s in "${COMPETITORS[@]}"; do if systemctl is-active --quiet "$s" 2>/dev/null || systemctl is-enabled --quiet "$s" 2>/dev/null; then systemctl disable --now "$s" >/dev/null 2>&1 || true; echo -e "${yellow}Se detuvo/deshabilitó $s porque puede competir por TCP 443. Archivos conservados.${reset}"; fi; done; }
stop_all_h2(){ systemctl stop "$SERVICE" >/dev/null 2>&1 || true; local p; for p in ${EXTRA_PORTS:-}; do systemctl stop "$(basename "$(extra_unit_path "$p")")" >/dev/null 2>&1 || true; done; }
remove_orphan_extra_units(){ local f p; for f in ${EXTRA_UNIT_PREFIX}-*.service; do [ -e "$f" ] || continue; p="${f##*-}"; p="${p%.service}"; list_has_port "${EXTRA_PORTS:-}" "$p" || { systemctl disable --now "$(basename "$f")" >/dev/null 2>&1 || true; rm -f "$f"; }; done; }

install_acme(){ [ -x "$ACME" ] && return 0; ensure_tls_deps || return 1; echo "Instalando acme.sh..."; if [ -n "${ACME_EMAIL:-}" ]; then curl -fsSL https://get.acme.sh | sh -s email="$ACME_EMAIL"; else curl -fsSL https://get.acme.sh | sh; fi; [ -x "$ACME" ]; }
configure_domain_cert(){
  ensure_tls_deps || return 1; load_config
  echo "Dominio actual: ${DOMAIN:-<sin configurar>}"; local d e
  prompt_read d "Dominio TLS que apunta DIRECTAMENTE a esta VPS: "; d="${d,,}"; valid_domain "$d" || { echo -e "${red}Dominio inválido.${reset}"; return 1; }
  prompt_read e "Email Let's Encrypt (opcional) [${ACME_EMAIL:-}]: "; [ -n "$e" ] && ACME_EMAIL="$e"; DOMAIN="$d"; save_config
  if cert_matches_domain "$TLS_DIR/fullchain.pem" "$DOMAIN" && [ -s "$TLS_DIR/key.pem" ]; then echo -e "${green}✔ Certificado válido; se reutiliza.${reset}"; return 0; fi
  import_legacy_cert_if_valid && return 0
  echo "DNS IPv4 observado para $DOMAIN:"; getent ahostsv4 "$DOMAIN" 2>/dev/null | awk '{print $1}' | sort -u | sed -n '1,8p' || true
  echo -e "${yellow}Para TLS-ALPN-01 TCP 443 debe llegar directo a esta VPS.${reset}"
  stop_all_h2; stop_known_competitors; sleep .2
  if port_in_use 443; then echo -e "${red}TCP 443 está ocupado:${reset}"; port_owner 443; return 1; fi
  install_acme || return 1; mkdir -p "$TLS_DIR"; "$ACME" --set-default-ca --server letsencrypt >/dev/null 2>&1 || true
  "$ACME" --issue --alpn -d "$DOMAIN" --server letsencrypt --keylength ec-256 || return 1
  "$ACME" --install-cert -d "$DOMAIN" --ecc --key-file "$TLS_DIR/key.pem" --fullchain-file "$TLS_DIR/fullchain.pem" --reloadcmd "systemctl restart '$SERVICE' >/dev/null 2>&1 || true"
  chmod 600 "$TLS_DIR/key.pem"; chmod 644 "$TLS_DIR/fullchain.pem"; echo -e "${green}✔ Certificado Let's Encrypt instalado.${reset}"
}

configure_domain_and_activate(){
  load_config
  [ -x "$BIN" ] || { echo -e "${red}Primero instala XHTTP TLS/H2 con la opción 1.${reset}"; return 1; }
  [ -n "$(managed_ports)" ] || { echo -e "${yellow}Primero agrega al menos un puerto XHTTP TLS/H2.${reset}"; return 1; }
  configure_domain_cert || return 1
  start_server
}

write_unit_for(){ local p="$1" path="$2" desc="$3"; cat > "$path" <<EOF_UNIT
[Unit]
Description=$desc
After=network.target
Wants=network.target

[Service]
Type=simple
ExecStart=$BIN --listen :$p --backend 127.0.0.1:${SSH_PORT} --cert $TLS_DIR/fullchain.pem --key $TLS_DIR/key.pem
Restart=on-failure
RestartSec=1
TimeoutStopSec=5
LimitNOFILE=131072
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
EOF_UNIT
}
write_units(){ load_config; if [ -n "${H2_PORT:-}" ]; then write_unit_for "$H2_PORT" "$UNIT" "NEW-GOLDEN $PROTOCOL_NAME - native TLS/HTTP2 tunnel v$ENGINE_VERSION"; else rm -f "$UNIT"; fi; local p; for p in ${EXTRA_PORTS:-}; do write_unit_for "$p" "$(extra_unit_path "$p")" "NEW-GOLDEN $PROTOCOL_NAME extra port $p - v$ENGINE_VERSION"; done; remove_orphan_extra_units; systemctl daemon-reload; if [ -n "${H2_PORT:-}" ]; then systemctl enable "$SERVICE" >/dev/null 2>&1 || true; else systemctl disable --now "$SERVICE" >/dev/null 2>&1 || true; fi; for p in ${EXTRA_PORTS:-}; do systemctl enable "$(basename "$(extra_unit_path "$p")")" >/dev/null 2>&1 || true; done; }

firewall_open_port(){ local p="$1" mode="${2:-extra}"; load_config; if have ufw && ufw status 2>/dev/null | head -1 | grep -qi active; then if ! ufw status 2>/dev/null | grep -Eq "^${p}/tcp[[:space:]]+ALLOW"; then ufw allow "${p}/tcp" >/dev/null 2>&1 || true; if [ "$mode" = main ]; then UFW_RULE_ADDED=1; UFW_RULE_PORT="$p"; else EXTRA_UFW_PORTS="$(list_add_port "$EXTRA_UFW_PORTS" "$p")"; fi; fi; fi; if have firewall-cmd && firewall-cmd --state >/dev/null 2>&1; then if ! firewall-cmd --quiet --query-port="${p}/tcp" >/dev/null 2>&1; then firewall-cmd --permanent --add-port="${p}/tcp" >/dev/null 2>&1 || true; firewall-cmd --reload >/dev/null 2>&1 || true; if [ "$mode" = main ]; then FIREWALLD_RULE_ADDED=1; FIREWALLD_RULE_PORT="$p"; else EXTRA_FIREWALLD_PORTS="$(list_add_port "$EXTRA_FIREWALLD_PORTS" "$p")"; fi; fi; fi; save_config; }
firewall_remove_extra(){ local p="$1"; load_config; if list_has_port "$EXTRA_UFW_PORTS" "$p" && have ufw; then ufw delete allow "${p}/tcp" >/dev/null 2>&1 || true; EXTRA_UFW_PORTS="$(list_remove_port "$EXTRA_UFW_PORTS" "$p")"; fi; if list_has_port "$EXTRA_FIREWALLD_PORTS" "$p" && have firewall-cmd; then firewall-cmd --permanent --remove-port="${p}/tcp" >/dev/null 2>&1 || true; firewall-cmd --reload >/dev/null 2>&1 || true; EXTRA_FIREWALLD_PORTS="$(list_remove_port "$EXTRA_FIREWALLD_PORTS" "$p")"; fi; save_config; }
firewall_remove_main(){ local p="${1:-}"; load_config; if [ "${UFW_RULE_ADDED:-0}" = 1 ] && [ -n "${UFW_RULE_PORT:-}" ] && { [ -z "$p" ] || [ "$UFW_RULE_PORT" = "$p" ]; } && have ufw; then ufw delete allow "${UFW_RULE_PORT}/tcp" >/dev/null 2>&1 || true; UFW_RULE_ADDED=0; UFW_RULE_PORT=""; fi; if [ "${FIREWALLD_RULE_ADDED:-0}" = 1 ] && [ -n "${FIREWALLD_RULE_PORT:-}" ] && { [ -z "$p" ] || [ "$FIREWALLD_RULE_PORT" = "$p" ]; } && have firewall-cmd; then firewall-cmd --permanent --remove-port="${FIREWALLD_RULE_PORT}/tcp" >/dev/null 2>&1 || true; firewall-cmd --reload >/dev/null 2>&1 || true; FIREWALLD_RULE_ADDED=0; FIREWALLD_RULE_PORT=""; fi; save_config; }

ssh_backend_ready(){ load_config; ss -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)$SSH_PORT$"; }
local_health_test_port(){ local p="$1"; load_config; ensure_tls_deps || return 1; local hdr body code proto; hdr="$(mktemp)"; body="$(mktemp)"; code="$(curl -4skS --http2 --connect-timeout 4 --max-time 8 --resolve "${DOMAIN}:${p}:127.0.0.1" -D "$hdr" -o "$body" -w '%{http_code} %{http_version}' "https://${DOMAIN}:${p}/health" 2>/dev/null || true)"; proto="${code#* }"; code="${code%% *}"; if [ "$code" = 200 ] && [ "$proto" = 2 ] && grep -qi '^x-superflash-h2-connect:[[:space:]]*1' "$hdr"; then rm -f "$hdr" "$body"; return 0; fi; rm -f "$hdr" "$body"; return 1; }

start_server(){
  load_config; [ -x "$BIN" ] || install_engine || return 1
  [ -n "$DOMAIN" ] || { echo -e "${red}Primero configura dominio/certificado.${reset}"; return 1; }
  [ -s "$TLS_DIR/fullchain.pem" ] && [ -s "$TLS_DIR/key.pem" ] || { import_legacy_cert_if_valid || { echo -e "${red}Falta certificado TLS.${reset}"; return 1; }; }
  ssh_backend_ready || { echo -e "${red}SSH no escucha en :$SSH_PORT.${reset}"; return 1; }
  stop_all_h2; [ "$H2_PORT" = 443 ] && stop_known_competitors || true; sleep .2
  local p all; all="$(managed_ports)"; [ -n "$all" ] || { echo -e "${yellow}No hay puertos XHTTP TLS/H2 configurados. Usa la opción 2.${reset}"; return 0; }; for p in $all; do if port_in_use "$p"; then echo -e "${red}TCP $p está ocupado por otro servicio:${reset}"; port_owner "$p"; return 1; fi; done
  write_units; if [ -n "${H2_PORT:-}" ]; then firewall_open_port "$H2_PORT" main; fi; for p in ${EXTRA_PORTS:-}; do firewall_open_port "$p" extra; done
  if [ -n "${H2_PORT:-}" ]; then systemctl restart "$SERVICE"; fi; for p in ${EXTRA_PORTS:-}; do systemctl restart "$(basename "$(extra_unit_path "$p")")"; done
  sleep .4; if [ -n "${H2_PORT:-}" ]; then systemctl is-active --quiet "$SERVICE" || { journalctl -u "$SERVICE" -n 40 --no-pager || true; return 1; }; fi
  echo -e "${green}✔ $PROTOCOL_NAME ACTIVO en: $(managed_ports_text) -> SSH 127.0.0.1:$SSH_PORT${reset}"
}
quick_install(){
  echo -e "${cyan}$PROTOCOL_NAME — instalación / actualización${reset}"
  install_engine || return 1
  load_config
  save_config
  echo -e "${green}✔ Motor instalado correctamente.${reset}"
  echo -e "${yellow}No se abrió ningún puerto automáticamente.${reset}"
  echo "Siguiente orden recomendado:"
  echo "  1) Agregar el puerto que quieras."
  echo "  2) Configurar dominio + certificado."
  echo "  3) El listener quedará activo después del TLS."
}

status_all(){ load_config; echo -e "${cyan}$PROTOCOL_NAME — ESTADO${reset}"; echo "Manager       : v$MANAGER_VERSION · Engine v$ENGINE_VERSION"; echo "Motor         : $(engine_state)"; echo "Dominio TLS   : ${DOMAIN:-<sin configurar>}"; echo "Puertos       : $(managed_ports_text) -> SSH 127.0.0.1:$SSH_PORT"; echo "Principal     : $(systemctl is-active "$SERVICE" 2>/dev/null || true)"; local p; for p in ${EXTRA_PORTS:-}; do echo "Puerto :$p    : $(systemctl is-active "$(basename "$(extra_unit_path "$p")")" 2>/dev/null || true)"; done; }
self_test(){ load_config; [ "$(engine_state)" = "ESTABLE v$ENGINE_VERSION" ] || { echo -e "${red}Motor distinto/ausente.${reset}"; return 1; }; [ -n "$DOMAIN" ] || return 1; [ -n "$(managed_ports)" ] || { echo -e "${red}No hay puertos XHTTP TLS/H2 configurados.${reset}"; return 1; }; ssh_backend_ready || return 1; local p out; for p in $(managed_ports); do out="$(echo | timeout 8 openssl s_client -connect "127.0.0.1:$p" -servername "$DOMAIN" -verify_hostname "$DOMAIN" -alpn h2 2>/dev/null | tr -d '\000' || true)"; echo "$out" | grep -q 'ALPN protocol: h2' || { echo -e "${red}ALPN h2 FAIL :$p${reset}"; return 1; }; echo "$out" | grep -q 'Verify return code: 0' || { echo -e "${red}TLS hostname FAIL :$p${reset}"; return 1; }; local_health_test_port "$p" || { echo -e "${red}/health FAIL :$p${reset}"; return 1; }; echo -e "${green}✔ :$p TLS/HTTP2 /health PASS${reset}"; done; echo -e "${green}✔ $PROTOCOL_NAME correcto en todos los puertos.${reset}"; }

set_port(){ load_config; local old="$H2_PORT" p; prompt_read p "Nuevo puerto principal XHTTP TLS/H2 [$H2_PORT]: "; p="${p:-$H2_PORT}"; valid_port "$p" || return 1; [ "$p" = "$old" ] && return 0; list_has_port "$EXTRA_PORTS" "$p" && { echo "Ese puerto ya está como adicional."; return 1; }; [ -n "$old" ] && firewall_remove_main "$old" || true; load_config; H2_PORT="$p"; EXTRA_PORTS="$(list_remove_port "$EXTRA_PORTS" "$p")"; save_config; start_server; }
set_ssh(){ load_config; local p; prompt_read p "Puerto SSH backend local [$SSH_PORT]: "; p="${p:-$SSH_PORT}"; valid_port "$p" || return 1; SSH_PORT="$p"; save_config; if [ -n "$(managed_ports)" ] && [ -n "$DOMAIN" ] && cert_matches_domain "$TLS_DIR/fullchain.pem" "$DOMAIN" && [ -s "$TLS_DIR/key.pem" ]; then start_server; else echo -e "${green}✔ SSH backend guardado en :$SSH_PORT.${reset}"; fi; }
add_port(){
  load_config; local p
  [ -x "$BIN" ] || { echo -e "${red}Primero instala XHTTP TLS/H2 con la opción 1.${reset}"; return 1; }
  prompt_read p "Puerto XHTTP TLS/H2 que quieres AGREGAR: "
  valid_port "$p" || { echo "Puerto inválido"; return 1; }
  list_has_port "$(managed_ports)" "$p" && { echo "Ese puerto ya está configurado."; return 0; }
  if port_in_use "$p"; then echo -e "${red}TCP $p está ocupado.${reset}"; port_owner "$p"; return 1; fi
  if [ -z "${H2_PORT:-}" ]; then H2_PORT="$p"; else EXTRA_PORTS="$(list_add_port "$EXTRA_PORTS" "$p")"; fi
  save_config
  if [ -n "$DOMAIN" ] && cert_matches_domain "$TLS_DIR/fullchain.pem" "$DOMAIN" && [ -s "$TLS_DIR/key.pem" ]; then
    start_server || return 1
    echo -e "${green}✔ Puerto :$p agregado y activo con autoarranque.${reset}"
  else
    echo -e "${green}✔ Puerto :$p guardado.${reset}"
    echo -e "${yellow}Ahora configura dominio + certificado; todavía no se abrió ningún listener.${reset}"
  fi
}
remove_port(){ load_config; local all p c newmain="" q promoted_ufw=0 promoted_firewalld=0; all="$(managed_ports)"; [ -n "$all" ] || { echo "No hay puertos configurados."; return 0; }; echo "Puertos XHTTP TLS/H2: ${all// /, }"; prompt_read p "Puerto que quieres CERRAR/ELIMINAR: "; valid_port "$p" || return 1; list_has_port "$all" "$p" || { echo "Ese puerto no está gestionado."; return 1; }; prompt_read c "Escribe CERRAR para confirmar :$p: "; [ "$c" = CERRAR ] || return 0
  if [ "$p" = "$H2_PORT" ]; then
    systemctl disable --now "$SERVICE" >/dev/null 2>&1 || true
    rm -f "$UNIT"
    firewall_remove_main "$p" || true
    load_config
    for q in $EXTRA_PORTS; do newmain="$q"; break; done
    if [ -n "$newmain" ]; then
      list_has_port "$EXTRA_UFW_PORTS" "$newmain" && promoted_ufw=1 || true
      list_has_port "$EXTRA_FIREWALLD_PORTS" "$newmain" && promoted_firewalld=1 || true
      EXTRA_PORTS="$(list_remove_port "$EXTRA_PORTS" "$newmain")"
      EXTRA_UFW_PORTS="$(list_remove_port "$EXTRA_UFW_PORTS" "$newmain")"
      EXTRA_FIREWALLD_PORTS="$(list_remove_port "$EXTRA_FIREWALLD_PORTS" "$newmain")"
      H2_PORT="$newmain"
      if [ "$promoted_ufw" -eq 1 ]; then UFW_RULE_ADDED=1; UFW_RULE_PORT="$newmain"; fi
      if [ "$promoted_firewalld" -eq 1 ]; then FIREWALLD_RULE_ADDED=1; FIREWALLD_RULE_PORT="$newmain"; fi
    else
      H2_PORT=""
    fi
  else
    systemctl disable --now "$(basename "$(extra_unit_path "$p")")" >/dev/null 2>&1 || true
    rm -f "$(extra_unit_path "$p")"
    firewall_remove_extra "$p"
    load_config
    EXTRA_PORTS="$(list_remove_port "$EXTRA_PORTS" "$p")"
  fi
  save_config
  systemctl daemon-reload
  if [ -n "$(managed_ports)" ]; then start_server || true; fi
  echo -e "${green}✔ Puerto :$p eliminado.${reset}"
}
renew_cert(){ load_config; [ -n "$DOMAIN" ] || return 1; install_acme || return 1; stop_all_h2; stop_known_competitors; [ ! port_in_use 443 ] || { echo "443 ocupado"; return 1; }; "$ACME" --renew -d "$DOMAIN" --ecc --force || return 1; "$ACME" --install-cert -d "$DOMAIN" --ecc --key-file "$TLS_DIR/key.pem" --fullchain-file "$TLS_DIR/fullchain.pem" --reloadcmd "systemctl restart '$SERVICE' >/dev/null 2>&1 || true"; start_server; }
rollback_xhttp(){ stop_all_h2; systemctl disable "$SERVICE" >/dev/null 2>&1 || true; if systemctl cat superflash-xhttp.service >/dev/null 2>&1; then systemctl enable superflash-xhttp.service >/dev/null 2>&1 || true; systemctl restart superflash-xhttp.service; echo -e "${green}✔ Restaurado SSH_XHTTP anterior.${reset}"; else echo -e "${yellow}No existe superflash-xhttp.service.${reset}"; fi; }
uninstall(){ load_config; echo -e "${yellow}Esto elimina SOLO XHTTP TLS/H2. BHTTP y SSH no se tocan.${reset}"; local c p; prompt_read c "Escribe XHTTP para confirmar: "; [ "$c" = XHTTP ] || return 0; stop_all_h2; systemctl disable "$SERVICE" >/dev/null 2>&1 || true; rm -f "$UNIT"; for p in ${EXTRA_PORTS:-}; do systemctl disable "$(basename "$(extra_unit_path "$p")")" >/dev/null 2>&1 || true; rm -f "$(extra_unit_path "$p")"; firewall_remove_extra "$p"; done; firewall_remove_main || true; load_config; rm -f "$BIN"; systemctl daemon-reload; rm -rf "$BASE"; echo -e "${green}✔ XHTTP TLS/H2 eliminado. BHTTP/SSH intactos.${reset}"; }

menu(){
  need_root; require_interactive_tty || return 1
  while true; do
    clear || true; load_config
    echo -e "${yellow}=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=${reset}"
    echo -e "${cyan} XHTTP TLS/H2  [ NEW-GOLDEN ADM PRO ]${reset}"
    echo -e "${yellow}=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=${reset}"
    echo " Manager       : v$MANAGER_VERSION · Engine v$ENGINE_VERSION"
    echo " Motor         : $(engine_state)"
    echo " Dominio       : ${DOMAIN:-<sin configurar>}"
    echo " Puertos       : $(managed_ports_text)"
    echo " SSH backend   : $SSH_PORT"
    echo -e "${yellow}=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=${reset}"
    echo
    echo "[ 1] ###>> INSTALAR / ACTUALIZAR XHTTP TLS/H2"
    echo "[ 2] ###>> Agregar puerto XHTTP TLS/H2"
    echo "[ 3] ###>> Cerrar/eliminar puerto XHTTP TLS/H2"
    echo "[ 4] ###>> Configurar dominio + certificado y ACTIVAR"
    echo "[ 5] ###>> Iniciar/reaplicar listeners"
    echo "[ 6] ###>> Cambiar puerto SSH backend"
    echo "[ 7] ###>> Estado/diagnóstico"
    echo "[ 8] ###>> AUTOPRUEBA COMPLETA"
    echo "[ 9] ###>> Ver logs"
    echo "[10] ###>> Renovar certificado"
    echo "[11] ###>> Reiniciar XHTTP TLS/H2"
    echo "[12] ###>> Detener XHTTP TLS/H2"
    echo "[13] ###>> Rollback a SSH_XHTTP anterior"
    echo "[14] ###>> DESINSTALAR XHTTP TLS/H2"
    echo "[ 0] ###>> VOLVER"
    echo -e "${yellow}=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=x=${reset}"
    echo
    local op p; prompt_read op "Seleccione una Opcion: "
    case "$op" in
      1) quick_install; pause;;
      2) add_port; pause;;
      3) remove_port; pause;;
      4) configure_domain_and_activate; pause;;
      5) start_server; pause;;
      6) set_ssh; pause;;
      7) status_all; pause;;
      8) self_test; pause;;
      9) journalctl -u "$SERVICE" -n 100 --no-pager || true; for p in ${EXTRA_PORTS:-}; do echo "===== :$p ====="; journalctl -u "$(basename "$(extra_unit_path "$p")")" -n 50 --no-pager || true; done; pause;;
      10) renew_cert; pause;;
      11) start_server; pause;;
      12) stop_all_h2; echo "XHTTP TLS/H2 detenido; puertos conservados para próximo inicio."; pause;;
      13) rollback_xhttp; pause;;
      14) uninstall; pause;;
      0) exit 0;;
      *) echo "Opción inválida"; sleep .5;;
    esac
  done
}

case "${1:-menu}" in menu|--menu|"") need_root; menu;; quick|--quick) need_root; require_interactive_tty; quick_install;; self-test|--self-test|test|--test) need_root; self_test;; status|--status) need_root; status_all;; uninstall|--uninstall|remove|--remove) need_root; require_interactive_tty; uninstall;; *) echo "Uso: $0 [menu|quick|self-test|status|uninstall]"; exit 2;; esac
