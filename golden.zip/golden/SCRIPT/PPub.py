#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Proxy HTTP/CONNECT compatible con Python 3 para Golden System PRO."""

import http.client
import select
import socket
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlsplit

MODE = "public"
DEFAULT_BANNER = "ADM-ULTIMATE"
HOP_HEADERS = {
    "connection", "proxy-connection", "keep-alive", "proxy-authenticate",
    "proxy-authorization", "te", "trailer", "trailers",
    "transfer-encoding", "upgrade",
}


def parse_target(value, default_port):
    value = value.strip()
    if value.startswith("["):
        end = value.find("]")
        if end < 0:
            raise ValueError("IPv6 invalida")
        host = value[1:end]
        tail = value[end + 1:]
        port = int(tail[1:]) if tail.startswith(":") else default_port
    elif value.count(":") == 1:
        host, raw_port = value.rsplit(":", 1)
        port = int(raw_port)
    elif ":" in value:
        host, port = value, default_port
    else:
        host, port = value, default_port
    if not host or not 1 <= int(port) <= 65535:
        raise ValueError("destino invalido")
    return host, int(port)


class ThreadedServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class ProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    timeout = 300
    banner = DEFAULT_BANNER
    allowed_hosts = set()

    def log_error(self, fmt, *args):
        if "timed out" not in fmt.lower():
            super().log_error(fmt, *args)

    def host_allowed(self, host):
        if MODE != "private":
            return True
        normalized = host.strip("[]").lower()
        return normalized in self.allowed_hosts

    def do_CONNECT(self):
        try:
            host, port = parse_target(self.path, 443)
        except (ValueError, TypeError):
            self.send_error(400, "Destino invalido")
            return
        if not self.host_allowed(host):
            self.send_error(403, "Server Forbidden")
            return
        try:
            upstream = socket.create_connection((host, port), timeout=15)
        except OSError:
            self.send_error(502, "Conexion rechazada")
            return

        self.send_response(200, self.banner)
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        self.close_connection = True
        self.connection.setblocking(False)
        upstream.setblocking(False)
        sockets = [self.connection, upstream]
        try:
            while sockets:
                readable, _, exceptional = select.select(sockets, [], sockets, self.timeout)
                if exceptional or not readable:
                    break
                for source in readable:
                    target = upstream if source is self.connection else self.connection
                    try:
                        data = source.recv(65536)
                    except (BlockingIOError, InterruptedError):
                        continue
                    if not data:
                        return
                    target.sendall(data)
        except (OSError, ValueError):
            pass
        finally:
            try:
                upstream.close()
            except OSError:
                pass

    def do_GET(self):
        self.forward_http()

    def do_HEAD(self):
        self.forward_http()

    def do_POST(self):
        self.forward_http()

    def do_PUT(self):
        self.forward_http()

    def do_DELETE(self):
        self.forward_http()

    def do_OPTIONS(self):
        self.forward_http()

    def forward_http(self):
        host_header = self.headers.get("Host", "")
        if self.path.startswith(("http://", "https://")):
            parsed = urlsplit(self.path)
        else:
            parsed = urlsplit("http://" + host_header + self.path)

        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            self.send_error(400, "URL invalida")
            return
        if not self.host_allowed(parsed.hostname):
            self.send_error(403, "Server Forbidden")
            return

        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        selector = parsed.path or "/"
        if parsed.query:
            selector += "?" + parsed.query

        length_raw = self.headers.get("Content-Length", "0")
        try:
            length = int(length_raw)
        except ValueError:
            self.send_error(400, "Content-Length invalido")
            return
        if length < 0 or length > 64 * 1024 * 1024:
            self.send_error(413, "Solicitud demasiado grande")
            return
        body = self.rfile.read(length) if length else None

        headers = {}
        connection_tokens = {
            item.strip().lower()
            for item in self.headers.get("Connection", "").split(",")
            if item.strip()
        }
        for key, value in self.headers.items():
            if key.lower() not in HOP_HEADERS | connection_tokens:
                headers[key] = value
        headers["Host"] = parsed.netloc

        conn_cls = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
        conn = conn_cls(parsed.hostname, port, timeout=30)
        response_started = False
        try:
            conn.request(self.command, selector, body=body, headers=headers)
            response = conn.getresponse()
            self.send_response(response.status, response.reason)
            response_tokens = {
                item.strip().lower()
                for item in response.getheader("Connection", "").split(",")
                if item.strip()
            }
            for key, value in response.getheaders():
                if key.lower() not in HOP_HEADERS | response_tokens:
                    self.send_header(key, value)
            self.send_header("Connection", "close")
            self.end_headers()
            response_started = True
            if self.command != "HEAD":
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        except (OSError, http.client.HTTPException):
            if not response_started:
                try:
                    self.send_error(502, "Error del servidor remoto")
                except (OSError, BrokenPipeError):
                    pass
        finally:
            conn.close()
            self.close_connection = True


def main():
    if len(sys.argv) < 2:
        suffix = " [HOSTS_PERMITIDOS]" if MODE == "private" else ""
        print("Uso: {} PUERTO [BANNER]{}".format(sys.argv[0], suffix), file=sys.stderr)
        return 2
    try:
        port = int(sys.argv[1])
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        print("Puerto invalido", file=sys.stderr)
        return 2

    ProxyHandler.banner = sys.argv[2] if len(sys.argv) > 2 else DEFAULT_BANNER
    if MODE == "private":
        raw = sys.argv[3] if len(sys.argv) > 3 else "127.0.0.1"
        raw = raw.replace(",", " ")
        ProxyHandler.allowed_hosts = {
            item.strip("[]").lower() for item in raw.split() if item.strip()
        }
        if not ProxyHandler.allowed_hosts:
            print("No se definieron hosts permitidos", file=sys.stderr)
            return 2

    server = ThreadedServer(("0.0.0.0", port), ProxyHandler)
    print("Servidor proxy en 0.0.0.0:{} modo={}".format(port, MODE))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
