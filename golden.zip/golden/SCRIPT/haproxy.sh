#!/bin/bash

# Golden REV26: compatibilidad común, APT no interactivo, timeouts de red y progreso.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive


SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ echo -e "\033[0;33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[0m"; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

type msg >/dev/null 2>&1 || msg(){
case "$1" in
-bar) linea ;;
-ama) shift; echo -e "${cor[3]}$*${cor[0]}" ;;
-azu) shift; echo -e "${cor[1]}$*${cor[0]}" ;;
-bra) shift; echo -e "${cor[0]}$*" ;;
*) echo -e "$*" ;;
esac
}

fun_bar () {
    local comando="${1:-true}"
    if declare -F golden_progress_command >/dev/null 2>&1; then
        golden_progress_command "Procesando HAProxy SSL" "$comando" "/tmp/haproxy_install.log"
        return $?
    fi
    eval "$comando" >"/tmp/haproxy_install.log" 2>&1
}


valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

mportas () {
    if command -v ss >/dev/null 2>&1; then
        ss -ltnp 2>/dev/null | awk '
        NR>1 {
            n=split($4,a,":");
            port=a[n];
            proc=$0;
            name="desconocido";
            if (proc ~ /haproxy/) name="haproxyssl";
            else if (proc ~ /stunnel/) name="stunnel4";
            else if (proc ~ /sshd/) name="sshd";
            else if (proc ~ /dropbear/) name="dropbear";
            else if (proc ~ /apache2/) name="apache2";
            else if (proc ~ /badvpn/) name="badvpn-ud";
            else if (proc ~ /rusty/) name="rustyprox";
            else if (proc ~ /xray/) name="xray";
            else if (proc ~ /v2ray/) name="v2ray";
            print name" "port;
        }' | sort -u
    else
        netstat -ltnp 2>/dev/null | awk '
        NR>2 {
            n=split($4,a,":");
            port=a[n];
            print "desconocido "port;
        }' | sort -u
    fi
}

port_in_use() {
    mportas | awk '{print $2}' | grep -wq "$1"
}

instalar_base_haproxy() {
    local old_wait="${GOLDEN_APT_LOCK_WAIT:-600}"
    local need_update=0

    # La instalación principal de Golden ya deja curl/wget/openssl/iproute2 listos.
    # HAProxy no vuelve a instalar una lista grande de paquetes ni ejecuta update
    # incondicionalmente. Solo instala lo que realmente falte.
    command -v openssl >/dev/null 2>&1 || need_update=1
    command -v ss >/dev/null 2>&1 || need_update=1
    command -v haproxy >/dev/null 2>&1 || need_update=1
    (( need_update == 0 )) && return 0

    # Un protocolo no puede quedar 10 minutos aparentando estar congelado.
    GOLDEN_APT_LOCK_WAIT=120

    # Si el bootstrap dejó el stamp reciente, golden_apt_update retorna sin tocar APT.
    # Si no hay stamp, actualiza una sola vez con timeout global de compat.sh.
    golden_apt_update || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }

    command -v openssl >/dev/null 2>&1 || golden_install_required openssl || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }
    command -v ss >/dev/null 2>&1 || golden_install_iproute || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }
    command -v haproxy >/dev/null 2>&1 || golden_install_required haproxy || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }

    GOLDEN_APT_LOCK_WAIT="$old_wait"
    command -v haproxy >/dev/null 2>&1
}

optimizar_haproxy_ssl() {
    mkdir -p /etc/sysctl.d
    mkdir -p /etc/security/limits.d
    mkdir -p /etc/systemd/system.conf.d
    mkdir -p /etc/systemd/user.conf.d
    mkdir -p /etc/systemd/system/haproxy.service.d

cat >/etc/sysctl.d/99-newgolden-haproxy.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_syn_retries = 3
net.ipv4.tcp_synack_retries = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF

    sysctl --system >/dev/null 2>&1

cat >/etc/security/limits.d/99-newgolden-haproxy.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
haproxy soft nofile 1048576
haproxy hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/system/haproxy.service.d/override.conf <<'EOF'
[Service]
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Restart=always
RestartSec=2
EOF

    systemctl daemon-reload >/dev/null 2>&1
}

optimizar_sshd_haproxy() {
    mkdir -p /etc/ssh/sshd_config.d

    sed -i '/^MaxStartups/d;/^MaxSessions/d;/^LoginGraceTime/d;/^ClientAliveInterval/d;/^ClientAliveCountMax/d;/^TCPKeepAlive/d;/^UseDNS/d;/^GSSAPIAuthentication/d;/^Compression/d' /etc/ssh/sshd_config 2>/dev/null

cat >/etc/ssh/sshd_config.d/99-newgolden-haproxy.conf <<'EOF'
MaxStartups 2000:30:5000
MaxSessions 5000
LoginGraceTime 15
ClientAliveInterval 60
ClientAliveCountMax 2
TCPKeepAlive yes
UseDNS no
GSSAPIAuthentication no
Compression no
EOF

    if command -v sshd >/dev/null 2>&1; then
        sshd -t >/tmp/sshd_haproxy_test.log 2>&1 || {
            echo "ERROR EN CONFIG SSHD"
            cat /tmp/sshd_haproxy_test.log
            return 1
        }
    fi

    systemctl restart ssh 2>/dev/null
    systemctl restart sshd 2>/dev/null
    service ssh restart 2>/dev/null
    service sshd restart 2>/dev/null
    return 0
}

limpiar_certificado_haproxy() {
    rm -f /etc/haproxy/certs/haproxy.pem
    rm -f /tmp/haproxy.key
    rm -f /tmp/haproxy.crt
}

generar_cert_haproxy() {
    mkdir -p /etc/haproxy/certs
    limpiar_certificado_haproxy

    echo -ne "Ingrese dominio SSL/SNI [localhost]: "
    read -r dominio
    dominio=$(echo "${dominio:-localhost}" | tr -d ' ')

    openssl genrsa -out /tmp/haproxy.key 2048 >/dev/null 2>&1 || {
        echo "ERROR: No se pudo generar la clave SSL"
        return 1
    }

    openssl req -new -x509 -days 1000 \
        -key /tmp/haproxy.key \
        -out /tmp/haproxy.crt \
        -subj "/C=US/ST=SSL/L=SSL/O=NEWGOLDEN/OU=VPN/CN=${dominio}" >/dev/null 2>&1 || {
        echo "ERROR: No se pudo generar el certificado SSL"
        limpiar_certificado_haproxy
        return 1
    }

    cat /tmp/haproxy.crt /tmp/haproxy.key > /etc/haproxy/certs/haproxy.pem
    chmod 600 /etc/haproxy/certs/haproxy.pem
    chown root:root /etc/haproxy/certs/haproxy.pem 2>/dev/null

    rm -f /tmp/haproxy.key /tmp/haproxy.crt

    openssl x509 -in /etc/haproxy/certs/haproxy.pem -noout >/dev/null 2>&1 || {
        echo "ERROR: Certificado generado inválido"
        limpiar_certificado_haproxy
        return 1
    }

    echo "Certificado SSL HAProxy generado correctamente"
    return 0
}

asegurar_cert_haproxy() {
    if [[ -s /etc/haproxy/certs/haproxy.pem ]]; then
        openssl x509 -in /etc/haproxy/certs/haproxy.pem -noout >/dev/null 2>&1
        [[ $? -eq 0 ]] && return 0
    fi

    echo "Certificado dañado o inexistente. Creando nuevo..."
    generar_cert_haproxy
}

activar_haproxy_boot() {
    mkdir -p /etc/haproxy /etc/haproxy/certs
    if declare -F golden_service_enable >/dev/null 2>&1; then
        golden_service_enable haproxy >/dev/null 2>&1 || true
    else
        systemctl enable haproxy >/dev/null 2>&1 || true
    fi
}

write_haproxy_conf() {
    # Configuración deliberadamente mínima: funciona tanto con HAProxy modernos
    # como con las ramas antiguas de Ubuntu/Debian. Evita directivas nuevas como
    # nbthread/expose-fd que hacen fallar versiones viejas.
    cat >/etc/haproxy/haproxy.cfg <<'EOF'
global
    daemon
    maxconn 20000

defaults
    mode tcp
    option dontlognull
    option tcpka
    timeout connect 10s
    timeout client 2h
    timeout server 2h
EOF

    if [[ -f /etc/haproxy/newgolden.map ]]; then
        while IFS='|' read -r nombre ssl local; do
            [[ -z "$nombre" || -z "$ssl" || -z "$local" ]] && continue
            cat >>/etc/haproxy/haproxy.cfg <<EOF

frontend ${nombre}_front
    bind 0.0.0.0:${ssl} ssl crt /etc/haproxy/certs/haproxy.pem
    default_backend ${nombre}_back

backend ${nombre}_back
    server ${nombre}_srv 127.0.0.1:${local}
EOF
        done < /etc/haproxy/newgolden.map
    fi
}

agregar_servicio_haproxy() {
    local nombre="$1"
    local puerto_ssl="$2"
    local puerto_local="$3"

    mkdir -p /etc/haproxy
    touch /etc/haproxy/newgolden.map

    grep -v "|${puerto_ssl}|" /etc/haproxy/newgolden.map > /tmp/newgolden_haproxy.map 2>/dev/null
    mv /tmp/newgolden_haproxy.map /etc/haproxy/newgolden.map

    echo "${nombre}|${puerto_ssl}|${puerto_local}" >> /etc/haproxy/newgolden.map

    write_haproxy_conf
}

restart_haproxy_compatible() {
    local puerto_check="$1" i
    activar_haproxy_boot

    chmod 600 /etc/haproxy/certs/haproxy.pem 2>/dev/null || true
    chown root:root /etc/haproxy/certs/haproxy.pem 2>/dev/null || true
    : >/tmp/haproxy_test.log

    openssl x509 -in /etc/haproxy/certs/haproxy.pem -noout >>/tmp/haproxy_test.log 2>&1 || {
        echo "Certificado dañado. Regenerando..."
        generar_cert_haproxy || return 1
    }

    if declare -F golden_run_timeout >/dev/null 2>&1; then
        golden_run_timeout 20 haproxy -c -f /etc/haproxy/haproxy.cfg >/tmp/haproxy_test.log 2>&1 || {
            echo "ERROR CONFIG HAProxy:"; cat /tmp/haproxy_test.log; return 1;
        }
    else
        haproxy -c -f /etc/haproxy/haproxy.cfg >/tmp/haproxy_test.log 2>&1 || {
            echo "ERROR CONFIG HAProxy:"; cat /tmp/haproxy_test.log; return 1;
        }
    fi

    if declare -F golden_service >/dev/null 2>&1; then
        golden_service restart haproxy >>/tmp/haproxy_test.log 2>&1 || golden_service start haproxy >>/tmp/haproxy_test.log 2>&1 || true
    else
        service haproxy restart >>/tmp/haproxy_test.log 2>&1 || systemctl restart haproxy >>/tmp/haproxy_test.log 2>&1 || true
    fi

    for i in 1 2 3 4 5 6 7 8 9 10; do
        ss -H -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${puerto_check}$" && return 0
        sleep 1
    done

    echo "ERROR REAL DE HAPROXY:"
    cat /tmp/haproxy_test.log
    return 1
}

mostrar_haproxy_activos() {
    linea
    echo -e "        ${cor[3]}HAPROXY SSL ACTIVOS - NEW GOLDEN${cor[0]}"
    linea2

    if ss -ltnp 2>/dev/null | grep -qi haproxy; then
        ss -ltnp 2>/dev/null | grep -i haproxy | awk '{
            split($4,a,":");
            print "   [ONLINE] Puerto SSL : " a[length(a)];
        }'
    else
        echo -e "   ${cor[2]}[OFFLINE] No hay puertos HAProxy SSL activos.${cor[0]}"
    fi
}

haproxy_ssl () {
clean_screen
echo "HAPROXY SSL"
linea
echo "Seleccione un puerto interno abierto"
echo "Ejemplo: 22 OpenSSH, 80 Proxy, 53 Dropbear"
linea

while true; do
    read -p "Local-Port: " portx
    valid_port "$portx" || { echo "Puerto invalido"; continue; }

    if port_in_use "$portx"; then
        break
    else
        echo "Ese puerto interno no esta abierto"
    fi
done

linea
echo "Que puerto desea agregar como SSL"
linea

while true; do
    read -p "Listen-SSL: " SSLPORT
    valid_port "$SSLPORT" || { echo "Puerto invalido"; continue; }

    if port_in_use "$SSLPORT"; then
        echo "Este puerto ya esta en uso"
    else
        break
    fi
done

linea
echo "Instalando HAProxy SSL"
linea

fun_bar "instalar_base_haproxy" || {
    echo "No se pudieron preparar las dependencias de HAProxy. Revisa /tmp/haproxy_install.log"
    return 1
}
asegurar_cert_haproxy || return 1

agregar_servicio_haproxy "haproxy_${SSLPORT}" "$SSLPORT" "$portx"

if restart_haproxy_compatible "$SSLPORT"; then
    linea
    echo "INSTALADO CON EXITO"
    echo "HAProxy SSL: ${SSLPORT} -> LOCAL: ${portx}"
    linea
else
    linea
    echo "ERROR: HAProxy no pudo iniciar"
    echo "cat /etc/haproxy/haproxy.cfg"
    echo "cat /tmp/haproxy_test.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

haproxy_puerto () {
clean_screen
echo "AGREGAR PUERTO HAPROXY SSL OPENSSH"
linea

while true; do
    read -p "Puerto SSL: " SSLPORTr
    valid_port "$SSLPORTr" || { echo "Puerto invalido"; continue; }

    if port_in_use "$SSLPORTr"; then
        echo "Esta puerta esta en uso"
    else
        break
    fi
done

linea
echo "Instalando HAProxy SSL"
linea

fun_bar "instalar_base_haproxy" || {
    echo "No se pudieron preparar las dependencias de HAProxy. Revisa /tmp/haproxy_install.log"
    return 1
}
asegurar_cert_haproxy || return 1

agregar_servicio_haproxy "ssh_${SSLPORTr}" "$SSLPORTr" "22"

if restart_haproxy_compatible "$SSLPORTr"; then
    linea
    echo "AGREGADO CON EXITO"
    echo "HAProxy SSL: ${SSLPORTr} -> LOCAL: 22"
    linea
else
    linea
    echo "ERROR: HAProxy no pudo iniciar"
    echo "cat /etc/haproxy/haproxy.cfg"
    echo "cat /tmp/haproxy_test.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

haproxy_redir () {
clean_screen
echo "REDIRECCIONAR PUERTO HAPROXY SSL"
linea

read -p "Nombre: " namer
namer=$(echo "$namer" | tr -cd 'a-zA-Z0-9_-')
[[ -z "$namer" ]] && namer="redir_ssl"

linea
echo "A que puerto redireccionara el puerto SSL"
linea

while true; do
    read -p "Local-Port: " portd
    valid_port "$portd" || { echo "Puerto local invalido"; continue; }

    if port_in_use "$portd"; then
        break
    else
        echo "Ese puerto local no esta abierto"
    fi
done

linea
echo "Que puerto desea agregar como SSL"
linea

while true; do
    read -p "Puerto SSL: " SSLPORTr
    valid_port "$SSLPORTr" || { echo "Puerto SSL invalido"; continue; }

    if port_in_use "$SSLPORTr"; then
        echo "Esta puerta esta en uso"
    else
        break
    fi
done

linea
echo "Instalando HAProxy SSL"
linea

fun_bar "instalar_base_haproxy" || {
    echo "No se pudieron preparar las dependencias de HAProxy. Revisa /tmp/haproxy_install.log"
    return 1
}
asegurar_cert_haproxy || return 1

agregar_servicio_haproxy "$namer" "$SSLPORTr" "$portd"

if restart_haproxy_compatible "$SSLPORTr"; then
    linea
    echo "REDIRECCION HAPROXY SSL AGREGADA CON EXITO"
    echo "HAProxy SSL: ${SSLPORTr} -> LOCAL: ${portd}"
    linea
else
    linea
    echo "ERROR: HAProxy no pudo iniciar"
    echo "cat /etc/haproxy/haproxy.cfg"
    echo "cat /tmp/haproxy_test.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

detener_haproxy () {
clean_screen
echo "DESINSTALAR HAPROXY SSL"
linea
echo "Esta opcion eliminara completamente HAProxy SSL"
echo "Configuraciones, certificados y servicios"
linea

read -p "¿Deseas continuar? [s/n]: " confirmssl
[[ "$confirmssl" != "s" && "$confirmssl" != "S" ]] && return 0

linea
echo "DESINSTALANDO HAPROXY SSL COMPLETAMENTE"
linea

desinstalar_haproxy_completo() {
    service haproxy stop >/dev/null 2>&1
    systemctl stop haproxy >/dev/null 2>&1
    systemctl disable haproxy >/dev/null 2>&1

    pkill -9 haproxy >/dev/null 2>&1

    rm -rf /etc/haproxy
    rm -rf /etc/default/haproxy
    rm -rf /etc/systemd/system/haproxy.service.d
    rm -rf /var/lib/haproxy
    rm -rf /run/haproxy

    rm -f /tmp/haproxy_test.log
    rm -f /tmp/haproxy_install.log
    rm -f /tmp/haproxy.key
    rm -f /tmp/haproxy.crt

    apt-get purge -y haproxy >/dev/null 2>&1
    apt-get autoremove -y >/dev/null 2>&1
    apt-get autoclean -y >/dev/null 2>&1

    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
}

fun_bar "desinstalar_haproxy_completo"

linea
echo "HAPROXY SSL ELIMINADO COMPLETAMENTE"
echo "Puedes volver a instalar HAProxy SSL limpio sin errores"
linea

read -p "Presiona ENTER para continuar..."
return 0
}

cert_haproxy () {
clean_screen
echo "AGREGAR CERTIFICADO HAPROXY SSL"
linea
echo "INGRESA EL LINK DEL CERTIFICADO ZIP"
read -p "LINK: " linksd
linea

instalar_certificado_haproxy_zip() {
    mkdir -p /etc/haproxy/certs
    limpiar_certificado_haproxy
    rm -f /etc/haproxy/certs/certificado.zip
    rm -f /etc/haproxy/certs/private.key /etc/haproxy/certs/certificate.crt /etc/haproxy/certs/ca_bundle.crt

    wget -q "$linksd" -O /etc/haproxy/certs/certificado.zip || return 1
    cd /etc/haproxy/certs || return 1
    unzip -o certificado.zip >/dev/null 2>&1 || return 1

    if [[ -f private.key && -f certificate.crt && -f ca_bundle.crt ]]; then
        cat certificate.crt ca_bundle.crt private.key > haproxy.pem
    elif [[ -f private.key && -f certificate.crt ]]; then
        cat certificate.crt private.key > haproxy.pem
    else
        return 1
    fi

    chmod 600 /etc/haproxy/certs/haproxy.pem
    chown root:root /etc/haproxy/certs/haproxy.pem 2>/dev/null
    openssl x509 -in /etc/haproxy/certs/haproxy.pem -noout >/dev/null 2>&1 || return 1
}

fun_bar "instalar_certificado_haproxy_zip" || {
    echo "No se pudo instalar el certificado. Verifica el ZIP."
    read -p "Presiona ENTER para continuar..."
    return 1
}

ultimo_puerto="$(awk -F'|' 'END{print $2}' /etc/haproxy/newgolden.map 2>/dev/null)"

if [[ -n "$ultimo_puerto" ]] && restart_haproxy_compatible "$ultimo_puerto"; then
    linea
    echo "CERTIFICADO HAPROXY INSTALADO CON EXITO"
    linea
else
    linea
    echo "CERTIFICADO INSTALADO, PERO HAPROXY NO REINICIO"
    echo "cat /tmp/haproxy_test.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

gestor_fun () {
while true; do
clean_screen
mostrar_haproxy_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR HAPROXY SSL${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  ${cor[3]}ABRIR PUERTO HAPROXY SSL${cor[0]}"
echo -e "   ${cor[2]}[2]${cor[0]}  AGREGAR MAS PUERTOS SSL"
echo -e "   ${cor[2]}[3]${cor[0]}  REDIRECCIONAR PUERTO SSL"
echo -e "   ${cor[2]}[4]${cor[0]}  ${cor[2]}DESINSTALAR HAPROXY SSL${cor[0]}"
echo -e "   ${cor[2]}[5]${cor[0]}  AGREGAR CERTIFICADO SSL"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-5]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1) haproxy_ssl ;;
    2) haproxy_puerto ;;
    3) haproxy_redir ;;
    4) detener_haproxy ;;
    5) cert_haproxy ;;
esac
done
}

gestor_fun
