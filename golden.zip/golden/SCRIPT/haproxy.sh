#!/bin/bash

# Golden REV26.24: HAProxy SSL + 443 compartido + gestor seguro de certificados SSL.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive


SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ echo -e "\033[0;33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[0m"; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

type msg >/dev/null 2>&1 || msg(){
case "$1" in
-bar) linea ;;
-ama) shift; echo -e "${cor[3]}$*${cor[0]}" ;;
-azu) shift; echo -e "${cor[1]}$*${cor[0]}" ;;
-bra) shift; echo -e "${cor[0]}$*" ;;
*) echo -e "$*" ;;
esac
}

fun_bar () {
    local comando="${1:-true}"
    if declare -F golden_progress_command >/dev/null 2>&1; then
        golden_progress_command "Procesando HAProxy SSL" "$comando" "/tmp/haproxy_install.log"
        return $?
    fi
    eval "$comando" >"/tmp/haproxy_install.log" 2>&1
}


valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

mportas () {
    if command -v ss >/dev/null 2>&1; then
        ss -ltnp 2>/dev/null | awk '
        NR>1 {
            n=split($4,a,":");
            port=a[n];
            proc=$0;
            name="desconocido";
            if (proc ~ /haproxy/) name="haproxyssl";
            else if (proc ~ /stunnel/) name="stunnel4";
            else if (proc ~ /sshd/) name="sshd";
            else if (proc ~ /dropbear/) name="dropbear";
            else if (proc ~ /apache2/) name="apache2";
            else if (proc ~ /badvpn/) name="badvpn-ud";
            else if (proc ~ /rusty/) name="rustyprox";
            else if (proc ~ /xray/) name="xray";
            else if (proc ~ /v2ray/) name="v2ray";
            print name" "port;
        }' | sort -u
    else
        netstat -ltnp 2>/dev/null | awk '
        NR>2 {
            n=split($4,a,":");
            port=a[n];
            print "desconocido "port;
        }' | sort -u
    fi
}

port_in_use() {
    mportas | awk '{print $2}' | grep -wq "$1"
}

# Localiza el MISMO proxygo.sh instalado por Golden. La opcion [6] no incluye
# una segunda implementacion de ProxyGo: delega al script oficial del panel.
find_proxygo_script_shared443() {
    local here f
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in \
        "${SCPinst}/proxygo.sh" \
        "${SCPfrm}/proxygo.sh" \
        "/etc/SCRIPT/proxygo.sh" \
        "${here}/proxygo.sh"; do
        [[ -x "$f" || -r "$f" ]] || continue
        printf '%s\n' "$f"
        return 0
    done
    return 1
}

asegurar_proxygo_80_shared443() {
    local proxygo_script
    proxygo_script="$(find_proxygo_script_shared443)" || {
        echo "ERROR: no se encontro proxygo.sh de NEW GOLDEN."
        return 1
    }

    # El subcomando fue agregado al mismo ProxyGo estable para que una VPS
    # virgen instale/repare el core y, si TCP/80 esta libre, cree :80 -> :22.
    # Si :80 ya pertenece a otro servicio, ProxyGo no lo desplaza.
    bash "$proxygo_script" --ensure-shared443-port80 22
}

instalar_base_haproxy() {
    local old_wait="${GOLDEN_APT_LOCK_WAIT:-600}"
    local need_update=0

    # La instalación principal de Golden ya deja curl/wget/openssl/iproute2 listos.
    # HAProxy no vuelve a instalar una lista grande de paquetes ni ejecuta update
    # incondicionalmente. Solo instala lo que realmente falte.
    command -v openssl >/dev/null 2>&1 || need_update=1
    command -v ss >/dev/null 2>&1 || need_update=1
    command -v haproxy >/dev/null 2>&1 || need_update=1
    (( need_update == 0 )) && return 0

    # Un protocolo no puede quedar 10 minutos aparentando estar congelado.
    GOLDEN_APT_LOCK_WAIT=120

    # Si el bootstrap dejó el stamp reciente, golden_apt_update retorna sin tocar APT.
    # Si no hay stamp, actualiza una sola vez con timeout global de compat.sh.
    golden_apt_update || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }

    command -v openssl >/dev/null 2>&1 || golden_install_required openssl || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }
    command -v ss >/dev/null 2>&1 || golden_install_iproute || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }
    command -v haproxy >/dev/null 2>&1 || golden_install_required haproxy || { GOLDEN_APT_LOCK_WAIT="$old_wait"; return 1; }

    GOLDEN_APT_LOCK_WAIT="$old_wait"
    command -v haproxy >/dev/null 2>&1
}

optimizar_haproxy_ssl() {
    mkdir -p /etc/sysctl.d
    mkdir -p /etc/security/limits.d
    mkdir -p /etc/systemd/system.conf.d
    mkdir -p /etc/systemd/user.conf.d
    mkdir -p /etc/systemd/system/haproxy.service.d

cat >/etc/sysctl.d/99-newgolden-haproxy.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_syn_retries = 3
net.ipv4.tcp_synack_retries = 3
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_mtu_probing = 1
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF

    sysctl --system >/dev/null 2>&1

cat >/etc/security/limits.d/99-newgolden-haproxy.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
haproxy soft nofile 1048576
haproxy hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/system/haproxy.service.d/override.conf <<'EOF'
[Service]
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Restart=always
RestartSec=2
EOF

    systemctl daemon-reload >/dev/null 2>&1
}

optimizar_sshd_haproxy() {
    mkdir -p /etc/ssh/sshd_config.d

    sed -i '/^MaxStartups/d;/^MaxSessions/d;/^LoginGraceTime/d;/^ClientAliveInterval/d;/^ClientAliveCountMax/d;/^TCPKeepAlive/d;/^UseDNS/d;/^GSSAPIAuthentication/d;/^Compression/d' /etc/ssh/sshd_config 2>/dev/null

cat >/etc/ssh/sshd_config.d/99-newgolden-haproxy.conf <<'EOF'
MaxStartups 2000:30:5000
MaxSessions 5000
LoginGraceTime 15
ClientAliveInterval 60
ClientAliveCountMax 2
TCPKeepAlive yes
UseDNS no
GSSAPIAuthentication no
Compression no
EOF

    if command -v sshd >/dev/null 2>&1; then
        sshd -t >/tmp/sshd_haproxy_test.log 2>&1 || {
            echo "ERROR EN CONFIG SSHD"
            cat /tmp/sshd_haproxy_test.log
            return 1
        }
    fi

    systemctl restart ssh 2>/dev/null
    systemctl restart sshd 2>/dev/null
    service ssh restart 2>/dev/null
    service sshd restart 2>/dev/null
    return 0
}

HAPROXY_CERT_DIR="/etc/haproxy/certs"
HAPROXY_CERT_ACTIVE="${HAPROXY_CERT_DIR}/haproxy.pem"
HAPROXY_CERT_DEFAULT="${HAPROXY_CERT_DIR}/haproxy.default.pem"
HAPROXY_CERT_MODE="${HAPROXY_CERT_DIR}/newgolden-cert.mode"
HAPROXY_CERT_DOMAIN="${HAPROXY_CERT_DIR}/newgolden-cert.domain"
HAPROXY_ACME_FULLCHAIN="${HAPROXY_CERT_DIR}/acme-fullchain.pem"
HAPROXY_ACME_KEY="${HAPROXY_CERT_DIR}/acme-private.key"
HAPROXY_ACME_RELOAD="/etc/haproxy/newgolden-acme-reload.sh"

limpiar_certificado_haproxy() {
    rm -f "$HAPROXY_CERT_ACTIVE"
    rm -f /tmp/haproxy.key
    rm -f /tmp/haproxy.crt
}

cert_haproxy_pem_valido() {
    local pem="$1" cert_pub key_pub
    [[ -s "$pem" ]] || return 1
    openssl x509 -in "$pem" -noout >/dev/null 2>&1 || return 1
    openssl x509 -in "$pem" -checkend 0 -noout >/dev/null 2>&1 || return 1
    openssl pkey -in "$pem" -noout >/dev/null 2>&1 || return 1
    cert_pub="$(openssl x509 -in "$pem" -pubkey -noout 2>/dev/null | openssl pkey -pubin -outform DER 2>/dev/null | sha256sum 2>/dev/null | awk '{print $1}')"
    key_pub="$(openssl pkey -in "$pem" -pubout -outform DER 2>/dev/null | sha256sum 2>/dev/null | awk '{print $1}')"
    [[ -n "$cert_pub" && "$cert_pub" == "$key_pub" ]]
}

cert_haproxy_pair_valido() {
    local cert="$1" key="$2" cert_pub key_pub
    [[ -s "$cert" && -s "$key" ]] || return 1
    openssl x509 -in "$cert" -noout >/dev/null 2>&1 || return 1
    openssl x509 -in "$cert" -checkend 0 -noout >/dev/null 2>&1 || return 1
    openssl pkey -in "$key" -noout >/dev/null 2>&1 || return 1
    cert_pub="$(openssl x509 -in "$cert" -pubkey -noout 2>/dev/null | openssl pkey -pubin -outform DER 2>/dev/null | sha256sum 2>/dev/null | awk '{print $1}')"
    key_pub="$(openssl pkey -in "$key" -pubout -outform DER 2>/dev/null | sha256sum 2>/dev/null | awk '{print $1}')"
    [[ -n "$cert_pub" && "$cert_pub" == "$key_pub" ]]
}

cert_haproxy_valido_para_dominio() {
    local cert="$1" dominio="$2" min_seconds="${3:-86400}"
    [[ -s "$cert" && -n "$dominio" ]] || return 1
    openssl x509 -in "$cert" -noout >/dev/null 2>&1 || return 1
    openssl x509 -in "$cert" -checkend "$min_seconds" -noout >/dev/null 2>&1 || return 1
    if openssl x509 -in "$cert" -noout -checkhost "$dominio" >/dev/null 2>&1; then
        return 0
    fi
    openssl x509 -in "$cert" -noout -text 2>/dev/null | grep -Fqi "$dominio"
}

cert_haproxy_dominio_valido() {
    local d="${1,,}" label
    local -a labels=()
    [[ ${#d} -le 253 ]] || return 1
    [[ "$d" == *.* ]] || return 1
    [[ "$d" != .* && "$d" != *. && "$d" != *..* ]] || return 1
    [[ "$d" =~ ^[a-z0-9.-]+$ ]] || return 1
    [[ ! "$d" =~ ^[0-9.]+$ ]] || return 1
    IFS='.' read -r -a labels <<<"$d"
    for label in "${labels[@]}"; do
        [[ ${#label} -ge 1 && ${#label} -le 63 ]] || return 1
        [[ "$label" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]] || return 1
    done
    return 0
}

cert_haproxy_email_valido() {
    [[ "$1" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]]
}

cert_haproxy_guardar_default_si_falta() {
    local mode=''
    mkdir -p "$HAPROXY_CERT_DIR"
    [[ -s "$HAPROXY_CERT_DEFAULT" ]] && cert_haproxy_pem_valido "$HAPROXY_CERT_DEFAULT" && return 0
    [[ -f "$HAPROXY_CERT_MODE" ]] && mode="$(cat "$HAPROXY_CERT_MODE" 2>/dev/null || true)"
    [[ -n "$mode" && "$mode" != 'default' ]] && return 1
    if [[ -s "$HAPROXY_CERT_ACTIVE" ]] && cert_haproxy_pem_valido "$HAPROXY_CERT_ACTIVE"; then
        cp -f "$HAPROXY_CERT_ACTIVE" "$HAPROXY_CERT_DEFAULT"
        chmod 600 "$HAPROXY_CERT_DEFAULT"
        chown root:root "$HAPROXY_CERT_DEFAULT" 2>/dev/null || true
        return 0
    fi
    return 1
}

crear_cert_autofirmado_haproxy() {
    local dominio="$1" salida="$2" tmpd key crt
    tmpd="$(mktemp -d /tmp/newgolden-haproxy-self.XXXXXX)" || return 1
    key="$tmpd/key.pem"
    crt="$tmpd/cert.pem"

    openssl genrsa -out "$key" 2048 >/dev/null 2>&1 || { rm -rf "$tmpd"; return 1; }
    openssl req -new -x509 -days 1000 \
        -key "$key" \
        -out "$crt" \
        -subj "/C=US/ST=SSL/L=SSL/O=NEWGOLDEN/OU=VPN/CN=${dominio}" >/dev/null 2>&1 || { rm -rf "$tmpd"; return 1; }

    cat "$crt" "$key" > "$salida"
    chmod 600 "$salida"
    rm -rf "$tmpd"
    cert_haproxy_pem_valido "$salida"
}

# REV26.24: generador exclusivo para la opción [3]. No altera la lógica
# histórica de generar_cert_haproxy(). El nuevo default incluye SAN para
# que el nombre elegido (dominio o localhost) quede realmente dentro del cert.
crear_cert_default_nuevo_haproxy() {
    local nombre="$1" salida="$2" tmpd key crt cfg
    tmpd="$(mktemp -d /tmp/newgolden-haproxy-default-new.XXXXXX)" || return 1
    key="$tmpd/key.pem"
    crt="$tmpd/cert.pem"
    cfg="$tmpd/openssl.cnf"

    cat >"$cfg" <<EOF_CERTCFG
[req]
prompt = no
distinguished_name = dn
x509_extensions = v3_req

[dn]
C = US
ST = SSL
L = SSL
O = NEWGOLDEN
OU = VPN
CN = ${nombre}

[v3_req]
basicConstraints = critical,CA:FALSE
keyUsage = critical,digitalSignature,keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1 = ${nombre}
EOF_CERTCFG
    if [[ "$nombre" == "localhost" ]]; then
        printf '%s\n' 'IP.1 = 127.0.0.1' >>"$cfg"
    fi

    openssl genrsa -out "$key" 2048 >/dev/null 2>&1 || { rm -rf "$tmpd"; return 1; }
    openssl req -new -x509 -sha256 -days 1000 \
        -key "$key" \
        -out "$crt" \
        -config "$cfg" \
        -extensions v3_req >/dev/null 2>&1 || { rm -rf "$tmpd"; return 1; }

    cat "$crt" "$key" > "$salida"
    chmod 600 "$salida"
    if ! cert_haproxy_pem_valido "$salida" || ! cert_haproxy_valido_para_dominio "$salida" "$nombre" 86400; then
        rm -rf "$tmpd"
        rm -f "$salida"
        return 1
    fi
    rm -rf "$tmpd"
    return 0
}

generar_cert_haproxy() {
    local dominio="${1:-}" tmpd candidate
    mkdir -p "$HAPROXY_CERT_DIR"

    if [[ -z "$dominio" ]]; then
        echo -ne "Ingrese dominio SSL/SNI [localhost]: "
        read -r dominio
        dominio="$(echo "${dominio:-localhost}" | tr -d ' ')"
    fi

    tmpd="$(mktemp -d /tmp/newgolden-haproxy-default.XXXXXX)" || return 1
    candidate="$tmpd/haproxy.pem"
    if ! crear_cert_autofirmado_haproxy "$dominio" "$candidate"; then
        rm -rf "$tmpd"
        echo "ERROR: No se pudo generar el certificado SSL"
        return 1
    fi

    install -m 600 "$candidate" "${HAPROXY_CERT_ACTIVE}.new" || { rm -rf "$tmpd"; return 1; }
    mv -f "${HAPROXY_CERT_ACTIVE}.new" "$HAPROXY_CERT_ACTIVE"
    chown root:root "$HAPROXY_CERT_ACTIVE" 2>/dev/null || true
    cp -f "$HAPROXY_CERT_ACTIVE" "$HAPROXY_CERT_DEFAULT"
    chmod 600 "$HAPROXY_CERT_DEFAULT"
    printf '%s\n' 'default' > "$HAPROXY_CERT_MODE"
    rm -f "$HAPROXY_CERT_DOMAIN"
    rm -rf "$tmpd"

    echo "Certificado SSL HAProxy predeterminado generado correctamente"
    return 0
}

asegurar_cert_haproxy() {
    if [[ -s "$HAPROXY_CERT_ACTIVE" ]] && cert_haproxy_pem_valido "$HAPROXY_CERT_ACTIVE"; then
        cert_haproxy_guardar_default_si_falta >/dev/null 2>&1 || true
        return 0
    fi

    echo "Certificado dañado o inexistente. Creando nuevo..."
    generar_cert_haproxy
}

cert_haproxy_puerto_check() {
    local p=""
    [[ -f /etc/haproxy/newgolden.shared443 ]] && { printf '443\n'; return 0; }
    p="$(awk -F'|' 'END{print $2}' /etc/haproxy/newgolden.map 2>/dev/null)"
    if [[ -z "$p" && -f /etc/haproxy/haproxy.cfg ]]; then
        p="$(awk '/^[[:space:]]*bind[[:space:]]+/{v=$2; sub(/^.*:/,"",v); sub(/[^0-9].*$/,"",v); if (v ~ /^[0-9]+$/) {print v; exit}}' /etc/haproxy/haproxy.cfg 2>/dev/null)"
    fi
    [[ -n "$p" ]] && printf '%s\n' "$p"
    return 0
}

cert_haproxy_aplicar_pem() {
    local candidate="$1" mode="$2" dominio="${3:-}" check_port olddir had_active=0 old_mode='' old_domain=''
    cert_haproxy_pem_valido "$candidate" || { echo "ERROR: El certificado y su clave privada no son válidos o no corresponden."; return 1; }

    mkdir -p "$HAPROXY_CERT_DIR"
    cert_haproxy_guardar_default_si_falta >/dev/null 2>&1 || true
    olddir="$(mktemp -d /tmp/newgolden-haproxy-cert-old.XXXXXX)" || return 1
    if [[ -s "$HAPROXY_CERT_ACTIVE" ]]; then
        cp -f "$HAPROXY_CERT_ACTIVE" "$olddir/haproxy.pem"
        had_active=1
    fi
    [[ -f "$HAPROXY_CERT_MODE" ]] && old_mode="$(cat "$HAPROXY_CERT_MODE" 2>/dev/null || true)"
    [[ -f "$HAPROXY_CERT_DOMAIN" ]] && old_domain="$(cat "$HAPROXY_CERT_DOMAIN" 2>/dev/null || true)"

    install -m 600 "$candidate" "${HAPROXY_CERT_ACTIVE}.new" || { rm -rf "$olddir"; return 1; }
    chown root:root "${HAPROXY_CERT_ACTIVE}.new" 2>/dev/null || true
    mv -f "${HAPROXY_CERT_ACTIVE}.new" "$HAPROXY_CERT_ACTIVE"
    printf '%s\n' "$mode" > "$HAPROXY_CERT_MODE"
    if [[ -n "$dominio" ]]; then printf '%s\n' "$dominio" > "$HAPROXY_CERT_DOMAIN"; else rm -f "$HAPROXY_CERT_DOMAIN"; fi

    check_port="$(cert_haproxy_puerto_check)"
    if [[ -n "$check_port" && -f /etc/haproxy/haproxy.cfg && -x "$(command -v haproxy 2>/dev/null)" ]]; then
        if ! restart_haproxy_compatible "$check_port"; then
            echo "ERROR: El certificado nuevo no permitió iniciar HAProxy. Restaurando el anterior..."
            if (( had_active == 1 )); then
                cp -f "$olddir/haproxy.pem" "$HAPROXY_CERT_ACTIVE"
                chmod 600 "$HAPROXY_CERT_ACTIVE"
            else
                rm -f "$HAPROXY_CERT_ACTIVE"
            fi
            if [[ -n "$old_mode" ]]; then printf '%s\n' "$old_mode" > "$HAPROXY_CERT_MODE"; else rm -f "$HAPROXY_CERT_MODE"; fi
            if [[ -n "$old_domain" ]]; then printf '%s\n' "$old_domain" > "$HAPROXY_CERT_DOMAIN"; else rm -f "$HAPROXY_CERT_DOMAIN"; fi
            if (( had_active == 1 )); then restart_haproxy_compatible "$check_port" >/dev/null 2>&1 || true; fi
            rm -rf "$olddir"
            return 1
        fi
    fi
    rm -rf "$olddir"
    return 0
}

cert_haproxy_mostrar_estado() {
    local mode='default' domain='' subject='' issuer='' expiry=''
    [[ -f "$HAPROXY_CERT_MODE" ]] && mode="$(cat "$HAPROXY_CERT_MODE" 2>/dev/null || echo default)"
    [[ -f "$HAPROXY_CERT_DOMAIN" ]] && domain="$(cat "$HAPROXY_CERT_DOMAIN" 2>/dev/null || true)"
    if [[ -s "$HAPROXY_CERT_ACTIVE" ]] && openssl x509 -in "$HAPROXY_CERT_ACTIVE" -noout >/dev/null 2>&1; then
        subject="$(openssl x509 -in "$HAPROXY_CERT_ACTIVE" -noout -subject 2>/dev/null | sed 's/^subject=//')"
        issuer="$(openssl x509 -in "$HAPROXY_CERT_ACTIVE" -noout -issuer 2>/dev/null | sed 's/^issuer=//')"
        expiry="$(openssl x509 -in "$HAPROXY_CERT_ACTIVE" -noout -enddate 2>/dev/null | sed 's/^notAfter=//')"
        echo -e "   ${cor[4]}[ACTIVO]${cor[0]} modo: ${mode}"
        [[ -n "$domain" ]] && echo "   Dominio: $domain"
        [[ -n "$subject" ]] && echo "   Subject: $subject"
        [[ -n "$issuer" ]] && echo "   Emisor : $issuer"
        [[ -n "$expiry" ]] && echo "   Vence  : $expiry"
    else
        echo -e "   ${cor[2]}[SIN CERTIFICADO VALIDO]${cor[0]}"
    fi
}

cert_haproxy_instalar_zip() {
    local linksd tmpd zip cert='' key='' chain='' candidate
    echo "INGRESA EL LINK DEL CERTIFICADO ZIP"
    read -r -p "LINK: " linksd
    [[ "$linksd" =~ ^https?:// ]] || { echo "ERROR: El enlace debe comenzar con http:// o https://"; return 1; }

    tmpd="$(mktemp -d /tmp/newgolden-haproxy-zip.XXXXXX)" || return 1
    zip="$tmpd/certificado.zip"
    echo "Descargando y validando certificado antes de aplicarlo..."
    golden_fetch "$linksd" "$zip" || { rm -rf "$tmpd"; echo "ERROR: No se pudo descargar el ZIP."; return 1; }
    command -v unzip >/dev/null 2>&1 || { golden_apt_update >/dev/null 2>&1 || true; golden_install_required unzip || { rm -rf "$tmpd"; return 1; }; }
    unzip -q -o "$zip" -d "$tmpd/extract" >/dev/null 2>&1 || { rm -rf "$tmpd"; echo "ERROR: El archivo descargado no es un ZIP válido."; return 1; }

    for cert in "$tmpd/extract/certificate.crt" "$tmpd/extract/fullchain.pem" "$tmpd/extract/fullchain.cer" "$tmpd/extract/cert.pem"; do [[ -s "$cert" ]] && break; done
    [[ -s "$cert" ]] || cert="$(find "$tmpd/extract" -maxdepth 2 -type f \( -name 'certificate.crt' -o -name 'fullchain.pem' -o -name 'fullchain.cer' -o -name 'cert.pem' \) -print -quit 2>/dev/null)"
    for key in "$tmpd/extract/private.key" "$tmpd/extract/privkey.pem" "$tmpd/extract/key.pem"; do [[ -s "$key" ]] && break; done
    [[ -s "$key" ]] || key="$(find "$tmpd/extract" -maxdepth 2 -type f \( -name 'private.key' -o -name 'privkey.pem' -o -name 'key.pem' \) -print -quit 2>/dev/null)"
    [[ -s "$cert" && -s "$key" ]] || { rm -rf "$tmpd"; echo "ERROR: El ZIP debe incluir certificado/fullchain y clave privada."; return 1; }
    cert_haproxy_pair_valido "$cert" "$key" || { rm -rf "$tmpd"; echo "ERROR: Certificado inválido, expirado o la clave privada no corresponde."; return 1; }

    chain="$(find "$tmpd/extract" -maxdepth 2 -type f \( -name 'ca_bundle.crt' -o -name 'chain.pem' -o -name 'ca_bundle.pem' \) -print -quit 2>/dev/null)"
    candidate="$tmpd/haproxy.pem"
    if [[ "$(basename "$cert")" == fullchain.* || -z "$chain" ]]; then
        cat "$cert" "$key" > "$candidate"
    else
        cat "$cert" "$chain" "$key" > "$candidate"
    fi
    chmod 600 "$candidate"
    cert_haproxy_pem_valido "$candidate" || { rm -rf "$tmpd"; echo "ERROR: El PEM final no pasó la validación."; return 1; }

    if cert_haproxy_aplicar_pem "$candidate" 'zip' ''; then
        rm -rf "$tmpd"
        echo "CERTIFICADO HAPROXY INSTALADO Y VALIDADO CORRECTAMENTE"
        return 0
    fi
    rm -rf "$tmpd"
    return 1
}

cert_haproxy_public_ipv4() {
    local ip=''
    if [[ -n "${GOLDEN_CURL_BIN:-}" && -x "${GOLDEN_CURL_BIN:-}" ]]; then
        ip="$(golden_run_timeout 15 "$GOLDEN_CURL_BIN" -4 -fsS --connect-timeout 5 --max-time 10 https://api.ipify.org 2>/dev/null || true)"
        [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || ip="$(golden_run_timeout 15 "$GOLDEN_CURL_BIN" -4 -fsS --connect-timeout 5 --max-time 10 https://ipv4.icanhazip.com 2>/dev/null | tr -d '\r\n' || true)"
    fi
    [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] && printf '%s\n' "$ip"
}

cert_haproxy_dns_apunta_vps() {
    local dominio="$1" public_ip dns_ips
    public_ip="$(cert_haproxy_public_ipv4)"
    [[ -n "$public_ip" ]] || { echo "ERROR: No se pudo detectar la IPv4 pública de esta VPS."; return 1; }
    dns_ips="$(getent ahostsv4 "$dominio" 2>/dev/null | awk '{print $1}' | sort -u)"
    [[ -n "$dns_ips" ]] || { echo "ERROR: El dominio no tiene resolución IPv4 (registro A)."; return 1; }
    if ! grep -Fxq "$public_ip" <<<"$dns_ips"; then
        echo "ERROR: El dominio no apunta directamente a esta VPS."
        echo "IPv4 de la VPS : $public_ip"
        echo "DNS del dominio: $(tr '\n' ' ' <<<"$dns_ips")"
        echo "Corrige el registro A y desactiva proxy/CDN temporalmente si lo hubiera."
        return 1
    fi
    echo "DNS verificado: $dominio -> $public_ip"
    return 0
}

cert_haproxy_preparar_reload_acme() {
    cat > "$HAPROXY_ACME_RELOAD" <<'EOF_RELOAD'
#!/bin/bash
set -u
ACTION="${1:-deploy}"
DOMAIN="${2:-}"
CERT_DIR=/etc/haproxy/certs
MODE_FILE="$CERT_DIR/newgolden-cert.mode"
DOMAIN_FILE="$CERT_DIR/newgolden-cert.domain"
FULLCHAIN="$CERT_DIR/acme-fullchain.pem"
KEY="$CERT_DIR/acme-private.key"
ACTIVE="$CERT_DIR/haproxy.pem"
SAFE_DOMAIN="$(printf '%s' "$DOMAIN" | tr -c 'A-Za-z0-9_.-' '_')"
MARKER="/run/newgolden-haproxy-acme-${SAFE_DOMAIN}.was_active"

mode_matches() {
    [[ -n "$DOMAIN" && -s "$MODE_FILE" && -s "$DOMAIN_FILE" ]] || return 1
    [[ "$(cat "$MODE_FILE" 2>/dev/null)" == "acme" ]] || return 1
    [[ "$(cat "$DOMAIN_FILE" 2>/dev/null)" == "$DOMAIN" ]]
}

service_active() {
    systemctl is-active --quiet haproxy >/dev/null 2>&1 || service haproxy status >/dev/null 2>&1
}

case "$ACTION" in
pre)
    # Solo interrumpe HAProxy si ESTE certificado sigue seleccionado.
    mode_matches || exit 0
    if service_active; then
        mkdir -p /run 2>/dev/null || true
        : > "$MARKER"
        systemctl stop haproxy >/dev/null 2>&1 || service haproxy stop >/dev/null 2>&1 || exit 1
    fi
    exit 0
    ;;
post)
    # Aunque la renovación falle, restaura el servicio que estaba activo.
    if [[ -f "$MARKER" ]]; then
        systemctl start haproxy >/dev/null 2>&1 || service haproxy start >/dev/null 2>&1 || true
        rm -f "$MARKER"
    fi
    exit 0
    ;;
deploy)
    mode_matches || exit 0
    [[ -s "$FULLCHAIN" && -s "$KEY" ]] || exit 1
    TMP="${ACTIVE}.renew.$$"
    cat "$FULLCHAIN" "$KEY" > "$TMP" || exit 1
    chmod 600 "$TMP"
    openssl x509 -in "$TMP" -checkend 86400 -noout >/dev/null 2>&1 || { rm -f "$TMP"; exit 1; }
    openssl pkey -in "$TMP" -noout >/dev/null 2>&1 || { rm -f "$TMP"; exit 1; }
    CERT_PUB="$(openssl x509 -in "$TMP" -pubkey -noout 2>/dev/null | openssl pkey -pubin -outform DER 2>/dev/null | sha256sum 2>/dev/null | awk '{print $1}')"
    KEY_PUB="$(openssl pkey -in "$TMP" -pubout -outform DER 2>/dev/null | sha256sum 2>/dev/null | awk '{print $1}')"
    [[ -n "$CERT_PUB" && "$CERT_PUB" == "$KEY_PUB" ]] || { rm -f "$TMP"; exit 1; }
    if openssl x509 -in "$TMP" -noout -checkhost "$DOMAIN" >/dev/null 2>&1 || openssl x509 -in "$TMP" -noout -text 2>/dev/null | grep -Fqi "$DOMAIN"; then
        OLD="${ACTIVE}.pre-renew.$$"
        HAD_OLD=0
        if [[ -s "$ACTIVE" ]]; then cp -f "$ACTIVE" "$OLD" && HAD_OLD=1; fi
        mv -f "$TMP" "$ACTIVE"
        chown root:root "$ACTIVE" 2>/dev/null || true
        if command -v haproxy >/dev/null 2>&1 && [[ -f /etc/haproxy/haproxy.cfg ]]; then
            if ! haproxy -c -f /etc/haproxy/haproxy.cfg >/dev/null 2>&1; then
                if (( HAD_OLD == 1 )); then mv -f "$OLD" "$ACTIVE"; else rm -f "$ACTIVE"; fi
                exit 1
            fi
            if service_active || [[ -f "$MARKER" ]]; then
                if ! (systemctl restart haproxy >/dev/null 2>&1 || service haproxy restart >/dev/null 2>&1); then
                    if (( HAD_OLD == 1 )); then mv -f "$OLD" "$ACTIVE"; else rm -f "$ACTIVE"; fi
                    systemctl start haproxy >/dev/null 2>&1 || service haproxy start >/dev/null 2>&1 || true
                    exit 1
                fi
            fi
        fi
        rm -f "$OLD"
        exit 0
    fi
    rm -f "$TMP"
    exit 1
    ;;
*) exit 2 ;;
esac
EOF_RELOAD
    chmod 700 "$HAPROXY_ACME_RELOAD"
}

cert_haproxy_generar_dominio() {
    local dominio email tmpd candidate haproxy_443=0 had_haproxy_active=0 acme_installer rc=0
    linea
    echo "GENERAR CERTIFICADO SSL PUBLICO - LET'S ENCRYPT"
    echo "El dominio debe tener un registro A que apunte DIRECTAMENTE a la IPv4 de esta VPS."
    echo "Para validar sin tocar el puerto 80 se usará TLS-ALPN por TCP 443."
    linea

    while true; do
        read -r -p "Dominio/SNI de la VPS (ej. vpn.midominio.com): " dominio
        dominio="$(echo "${dominio,,}" | tr -d ' ')"
        cert_haproxy_dominio_valido "$dominio" && break
        echo "Dominio inválido. Usa un nombre DNS completo; no IP ni localhost."
    done
    while true; do
        read -r -p "Correo para Let's Encrypt: " email
        email="$(echo "$email" | tr -d ' ')"
        cert_haproxy_email_valido "$email" && break
        echo "Correo inválido."
    done

    cert_haproxy_dns_apunta_vps "$dominio" || return 1

    echo "Verificando dependencias ACME..."
    golden_apt_update >/dev/null 2>&1 || true
    golden_install_required ca-certificates openssl curl socat || { echo "ERROR: No se pudieron instalar dependencias para ACME."; return 1; }

    if [[ ! -x "$HOME/.acme.sh/acme.sh" ]]; then
        acme_installer="/tmp/newgolden-acme-install.sh"
        golden_fetch "https://get.acme.sh" "$acme_installer" || { echo "ERROR: No se pudo descargar acme.sh."; return 1; }
        golden_run_timeout 180 sh "$acme_installer" email="$email" >/tmp/haproxy_acme.log 2>&1 || { rm -f "$acme_installer"; echo "ERROR: No se pudo instalar acme.sh. Revisa /tmp/haproxy_acme.log"; return 1; }
        rm -f "$acme_installer"
    fi

    golden_run_timeout 180 "$HOME/.acme.sh/acme.sh" --register-account -m "$email" --server letsencrypt >/tmp/haproxy_acme.log 2>&1 || true
    golden_run_timeout 180 "$HOME/.acme.sh/acme.sh" --set-default-ca --server letsencrypt >>/tmp/haproxy_acme.log 2>&1 || true

    if ss -H -ltnp 2>/dev/null | awk '$4 ~ /:443$/ {print}' | grep -qi haproxy; then
        haproxy_443=1
    elif ss -H -ltnp 2>/dev/null | awk '$4 ~ /:443$/ {print}' | grep -q .; then
        echo "ERROR: TCP 443 está ocupado por otro servicio y no se tocará:"
        ss -H -ltnp 2>/dev/null | awk '$4 ~ /:443$/ {print}'
        return 1
    fi
    if (( haproxy_443 == 1 )); then
        had_haproxy_active=1
    elif golden_service_active haproxy >/dev/null 2>&1; then
        had_haproxy_active=1
    fi

    if (( haproxy_443 == 1 )); then
        echo "Liberando HAProxy :443 solo durante la validación del certificado..."
        golden_service stop haproxy >/dev/null 2>&1 || { echo "ERROR: No se pudo liberar TCP 443."; return 1; }
        sleep 1
    fi
    if ss -H -ltn 2>/dev/null | awk '$4 ~ /:443$/ {found=1} END{exit !found}'; then
        echo "ERROR: TCP 443 sigue ocupado. No se intentará emitir para evitar un certificado incompleto."
        (( had_haproxy_active == 1 )) && golden_service start haproxy >/dev/null 2>&1 || true
        return 1
    fi

    cert_haproxy_preparar_reload_acme
    echo "Solicitando certificado público para $dominio..."
    golden_run_timeout 360 "$HOME/.acme.sh/acme.sh" --issue --server letsencrypt -d "$dominio" --alpn --keylength ec-256 \
        --pre-hook "$HAPROXY_ACME_RELOAD pre '$dominio'" \
        --post-hook "$HAPROXY_ACME_RELOAD post '$dominio'" >>/tmp/haproxy_acme.log 2>&1 || rc=$?

    tmpd="$(mktemp -d /tmp/newgolden-haproxy-acme.XXXXXX)" || {
        (( had_haproxy_active == 1 )) && golden_service start haproxy >/dev/null 2>&1 || true
        return 1
    }
    rm -f "$HAPROXY_ACME_FULLCHAIN" "$HAPROXY_ACME_KEY"
    if [[ -x "$HOME/.acme.sh/acme.sh" ]]; then
        golden_run_timeout 180 "$HOME/.acme.sh/acme.sh" --install-cert -d "$dominio" --ecc \
            --key-file "$HAPROXY_ACME_KEY" \
            --fullchain-file "$HAPROXY_ACME_FULLCHAIN" \
            --reloadcmd "$HAPROXY_ACME_RELOAD deploy '$dominio'" >>/tmp/haproxy_acme.log 2>&1 || true
    fi

    if [[ ! -s "$HAPROXY_ACME_FULLCHAIN" || ! -s "$HAPROXY_ACME_KEY" ]]; then
        echo "ERROR: Let's Encrypt no entregó los archivos del certificado."
        echo "Verifica DNS, acceso público al TCP 443 y límites de emisión."
        echo "Detalle: /tmp/haproxy_acme.log"
        rm -rf "$tmpd"
        (( had_haproxy_active == 1 )) && golden_service start haproxy >/dev/null 2>&1 || true
        return 1
    fi
    if ! cert_haproxy_pair_valido "$HAPROXY_ACME_FULLCHAIN" "$HAPROXY_ACME_KEY" || ! cert_haproxy_valido_para_dominio "$HAPROXY_ACME_FULLCHAIN" "$dominio" 86400; then
        echo "ERROR: El certificado recibido no corresponde al dominio, está vencido o la clave no coincide."
        rm -rf "$tmpd"
        (( had_haproxy_active == 1 )) && golden_service start haproxy >/dev/null 2>&1 || true
        return 1
    fi

    candidate="$tmpd/haproxy.pem"
    cat "$HAPROXY_ACME_FULLCHAIN" "$HAPROXY_ACME_KEY" > "$candidate"
    chmod 600 "$candidate"
    if ! cert_haproxy_pem_valido "$candidate"; then
        echo "ERROR: El PEM final no pasó validación; se mantiene el certificado anterior."
        rm -rf "$tmpd"
        (( had_haproxy_active == 1 )) && golden_service start haproxy >/dev/null 2>&1 || true
        return 1
    fi

    # cert_haproxy_aplicar_pem reinicia HAProxy si ya hay una configuración activa.
    if cert_haproxy_aplicar_pem "$candidate" 'acme' "$dominio"; then
        rm -rf "$tmpd"
        echo "CERTIFICADO LET'S ENCRYPT GENERADO, VALIDADO Y APLICADO CORRECTAMENTE"
        echo "Dominio: $dominio"
        echo "Renovación: acme.sh queda configurado; solo reaplica mientras este certificado siga seleccionado."
        return 0
    fi

    rm -rf "$tmpd"
    (( had_haproxy_active == 1 )) && golden_service start haproxy >/dev/null 2>&1 || true
    return 1
}

cert_haproxy_restaurar_default() {
    local tmpd candidate default_cn opcion_default=''
    mkdir -p "$HAPROXY_CERT_DIR"

    linea
    echo "GENERAR NUEVO CERTIFICADO PREDETERMINADO - NEW GOLDEN"
    echo "El certificado activo se reemplazará SOLO después de generar y validar el nuevo."
    echo "Si HAProxy no acepta el nuevo certificado, se restaura automáticamente el anterior."
    linea
    echo "   [1] USAR DOMINIO / SNI DE LA VPS"
    echo "   [2] USAR LOCALHOST"
    echo "   [0] CANCELAR"
    linea
    while [[ ! "$opcion_default" =~ ^[0-2]$ ]]; do
        read -r -p "Selecciona una opcion: " opcion_default
    done
    [[ "$opcion_default" == '0' ]] && { echo "Operación cancelada."; return 0; }

    if [[ "$opcion_default" == '1' ]]; then
        while true; do
            read -r -p "Dominio/SNI para el certificado (ej. vpn.midominio.com): " default_cn
            default_cn="$(echo "${default_cn,,}" | tr -d ' ')"
            cert_haproxy_dominio_valido "$default_cn" && break
            echo "Dominio inválido. Usa un nombre DNS completo; no IP ni localhost."
        done
    else
        default_cn='localhost'
    fi

    tmpd="$(mktemp -d /tmp/newgolden-haproxy-restore.XXXXXX)" || return 1
    candidate="$tmpd/haproxy.pem"

    echo "Generando un certificado predeterminado NUEVO para: $default_cn"
    if ! crear_cert_default_nuevo_haproxy "$default_cn" "$candidate"; then
        rm -rf "$tmpd"
        echo "ERROR: No se pudo generar o validar el nuevo certificado predeterminado."
        echo "El certificado activo anterior NO fue modificado."
        return 1
    fi

    # Prepara también la copia default antes de tocar el certificado activo.
    # Si esta escritura falla, el certificado actual queda completamente intacto.
    if ! install -m 600 "$candidate" "${HAPROXY_CERT_DEFAULT}.new"; then
        rm -f "${HAPROXY_CERT_DEFAULT}.new"
        rm -rf "$tmpd"
        echo "ERROR: No se pudo preparar la copia del certificado default."
        echo "El certificado activo anterior NO fue modificado."
        return 1
    fi
    chown root:root "${HAPROXY_CERT_DEFAULT}.new" 2>/dev/null || true

    # Aplica con el rollback ya existente de HAProxy. Solo después de un PASS
    # se convierte la copia preparada en el default oficial de NEW GOLDEN.
    if cert_haproxy_aplicar_pem "$candidate" 'default' "$default_cn"; then
        if ! mv -f "${HAPROXY_CERT_DEFAULT}.new" "$HAPROXY_CERT_DEFAULT"; then
            echo "ERROR: El certificado quedó activo, pero no se pudo actualizar la copia default."
            echo "Revisa permisos/espacio en $HAPROXY_CERT_DIR antes de repetir la operación."
            rm -rf "$tmpd"
            return 1
        fi
        chmod 600 "$HAPROXY_CERT_DEFAULT"
        chown root:root "$HAPROXY_CERT_DEFAULT" 2>/dev/null || true
        rm -f "$HAPROXY_ACME_FULLCHAIN" "$HAPROXY_ACME_KEY"
        rm -rf "$tmpd"
        echo "CERTIFICADO ANTERIOR REEMPLAZADO CORRECTAMENTE"
        echo "NUEVO CERTIFICADO PREDETERMINADO DE NEW GOLDEN APLICADO"
        echo "Nombre/SNI: $default_cn"
        return 0
    fi

    rm -f "${HAPROXY_CERT_DEFAULT}.new"
    rm -rf "$tmpd"
    echo "ERROR: El nuevo certificado no pudo aplicarse. Se conserva el certificado anterior."
    return 1
}

activar_haproxy_boot() {
    mkdir -p /etc/haproxy /etc/haproxy/certs
    if declare -F golden_service_enable >/dev/null 2>&1; then
        golden_service_enable haproxy >/dev/null 2>&1 || true
    else
        systemctl enable haproxy >/dev/null 2>&1 || true
    fi
}

write_haproxy_conf() {
    # Configuración deliberadamente mínima: funciona tanto con HAProxy modernos
    # como con las ramas antiguas de Ubuntu/Debian. Evita directivas nuevas como
    # nbthread/expose-fd que hacen fallar versiones viejas.
    cat >/etc/haproxy/haproxy.cfg <<'EOF'
global
    daemon
    maxconn 20000

defaults
    mode tcp
    option dontlognull
    option tcpka
    timeout connect 10s
    timeout client 2h
    timeout server 2h
EOF

    # REV26.17 SHARED443:
    # Un unico HAProxy posee TCP/443 y termina TLS. Tras descifrar, clasifica
    # los primeros bytes de aplicacion sin tocar OpenSSH ni el servicio :80:
    #   - SSH directo normalmente espera el banner del servidor; si envia SSH-
    #     de inmediato tambien se reconoce y se envia a 127.0.0.1:22.
    #   - Un injector/payload envia datos inmediatamente y se envia a :80.
    # El estado se guarda fuera del mapa normal para poder desactivar esta
    # funcion y recuperar la redireccion 443 anterior sin perderla.
    local shared443_active=0
    [[ -f /etc/haproxy/newgolden.shared443 ]] && shared443_active=1

    if (( shared443_active == 1 )); then
        cat >>/etc/haproxy/haproxy.cfg <<'EOF'

# ---------------------------------------------------------------
# TCP/443 COMPARTIDO - NEW GOLDEN
# TLS termina aqui. Sin payload inmediato => SSL DIRECTO/OpenSSH :22.
# Con payload inmediato => servicio local :80.
# ---------------------------------------------------------------
frontend newgolden_shared443_front
    bind 0.0.0.0:443 ssl crt /etc/haproxy/certs/haproxy.pem
    mode tcp
    tcp-request inspect-delay 400ms
    acl shared443_has_payload req.len ge 4
    acl shared443_is_ssh req.payload(0,4) -m str SSH-
    tcp-request content accept if shared443_has_payload
    use_backend newgolden_shared443_ssh_back if shared443_is_ssh
    use_backend newgolden_shared443_payload_back if shared443_has_payload !shared443_is_ssh
    default_backend newgolden_shared443_ssh_back

backend newgolden_shared443_ssh_back
    mode tcp
    server newgolden_shared443_ssh 127.0.0.1:22

backend newgolden_shared443_payload_back
    mode tcp
    server newgolden_shared443_payload 127.0.0.1:80
EOF
    fi

    if [[ -f /etc/haproxy/newgolden.map ]]; then
        while IFS='|' read -r nombre ssl local; do
            [[ -z "$nombre" || -z "$ssl" || -z "$local" ]] && continue
            # Mientras 443 compartido esta activo, conserva la linea antigua
            # en el mapa pero no crea un segundo bind sobre el mismo puerto.
            (( shared443_active == 1 )) && [[ "$ssl" == "443" ]] && continue
            cat >>/etc/haproxy/haproxy.cfg <<EOF

frontend ${nombre}_front
    bind 0.0.0.0:${ssl} ssl crt /etc/haproxy/certs/haproxy.pem
    default_backend ${nombre}_back

backend ${nombre}_back
    server ${nombre}_srv 127.0.0.1:${local}
EOF
        done < /etc/haproxy/newgolden.map
    fi
}

agregar_servicio_haproxy() {
    local nombre="$1"
    local puerto_ssl="$2"
    local puerto_local="$3"

    mkdir -p /etc/haproxy
    touch /etc/haproxy/newgolden.map

    grep -v "|${puerto_ssl}|" /etc/haproxy/newgolden.map > /tmp/newgolden_haproxy.map 2>/dev/null
    mv /tmp/newgolden_haproxy.map /etc/haproxy/newgolden.map

    echo "${nombre}|${puerto_ssl}|${puerto_local}" >> /etc/haproxy/newgolden.map

    write_haproxy_conf
}

restart_haproxy_compatible() {
    local puerto_check="$1" i
    activar_haproxy_boot

    chmod 600 /etc/haproxy/certs/haproxy.pem 2>/dev/null || true
    chown root:root /etc/haproxy/certs/haproxy.pem 2>/dev/null || true
    : >/tmp/haproxy_test.log

    openssl x509 -in /etc/haproxy/certs/haproxy.pem -noout >>/tmp/haproxy_test.log 2>&1 || {
        echo "Certificado dañado. Regenerando..."
        generar_cert_haproxy || return 1
    }

    if declare -F golden_run_timeout >/dev/null 2>&1; then
        golden_run_timeout 20 haproxy -c -f /etc/haproxy/haproxy.cfg >/tmp/haproxy_test.log 2>&1 || {
            echo "ERROR CONFIG HAProxy:"; cat /tmp/haproxy_test.log; return 1;
        }
    else
        haproxy -c -f /etc/haproxy/haproxy.cfg >/tmp/haproxy_test.log 2>&1 || {
            echo "ERROR CONFIG HAProxy:"; cat /tmp/haproxy_test.log; return 1;
        }
    fi

    if declare -F golden_service >/dev/null 2>&1; then
        golden_service restart haproxy >>/tmp/haproxy_test.log 2>&1 || golden_service start haproxy >>/tmp/haproxy_test.log 2>&1 || true
    else
        service haproxy restart >>/tmp/haproxy_test.log 2>&1 || systemctl restart haproxy >>/tmp/haproxy_test.log 2>&1 || true
    fi

    for i in 1 2 3 4 5 6 7 8 9 10; do
        ss -H -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${puerto_check}$" && return 0
        sleep 1
    done

    echo "ERROR REAL DE HAPROXY:"
    cat /tmp/haproxy_test.log
    return 1
}

mostrar_haproxy_activos() {
    linea
    echo -e "        ${cor[3]}HAPROXY SSL ACTIVOS - NEW GOLDEN${cor[0]}"
    linea2

    if ss -ltnp 2>/dev/null | grep -qi haproxy; then
        ss -ltnp 2>/dev/null | grep -i haproxy | awk '{
            split($4,a,":");
            print "   [ONLINE] Puerto SSL : " a[length(a)];
        }'
        if [[ -f /etc/haproxy/newgolden.shared443 ]]; then
            echo -e "   ${cor[4]}[SHARED] 443 -> SSL DIRECTO:22 | PAYLOAD+SSL:80${cor[0]}"
        fi
    else
        echo -e "   ${cor[2]}[OFFLINE] No hay puertos HAProxy SSL activos.${cor[0]}"
    fi
}

haproxy_ssl () {
clean_screen
echo "HAPROXY SSL"
linea
echo "Seleccione un puerto interno abierto"
echo "Ejemplo: 22 OpenSSH, 80 Proxy, 53 Dropbear"
linea

while true; do
    read -p "Local-Port: " portx
    valid_port "$portx" || { echo "Puerto invalido"; continue; }

    if port_in_use "$portx"; then
        break
    else
        echo "Ese puerto interno no esta abierto"
    fi
done

linea
echo "Que puerto desea agregar como SSL"
linea

while true; do
    read -p "Listen-SSL: " SSLPORT
    valid_port "$SSLPORT" || { echo "Puerto invalido"; continue; }

    if port_in_use "$SSLPORT"; then
        echo "Este puerto ya esta en uso"
    else
        break
    fi
done

linea
echo "Instalando HAProxy SSL"
linea

fun_bar "instalar_base_haproxy" || {
    echo "No se pudieron preparar las dependencias de HAProxy. Revisa /tmp/haproxy_install.log"
    return 1
}
asegurar_cert_haproxy || return 1

agregar_servicio_haproxy "haproxy_${SSLPORT}" "$SSLPORT" "$portx"

if restart_haproxy_compatible "$SSLPORT"; then
    linea
    echo "INSTALADO CON EXITO"
    echo "HAProxy SSL: ${SSLPORT} -> LOCAL: ${portx}"
    linea
else
    linea
    echo "ERROR: HAProxy no pudo iniciar"
    echo "cat /etc/haproxy/haproxy.cfg"
    echo "cat /tmp/haproxy_test.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

haproxy_puerto () {
clean_screen
echo "AGREGAR PUERTO HAPROXY SSL OPENSSH"
linea

while true; do
    read -p "Puerto SSL: " SSLPORTr
    valid_port "$SSLPORTr" || { echo "Puerto invalido"; continue; }

    if port_in_use "$SSLPORTr"; then
        echo "Esta puerta esta en uso"
    else
        break
    fi
done

linea
echo "Instalando HAProxy SSL"
linea

fun_bar "instalar_base_haproxy" || {
    echo "No se pudieron preparar las dependencias de HAProxy. Revisa /tmp/haproxy_install.log"
    return 1
}
asegurar_cert_haproxy || return 1

agregar_servicio_haproxy "ssh_${SSLPORTr}" "$SSLPORTr" "22"

if restart_haproxy_compatible "$SSLPORTr"; then
    linea
    echo "AGREGADO CON EXITO"
    echo "HAProxy SSL: ${SSLPORTr} -> LOCAL: 22"
    linea
else
    linea
    echo "ERROR: HAProxy no pudo iniciar"
    echo "cat /etc/haproxy/haproxy.cfg"
    echo "cat /tmp/haproxy_test.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

haproxy_redir () {
clean_screen
echo "REDIRECCIONAR PUERTO HAPROXY SSL"
linea

read -p "Nombre: " namer
namer=$(echo "$namer" | tr -cd 'a-zA-Z0-9_-')
[[ -z "$namer" ]] && namer="redir_ssl"

linea
echo "A que puerto redireccionara el puerto SSL"
linea

while true; do
    read -p "Local-Port: " portd
    valid_port "$portd" || { echo "Puerto local invalido"; continue; }

    if port_in_use "$portd"; then
        break
    else
        echo "Ese puerto local no esta abierto"
    fi
done

linea
echo "Que puerto desea agregar como SSL"
linea

while true; do
    read -p "Puerto SSL: " SSLPORTr
    valid_port "$SSLPORTr" || { echo "Puerto SSL invalido"; continue; }

    if port_in_use "$SSLPORTr"; then
        echo "Esta puerta esta en uso"
    else
        break
    fi
done

linea
echo "Instalando HAProxy SSL"
linea

fun_bar "instalar_base_haproxy" || {
    echo "No se pudieron preparar las dependencias de HAProxy. Revisa /tmp/haproxy_install.log"
    return 1
}
asegurar_cert_haproxy || return 1

agregar_servicio_haproxy "$namer" "$SSLPORTr" "$portd"

if restart_haproxy_compatible "$SSLPORTr"; then
    linea
    echo "REDIRECCION HAPROXY SSL AGREGADA CON EXITO"
    echo "HAProxy SSL: ${SSLPORTr} -> LOCAL: ${portd}"
    linea
else
    linea
    echo "ERROR: HAProxy no pudo iniciar"
    echo "cat /etc/haproxy/haproxy.cfg"
    echo "cat /tmp/haproxy_test.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

haproxy_shared_443 () {
while true; do
clean_screen
linea
echo -e "        ${cor[3]}443 COMPARTIDO SSL DIRECTO + PAYLOAD${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
if [[ -f /etc/haproxy/newgolden.shared443 ]]; then
    echo -e "   ${cor[4]}[ACTIVO]${cor[0]} TCP 443 -> SSL DIRECTO:22 | PAYLOAD+SSL:80"
else
    echo -e "   ${cor[2]}[INACTIVO]${cor[0]} Comparticion especial de TCP 443"
fi
linea
echo -e "   ${cor[2]}[1]${cor[0]}  ACTIVAR / REAPLICAR 443 COMPARTIDO"
echo -e "   ${cor[2]}[2]${cor[0]}  DESACTIVAR 443 COMPARTIDO"
echo -e "   ${cor[2]}[0]${cor[0]}  VOLVER"
linea
local op443=""
while [[ ! "$op443" =~ ^[0-2]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read -r op443
done

case "$op443" in
0) return 0 ;;
1)
    # El destino SSH debe existir. En una VPS normal OpenSSH ya escucha en
    # :22; no se cambia su configuracion ni su puerto de forma automatica.
    if ! port_in_use 22; then
        linea
        echo -e "${cor[2]}ERROR: OpenSSH/local :22 no esta escuchando.${cor[0]}"
        echo "Activa SSH en el puerto 22 antes de compartir 443."
        linea
        read -r -p "Presiona ENTER para continuar..." _
        continue
    fi

    # REV26.20 - VPS VIRGEN / INSTALACION NUEVA:
    # Si ProxyGo no existe, instala EXACTAMENTE el ProxyGo actual del panel.
    # Si existe pero no tiene :80, crea :80 -> :22 usando su funcion oficial.
    # Si :80 esta ocupado por otro servicio, aborta sin matar ni reemplazarlo.
    linea
    echo -e "${cor[3]}Verificando ProxyGo NEW GOLDEN para Payload + SSL...${cor[0]}"
    if ! asegurar_proxygo_80_shared443; then
        linea
        echo -e "${cor[2]}ERROR: No se pudo preparar ProxyGo en TCP :80.${cor[0]}"
        echo "No se modifico ni desplazo ningun servicio que ya ocupe el puerto 80."
        linea
        read -r -p "Presiona ENTER para continuar..." _
        continue
    fi

    # Si 443 pertenece a otro proceso (stunnel, nginx, apache, etc.) no lo
    # mata ni lo reemplaza silenciosamente. Solo se admite libre o HAProxy.
    local listen443
    listen443="$(ss -H -ltnp 2>/dev/null | awk '$4 ~ /:443$/ {print}')"
    if [[ -n "$listen443" ]] && ! grep -qi 'haproxy' <<<"$listen443"; then
        linea
        echo -e "${cor[2]}ERROR: TCP 443 esta ocupado por otro servicio.${cor[0]}"
        echo "$listen443"
        echo "Libera/redirige ese 443 antes de activar el modo compartido."
        linea
        read -r -p "Presiona ENTER para continuar..." _
        continue
    fi

    # HAProxy SSL tambien se auto-instala en una VPS virgen usando exactamente
    # la misma funcion/base que las opciones normales de este panel.
    if ! command -v haproxy >/dev/null 2>&1; then
        linea
        echo -e "${cor[3]}HAProxy SSL no esta instalado. Instalando NEW GOLDEN...${cor[0]}"
    fi
    fun_bar "instalar_base_haproxy" || {
        echo "No se pudieron preparar las dependencias de HAProxy. Revisa /tmp/haproxy_install.log"
        read -r -p "Presiona ENTER para continuar..." _
        continue
    }
    asegurar_cert_haproxy || {
        read -r -p "Presiona ENTER para continuar..." _
        continue
    }

    mkdir -p /etc/haproxy
    local had_state=0 backup_cfg=''
    [[ -f /etc/haproxy/newgolden.shared443 ]] && had_state=1
    if [[ -f /etc/haproxy/haproxy.cfg ]]; then
        backup_cfg="/tmp/haproxy.cfg.pre_shared443.$$"
        cp -a /etc/haproxy/haproxy.cfg "$backup_cfg"
    fi

    : > /etc/haproxy/newgolden.shared443
    write_haproxy_conf

    if restart_haproxy_compatible 443; then
        rm -f "$backup_cfg" 2>/dev/null || true
        linea
        echo -e "${cor[4]}443 COMPARTIDO ACTIVADO CORRECTAMENTE${cor[0]}"
        echo "TCP 443 -> TLS HAProxy"
        echo "  SSL directo / SSH -> 127.0.0.1:22"
        echo "  Payload + SSL      -> ProxyGo 127.0.0.1:80"
        echo "Clasificacion post-TLS: payload inmediato a ProxyGo :80; sin payload inmediato a :22."
        echo "HAProxy maxconn: 20000"
        linea
    else
        # Rollback exacto: si la nueva configuracion no levanta, recupera el
        # estado anterior y no deja el 443 roto.
        (( had_state == 0 )) && rm -f /etc/haproxy/newgolden.shared443
        if [[ -n "$backup_cfg" && -f "$backup_cfg" ]]; then
            cp -a "$backup_cfg" /etc/haproxy/haproxy.cfg
            rm -f "$backup_cfg"
            systemctl restart haproxy >/dev/null 2>&1 || service haproxy restart >/dev/null 2>&1 || true
        fi
        linea
        echo -e "${cor[2]}ERROR: no se activo 443 compartido. Se restauro la configuracion anterior.${cor[0]}"
        echo "Revisa: cat /tmp/haproxy_test.log"
        linea
    fi
    read -r -p "Presiona ENTER para continuar..." _
    ;;
2)
    if [[ ! -f /etc/haproxy/newgolden.shared443 ]]; then
        echo "443 compartido ya esta desactivado."
        read -r -p "Presiona ENTER para continuar..." _
        continue
    fi

    rm -f /etc/haproxy/newgolden.shared443
    write_haproxy_conf
    if haproxy -c -f /etc/haproxy/haproxy.cfg >/tmp/haproxy_test.log 2>&1; then
        systemctl restart haproxy >/dev/null 2>&1 || service haproxy restart >/dev/null 2>&1 || true
        linea
        echo -e "${cor[4]}443 COMPARTIDO DESACTIVADO.${cor[0]}"
        echo "Se restauro el comportamiento normal definido en newgolden.map."
        linea
    else
        : > /etc/haproxy/newgolden.shared443
        write_haproxy_conf
        systemctl restart haproxy >/dev/null 2>&1 || service haproxy restart >/dev/null 2>&1 || true
        linea
        echo -e "${cor[2]}ERROR al desactivar. Se mantuvo 443 compartido para no romper el servicio.${cor[0]}"
        cat /tmp/haproxy_test.log
        linea
    fi
    read -r -p "Presiona ENTER para continuar..." _
    ;;
esac
done
}

detener_haproxy () {
clean_screen
echo "DESINSTALAR HAPROXY SSL"
linea
echo "Esta opcion eliminara completamente HAProxy SSL"
echo "Configuraciones, certificados y servicios"
linea

read -p "¿Deseas continuar? [s/n]: " confirmssl
[[ "$confirmssl" != "s" && "$confirmssl" != "S" ]] && return 0

linea
echo "DESINSTALANDO HAPROXY SSL COMPLETAMENTE"
linea

desinstalar_haproxy_completo() {
    service haproxy stop >/dev/null 2>&1
    systemctl stop haproxy >/dev/null 2>&1
    systemctl disable haproxy >/dev/null 2>&1

    pkill -9 haproxy >/dev/null 2>&1

    rm -rf /etc/haproxy
    rm -rf /etc/default/haproxy
    rm -rf /etc/systemd/system/haproxy.service.d
    rm -rf /var/lib/haproxy
    rm -rf /run/haproxy

    rm -f /tmp/haproxy_test.log
    rm -f /tmp/haproxy_install.log
    rm -f /tmp/haproxy.key
    rm -f /tmp/haproxy.crt

    apt-get purge -y haproxy >/dev/null 2>&1
    apt-get autoremove -y >/dev/null 2>&1
    apt-get autoclean -y >/dev/null 2>&1

    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
}

fun_bar "desinstalar_haproxy_completo"

linea
echo "HAPROXY SSL ELIMINADO COMPLETAMENTE"
echo "Puedes volver a instalar HAProxy SSL limpio sin errores"
linea

read -p "Presiona ENTER para continuar..."
return 0
}

cert_haproxy () {
while true; do
clean_screen
linea
echo -e "        ${cor[3]}CERTIFICADO HAPROXY SSL${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
cert_haproxy_mostrar_estado
linea
echo -e "   ${cor[2]}[1]${cor[0]}  AGREGAR CERTIFICADO DESDE ZIP"
echo -e "   ${cor[2]}[2]${cor[0]}  GENERAR SSL CON DOMINIO DE LA VPS"
echo -e "   ${cor[2]}[3]${cor[0]}  REMOVER ACTUAL / GENERAR DEFAULT NUEVO"
echo -e "   ${cor[2]}[0]${cor[0]}  VOLVER"
linea
local opcert=""
while [[ ! "$opcert" =~ ^[0-3]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read -r opcert
done

case "$opcert" in
0) return 0 ;;
1)
    linea
    cert_haproxy_instalar_zip
    linea
    read -r -p "Presiona ENTER para continuar..." _
    ;;
2)
    cert_haproxy_generar_dominio
    linea
    read -r -p "Presiona ENTER para continuar..." _
    ;;
3)
    linea
    echo "Esta acción reemplazará el certificado actual por un certificado predeterminado NUEVO de NEW GOLDEN."
    read -r -p "¿Deseas continuar? [s/n]: " confirm_cert
    if [[ "$confirm_cert" == "s" || "$confirm_cert" == "S" ]]; then
        cert_haproxy_restaurar_default
    else
        echo "Operación cancelada."
    fi
    linea
    read -r -p "Presiona ENTER para continuar..." _
    ;;
esac
done
}

gestor_fun () {
while true; do
clean_screen
mostrar_haproxy_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR HAPROXY SSL${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  ${cor[3]}ABRIR PUERTO HAPROXY SSL${cor[0]}"
echo -e "   ${cor[2]}[2]${cor[0]}  AGREGAR MAS PUERTOS SSL"
echo -e "   ${cor[2]}[3]${cor[0]}  REDIRECCIONAR PUERTO SSL"
echo -e "   ${cor[2]}[4]${cor[0]}  ${cor[2]}DESINSTALAR HAPROXY SSL${cor[0]}"
echo -e "   ${cor[2]}[5]${cor[0]}  GESTIONAR CERTIFICADO SSL"
echo -e "   ${cor[2]}[6]${cor[0]}  COMPARTIR 443: SSL DIRECTO + PAYLOAD"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-6]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1) haproxy_ssl ;;
    2) haproxy_puerto ;;
    3) haproxy_redir ;;
    4) detener_haproxy ;;
    5) cert_haproxy ;;
    6) haproxy_shared_443 ;;
esac
done
}

gestor_fun
