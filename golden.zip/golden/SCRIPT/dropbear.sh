#!/usr/bin/env bash
# Golden REV26 - Dropbear compatible con paquetes Debian/Ubuntu y systemd/SysV.
# No modifica OpenSSH. Configuracion por puertos con restauracion ante fallo.

golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo '[ERROR] Falta compat.sh de Golden.' >&2
    exit 1
fi
unset -f golden_load_compat
export DEBIAN_FRONTEND=noninteractive
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

declare -A cor=([0]='\033[1;37m' [2]='\033[1;32m' [3]='\033[1;36m' [4]='\033[1;31m' [5]='\033[1;33m')
linea(){ printf '\033[0;33m============================================================\033[0m\n'; }
clean_screen(){ [[ -t 1 ]] && clear || true; }
[[ $(id -u) == 0 ]] || { echo 'EJECUTE COMO ROOT' >&2; exit 1; }

fun_bar(){
    if declare -F golden_progress_command >/dev/null 2>&1; then
        golden_progress_command 'Procesando Dropbear' "$1" /tmp/dropbear_install.log
    else
        "$1" >/tmp/dropbear_install.log 2>&1
    fi
}
valid_port(){ [[ "$1" =~ ^[0-9]{1,5}$ ]] && (( 10#$1 >= 1 && 10#$1 <= 65535 )); }
# ss de iproute2 funciona en Debian/Ubuntu viejos y modernos; netstat/lsof son respaldo.
listening_ports(){
    local owner="${1:-}" data=""
    if command -v ss >/dev/null 2>&1; then
        data="$(ss -lntp 2>/dev/null)" || data=""
        if [[ -n "$data" ]]; then
            printf '%s\n' "$data" | awk -v owner="$owner" 'NR>1 && (owner=="" || tolower($0) ~ owner) {n=split($4,a,":"); if(a[n] ~ /^[0-9]+$/) print a[n]}' | sort -nu
            return 0
        fi
    fi
    if command -v netstat >/dev/null 2>&1; then
        netstat -lntp 2>/dev/null | awk -v owner="$owner" '$1 ~ /^tcp/ && (owner=="" || tolower($0) ~ owner) {n=split($4,a,":"); if(a[n] ~ /^[0-9]+$/) print a[n]}' | sort -nu
        return 0
    fi
    if command -v lsof >/dev/null 2>&1; then
        lsof -nP -iTCP -sTCP:LISTEN 2>/dev/null | awk -v owner="$owner" 'NR>1 && (owner=="" || tolower($1) ~ owner) {n=split($9,a,":"); if(a[n] ~ /^[0-9]+$/) print a[n]}' | sort -nu
        return 0
    fi
    echo '[ERROR] Falta ss, netstat o lsof para comprobar puertos.' >&2
    return 1
}
port_in_use(){ listening_ports | grep -Fxq -- "$1"; }
dropbear_port_in_use(){ listening_ports dropbear | grep -Fxq -- "$1"; }
preparar_herramientas_puertos(){
    command -v ss >/dev/null 2>&1 || command -v netstat >/dev/null 2>&1 || command -v lsof >/dev/null 2>&1 || {
        golden_apt_update && golden_install_iproute
    }
}

instalar_dependencias(){
    golden_apt_update || return 1
    # El paquete nativo aporta el servicio y el binario correcto para su release/arquitectura.
    if golden_pkg_available dropbear || golden_pkg_installed dropbear; then
        golden_install_required dropbear || return 1
    elif golden_pkg_available dropbear-run; then
        golden_install_required dropbear-run || return 1
    else
        echo '[ERROR] Dropbear no esta disponible en los repositorios configurados.' >&2
        return 1
    fi
    command -v dropbear >/dev/null && command -v dropbearkey >/dev/null || return 1
    golden_install_iproute || true
    return 0
}

dropbear_has_pam(){
    local binary
    binary="$(command -v dropbear)" || return 1
    # Un archivo pam.d no cambia como fue compilado el binario.
    LC_ALL=C ldd "$binary" 2>/dev/null | grep -Eq 'libpam\.so([.[:space:]]|$)'
}
configurar_pam_dropbear(){
    dropbear_has_pam || return 2
    [[ -s /etc/pam.d/common-auth && -s /etc/pam.d/common-account ]] || return 1
    [[ -e /etc/pam.d/dropbear ]] && return 0
    mkdir -p /etc/pam.d || return 1
    (umask 022; cat > /etc/pam.d/dropbear <<'PAM'
@include common-auth
@include common-account
@include common-session
PAM
    ) || return 1
    chmod 644 /etc/pam.d/dropbear
}
ensure_hostkeys(){
    local t key found=0
    mkdir -p /etc/dropbear || return 1
    for t in rsa ecdsa ed25519 dss; do
        key="/etc/dropbear/dropbear_${t}_host_key"
        if [[ -e "$key" ]]; then
            if [[ -s "$key" ]] && dropbearkey -y -f "$key" >/dev/null 2>&1; then found=1; fi
        fi
    done
    (( found )) && return 0
    # No exige DSS (retirado de versiones modernas) ni regenera claves existentes.
    for t in rsa ed25519 ecdsa; do
        key="/etc/dropbear/dropbear_${t}_host_key"
        [[ -e "$key" || -L "$key" ]] && continue
        if (umask 077; dropbearkey -t "$t" -f "$key" >/dev/null 2>&1); then return 0; fi
    done
    echo '[ERROR] No hay una clave host valida; se conservaron las existentes.' >&2
    return 1
}

guardar_config_dropbear(){
    local p first="" extra="" stage
    for p in $1; do
        valid_port "$p" || return 1
        p=$((10#$p))
        if [[ -z "$first" ]]; then first="$p"; else extra+=" -p $p"; fi
    done
    [[ -n "$first" ]] || return 1
    [[ ! -L /etc/default/dropbear ]] || { echo '[ERROR] Configuracion enlazada: revisar manualmente.' >&2; return 1; }
    mkdir -p /etc/default /etc/dropbear || return 1
    touch /etc/dropbear/banner || return 1
    stage="$(mktemp /etc/default/.golden-dropbear.XXXXXX)" || return 1
    cat > "$stage" <<EOF
# Golden Dropbear: primer puerto + adicionales, sin listener 22 implicito.
NO_START=0
DROPBEAR_PORT=$first
DROPBEAR_EXTRA_ARGS="$extra -w -b /etc/dropbear/banner"
DROPBEAR_BANNER="/etc/dropbear/banner"
DROPBEAR_RECEIVE_WINDOW=65536
EOF
    chmod 644 "$stage" && mv -f -- "$stage" /etc/default/dropbear
}
obtener_puertos_dropbear(){
    local primary extra
    [[ -f /etc/default/dropbear ]] || return 0
    primary="$(sed -nE 's/^[[:space:]]*DROPBEAR_PORT=["\x27]?([0-9]+)["\x27]?[[:space:]]*$/\1/p' /etc/default/dropbear)"
    extra="$(sed -n '/^[[:space:]]*DROPBEAR_EXTRA_ARGS=/p' /etc/default/dropbear | grep -oE -- '-p[[:space:]]*[0-9]+' | sed -E 's/^-p[[:space:]]*//')"
    # Migrar el 22 implicito del script anterior sin quitar un 22 propio real.
    if [[ "$primary" == 22 && -n "$extra" ]] && port_in_use 22 && ! dropbear_port_in_use 22; then primary=""; fi
    {
        printf '%s\n' "$primary" "$extra"
    } | while IFS= read -r p; do valid_port "$p" && printf '%s\n' "$((10#$p))"; done | sort -nu
}
restart_dropbear(){
    local p attempt good
    golden_daemon_reload
    golden_service_enable dropbear >/dev/null 2>&1 || return 1
    golden_service restart dropbear >/dev/null 2>&1 || return 1
    # No basta con que systemctl/service devuelva 0: comprobar TODOS los puertos.
    for attempt in 1 2 3 4 5; do
        good=1
        golden_service_active dropbear || good=0
        while IFS= read -r p; do
            [[ -n "$p" ]] || continue
            dropbear_port_in_use "$p" || good=0
        done < <(obtener_puertos_dropbear)
        (( good )) && return 0
        sleep 1
    done
    return 1
}
apply_config(){
    local ports="$1" install="${2:-0}" backup existed=0 was_active=0 was_enabled=0 result=0 f
    backup="$(mktemp /tmp/golden-dropbear-config.XXXXXX)" || return 1
    [[ -f /etc/default/dropbear ]] && { cp -p /etc/default/dropbear "$backup" || return 1; existed=1; }
    golden_service_active dropbear >/dev/null 2>&1 && was_active=1
    if golden_has_systemd; then
        systemctl is-enabled --quiet dropbear >/dev/null 2>&1 && was_enabled=1
    else
        for f in /etc/rc[2-5].d/S*dropbear; do [[ ! -e "$f" ]] || was_enabled=1; done
    fi
    guardar_config_dropbear "$ports" || { rm -f "$backup"; return 1; }
    # Preconfigurar antes de APT: los postinst no intentan ocupar el 22 de OpenSSH.
    if (( install )) && ! fun_bar instalar_dependencias; then result=1; fi
    if (( result == 0 )); then
        ensure_hostkeys || result=1
        if dropbear_has_pam; then configurar_pam_dropbear || result=1; fi
    fi
    if (( result == 0 )) && restart_dropbear; then
        rm -f -- "$backup"
        return 0
    fi
    (( existed )) && cp -p -- "$backup" /etc/default/dropbear || { (( existed )) || rm -f /etc/default/dropbear; }
    rm -f -- "$backup"
    if (( was_active )); then
        golden_service restart dropbear >/dev/null 2>&1 || true
    else
        golden_service stop dropbear >/dev/null 2>&1 || true
    fi
    (( was_enabled )) || golden_service_disable dropbear >/dev/null 2>&1 || true
    echo '[ERROR] Dropbear no completo la operacion; se restauro su configuracion anterior.' >&2
    echo 'Revisa /tmp/dropbear_install.log y el estado del servicio dropbear.' >&2
    return 1
}
ask_free_port(){
    local label="$1" default="${2:-}" value
    while :; do
        read -r -p "$label${default:+ [$default]}: " value || return 1
        value=${value:-$default}
        if ! valid_port "$value"; then echo 'Puerto invalido (1-65535).'; continue; fi
        value=$((10#$value))
        listening_ports >/dev/null || return 1
        if port_in_use "$value" && ! dropbear_port_in_use "$value"; then
            echo 'Puerto ocupado por otro servicio.'; continue
        fi
        REPLY="$value"; return 0
    done
}
mostrar_puertos_dropbear(){
    local ports p
    linea; echo 'PUERTOS DROPBEAR ACTIVOS'; linea
    ports="$(listening_ports dropbear)"
    if [[ -n "$ports" ]]; then
        while IFS= read -r p; do printf ' DROPBEAR : %s\n' "$p"; done <<< "$ports"
    else echo 'No hay puertos Dropbear activos.'; fi
}
instalar_dropbear(){
    local porta ports
    fun_bar preparar_herramientas_puertos || return 1
    ask_free_port 'PUERTO DROPBEAR' 443 || return 1; porta="$REPLY"
    ports="$( { obtener_puertos_dropbear; printf '%s\n' "$porta"; } | sort -nu | xargs)"
    apply_config "$ports" 1 || return 1
    printf 'DROPBEAR INSTALADO. PUERTOS: %s\n' "$ports"
    if dropbear_has_pam; then echo 'PAM: disponible y configurado.'; else echo 'Autenticacion del sistema: paquete nativo sin PAM.'; fi
}
agregar_puerto(){
    local ports
    [[ -f /etc/default/dropbear ]] || { echo 'Primero instala Dropbear.'; return 1; }
    ask_free_port 'Nuevo puerto' || return 1
    ports="$( { obtener_puertos_dropbear; printf '%s\n' "$REPLY"; } | sort -nu | xargs)"
    apply_config "$ports" && printf 'Puertos Dropbear: %s\n' "$ports"
}
eliminar_puerto(){
    local current port ports
    current="$(obtener_puertos_dropbear)"
    [[ -n "$current" ]] || { echo 'No hay puertos configurados.'; return 1; }
    printf 'Puertos actuales:\n%s\n' "$current"
    read -r -p 'Puerto a eliminar: ' port || return 1
    valid_port "$port" || return 1; port=$((10#$port))
    printf '%s\n' "$current" | grep -Fxq -- "$port" || { echo 'Puerto no encontrado.'; return 1; }
    ports="$(printf '%s\n' "$current" | grep -Fxv -- "$port" | xargs)"
    [[ -n "$ports" ]] || { echo 'No puedes eliminar todos los puertos.'; return 1; }
    apply_config "$ports" && printf 'Puerto %s eliminado.\n' "$port"
}
activar_pam(){
    if ! dropbear_has_pam; then
        echo 'Este paquete no fue compilado con PAM; un archivo pam.d no puede activarlo.'
        echo 'Se conserva la autenticacion nativa de usuarios del sistema.'
        return 1
    fi
    configurar_pam_dropbear && restart_dropbear || return 1
    echo 'PAM disponible, configurado y servicio comprobado.'
}
desinstalar_dropbear(){
    local ans packages=''
    read -r -p 'Desinstalar solo Dropbear [s/N]: ' ans || return 1
    [[ "$ans" == [sS] ]] || return 0
    golden_service stop dropbear >/dev/null 2>&1 || return 1
    golden_service_disable dropbear >/dev/null 2>&1 || true
    local p
    for p in dropbear dropbear-run; do golden_pkg_installed "$p" && packages+=" $p"; done
    if [[ -n "$packages" ]]; then
        golden_apt_wait || return 1
        golden_apt_base remove -y $packages || return 1
    fi
    echo 'Servicio Dropbear retirado. Se conservaron sus claves y configuracion.'
}
menu_dropbear(){
    local opcion
    while :; do
        clean_screen; mostrar_puertos_dropbear; linea
        echo 'ADMINISTRADOR DROPBEAR - NEW-GOLDEN ADM PRO'
        echo '[1] INSTALAR DROPBEAR'
        echo '[2] DESINSTALAR DROPBEAR'
        echo '[3] AGREGAR PUERTO EXTRA'
        echo '[4] ELIMINAR PUERTO'
        echo '[5] VERIFICAR/ACTIVAR PAM DISPONIBLE'
        echo '[0] SALIR'
        linea
        read -r -p 'OPCION: ' opcion || break
        case "$opcion" in
            1) instalar_dropbear ;;
            2) desinstalar_dropbear ;;
            3) agregar_puerto ;;
            4) eliminar_puerto ;;
            5) activar_pam ;;
            0) break ;;
            *) echo 'Opcion invalida.' ;;
        esac
    done
}
[[ "${BASH_SOURCE[0]}" != "$0" ]] || menu_dropbear
