#!/bin/bash

# Golden REV26: compatibilidad común, APT no interactivo, timeouts de red y progreso.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export DEBIAN_FRONTEND=noninteractive
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

declare -A cor=(
[0]="\033[1;37m"
[2]="\033[1;32m"
[3]="\033[1;36m"
[4]="\033[1;31m"
[5]="\033[1;33m"
)

linea() {
    echo -e "\033[0;33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[0m"
}

clean_screen() {
    clear
}

[[ $(id -u) != 0 ]] && {
    echo -e "${cor[4]}EJECUTE COMO ROOT${cor[0]}"
    exit 1
}

fun_bar () {
    local comando="${1:-true}"
    if declare -F golden_progress_command >/dev/null 2>&1; then
        golden_progress_command "Procesando Dropbear" "$comando" "/tmp/dropbear_install.log"
        return $?
    fi
    eval "$comando" >"/tmp/dropbear_install.log" 2>&1
}


mportas() {
    ss -lntp 2>/dev/null | awk '
    NR>1 {
        split($4,a,":");
        print a[length(a)]
    }' | sort -n | uniq
}

valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

port_in_use() {
    ss -lntp 2>/dev/null | awk '
    NR>1 {
        split($4,a,":");
        print a[length(a)]
    }' | sort -n | uniq | grep -wq "$1"
}

dropbear_port_in_use() {
    ss -ltnp 2>/dev/null | grep -i dropbear | awk '
    {
        split($4,a,":");
        print a[length(a)]
    }' | sort -n | uniq | grep -wq "$1"
}

instalar_dependencias() {
    golden_apt_update || return 1
    golden_install_required dropbear openssh-server curl lsof unzip || return 1
    golden_install_available jq sudo net-tools || true
    golden_install_iproute || true
}

configurar_pam_dropbear() {
    mkdir -p /etc/pam.d

    cat > /etc/pam.d/dropbear <<'EOF'
@include common-auth
@include common-account
@include common-session
@include common-password
EOF

    chmod 644 /etc/pam.d/dropbear
}

guardar_config_dropbear() {
    local puertos="$1"
    local args=""

    for p in $puertos; do
        args="$args -p $p"
    done

    mkdir -p /etc/dropbear
    touch /etc/dropbear/banner

    cat > /etc/default/dropbear <<EOF
NO_START=0
DROPBEAR_PORT=22
DROPBEAR_EXTRA_ARGS="$args -w"
DROPBEAR_BANNER="/etc/dropbear/banner"
DROPBEAR_RECEIVE_WINDOW=65536
EOF
}

obtener_puertos_dropbear() {
    grep '^DROPBEAR_EXTRA_ARGS=' /etc/default/dropbear 2>/dev/null \
    | grep -oE -- '-p[[:space:]]+[0-9]+' \
    | awk '{print $2}' \
    | sort -n | uniq
}

restart_dropbear() {
    golden_daemon_reload
    golden_service_enable dropbear >/dev/null 2>&1 || true
    golden_service restart dropbear >/dev/null 2>&1 || return 1
    sleep 1
    golden_service_active dropbear
}

configurar_ssh() {
    mkdir -p /etc/ssh
    sed -i '/^Port /d' /etc/ssh/sshd_config 2>/dev/null || true
    echo "Port 22" >> /etc/ssh/sshd_config
    sed -i 's/^#PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config 2>/dev/null || true
    sed -i 's/^PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config 2>/dev/null || true
    sed -i 's/^#PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config 2>/dev/null || true
    sed -i 's/^PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config 2>/dev/null || true
    golden_service_enable ssh >/dev/null 2>&1 || true
    golden_restart_ssh >/dev/null 2>&1 || true
}

mostrar_puertos_dropbear() {
    linea
    echo -e " ${cor[3]}PUERTOS DROPBEAR ACTIVOS${cor[0]}"
    linea

    ports=$(ss -ltnp 2>/dev/null | grep -i dropbear | awk '
    {
        split($4,a,":");
        print a[length(a)]
    }' | sort -n | uniq)

    if [[ -n "$ports" ]]; then
        echo "$ports" | while read -r p; do
            echo " DROPBEAR : $p"
        done
    else
        echo -e " ${cor[4]}No hay puertos Dropbear activos.${cor[0]}"
    fi
}

instalar_dropbear() {
    clean_screen

    linea
    echo -e " ${cor[3]}INSTALAR DROPBEAR CON PAM${cor[0]}"
    linea

    while true; do
        read -p "PUERTO DROPBEAR [443]: " porta
        [[ -z "$porta" ]] && porta="443"

        valid_port "$porta" || {
            echo -e "${cor[4]}Puerto invalido.${cor[0]}"
            continue
        }

        [[ "$porta" == "22" ]] && {
            echo -e "${cor[4]}No uses 22 para Dropbear.${cor[0]}"
            continue
        }

        if port_in_use "$porta"; then
            echo -e "${cor[4]}Puerto en uso.${cor[0]}"
            continue
        fi

        break
    done

    linea
    echo -e " ${cor[5]}INSTALANDO DROPBEAR...${cor[0]}"
    linea

    fun_bar "instalar_dependencias" || return 1

    configurar_pam_dropbear
    guardar_config_dropbear "$porta"
    configurar_ssh

    if restart_dropbear; then
        linea
        echo -e "${cor[2]}DROPBEAR INSTALADO CORRECTAMENTE${cor[0]}"
        echo -e "${cor[2]}PUERTO: $porta${cor[0]}"
        echo -e "${cor[2]}PAM AUTH: ACTIVADO${cor[0]}"
        linea
    else
        linea
        echo -e "${cor[4]}ERROR: Dropbear no pudo iniciar.${cor[0]}"
        echo "systemctl status dropbear --no-pager"
        echo "journalctl -u dropbear -n 50 --no-pager"
        linea
    fi

    sleep 1
}

desinstalar_dropbear() {
    clean_screen

    linea
    echo -e "${cor[4]}REMOVIENDO DROPBEAR${cor[0]}"
    linea

    parar_dropbear() {
        systemctl stop dropbear >/dev/null 2>&1
        service dropbear stop >/dev/null 2>&1

        sleep 1

        ps -eo pid=,comm= | awk '$2=="dropbear"{print $1}' | while read -r pid; do
            kill -9 "$pid" >/dev/null 2>&1
        done

        systemctl disable dropbear >/dev/null 2>&1
        systemctl daemon-reload >/dev/null 2>&1

        apt-get purge dropbear -y >/dev/null 2>&1
        apt-get autoremove -y >/dev/null 2>&1

        rm -rf /etc/dropbear
        rm -f /etc/default/dropbear
        rm -f /etc/pam.d/dropbear
    }

    fun_bar parar_dropbear

    linea
    echo -e "${cor[2]}DROPBEAR ELIMINADO${cor[0]}"
    linea

    sleep 1
}

agregar_puerto() {
    clean_screen

    linea
    echo -e "${cor[3]}AGREGAR PUERTO EXTRA DROPBEAR${cor[0]}"
    linea

    [[ ! -f /etc/default/dropbear ]] && {
        echo -e "${cor[4]}Dropbear no esta configurado.${cor[0]}"
        sleep 1
        return 1
    }

    while true; do
        read -p "Nuevo puerto: " nuevo_puerto

        valid_port "$nuevo_puerto" || {
            echo -e "${cor[4]}Puerto invalido.${cor[0]}"
            continue
        }

        if port_in_use "$nuevo_puerto"; then
            echo -e "${cor[4]}Puerto ya en uso.${cor[0]}"
        else
            break
        fi
    done

    puertos_actuales="$(obtener_puertos_dropbear)"

    puertos_finales="$(echo -e "$puertos_actuales\n$nuevo_puerto" \
    | sort -n | uniq | xargs)"

    configurar_pam_dropbear
    guardar_config_dropbear "$puertos_finales"

    if restart_dropbear; then
        linea
        echo -e "${cor[2]}Puerto $nuevo_puerto agregado correctamente.${cor[0]}"
        linea
    else
        linea
        echo -e "${cor[4]}ERROR al reiniciar Dropbear.${cor[0]}"
        linea
    fi

    sleep 1
}

eliminar_puerto() {
    clean_screen

    linea
    echo -e "${cor[3]}ELIMINAR PUERTO DROPBEAR${cor[0]}"
    linea

    puertos_actuales="$(obtener_puertos_dropbear)"

    [[ -z "$puertos_actuales" ]] && {
        echo -e "${cor[4]}No hay puertos configurados.${cor[0]}"
        sleep 1
        return 1
    }

    echo -e "${cor[2]}Puertos actuales:${cor[0]}"
    echo "$puertos_actuales"

    linea

    read -p "Puerto a eliminar: " port_del

    if ! echo "$puertos_actuales" | grep -wq "$port_del"; then
        echo -e "${cor[4]}Puerto no encontrado.${cor[0]}"
        sleep 1
        return 1
    fi

    puertos_finales="$(echo "$puertos_actuales" \
    | grep -vw "$port_del" | xargs)"

    if [[ -z "$puertos_finales" ]]; then
        echo -e "${cor[4]}No puedes eliminar todos los puertos.${cor[0]}"
        sleep 1
        return 1
    fi

    guardar_config_dropbear "$puertos_finales"

    if restart_dropbear; then
        linea
        echo -e "${cor[2]}Puerto $port_del eliminado correctamente.${cor[0]}"
        linea
    else
        linea
        echo -e "${cor[4]}ERROR al reiniciar Dropbear.${cor[0]}"
        linea
    fi

    sleep 1
}

activar_pam() {
    clean_screen

    linea
    echo -e "${cor[3]}ACTIVANDO PAM EN DROPBEAR${cor[0]}"
    linea

    configurar_pam_dropbear
    restart_dropbear

    linea
    echo -e "${cor[2]}PAM Authentication activado.${cor[0]}"
    linea

    sleep 1
}

menu_dropbear() {
while true; do
    clean_screen

    mostrar_puertos_dropbear

    linea
    echo -e " ${cor[3]}ADMINISTRADOR DROPBEAR${cor[0]}"
    echo -e " ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
    linea

    echo -e " ${cor[4]}[1]${cor[0]} INSTALAR DROPBEAR"
    echo -e " ${cor[4]}[2]${cor[0]} DESINSTALAR DROPBEAR"
    echo -e " ${cor[4]}[3]${cor[0]} AGREGAR PUERTO EXTRA"
    echo -e " ${cor[4]}[4]${cor[0]} ELIMINAR PUERTO"
    echo -e " ${cor[4]}[5]${cor[0]} ACTIVAR PAM AUTH"
    echo -e " ${cor[4]}[0]${cor[0]} SALIR"

    linea

    read -p "OPCION: " opcion

    case "$opcion" in
        1) instalar_dropbear ;;
        2) desinstalar_dropbear ;;
        3) agregar_puerto ;;
        4) eliminar_puerto ;;
        5) activar_pam ;;
        0) exit ;;
        *) echo -e "${cor[4]}Opcion invalida${cor[0]}"; sleep 1 ;;
    esac
done
}

menu_dropbear
