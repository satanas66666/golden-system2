#!/bin/bash

# Golden REV26: compatibilidad común, APT no interactivo, timeouts de red y progreso.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export PATH=/root/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

RUSTY_DIR="/opt/rustyproxy"
BIN_FILE="${RUSTY_DIR}/target/release/rustyproxy"
SERVICE_PREFIX="wscloud"
mkdir -p "$RUSTY_DIR/src" &>/dev/null

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
[5]="\033[1;36m"
[6]="\033[1;35m"
)

barra="${cor[3]}════════════════════════════════════════════${cor[0]}"

msg_bar(){ echo -e "$barra"; }

pause_menu(){
    echo
    read -r -p "Enter para continuar..."
}

valid_port(){
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

cargo_status(){
    command -v cargo &>/dev/null && echo -e "${cor[4]}INSTALADO${cor[0]}" || echo -e "${cor[2]}NO INSTALADO${cor[0]}"
}

rust_status(){
    [[ -x "$BIN_FILE" ]] && echo -e "${cor[4]}INSTALADO${cor[0]}" || echo -e "${cor[2]}NO INSTALADO${cor[0]}"
}

service_count(){
    find /etc/systemd/system -maxdepth 1 -type f -name "${SERVICE_PREFIX}-*.service" 2>/dev/null | wc -l
}

open_port(){
    local PORT="$1"
    valid_port "$PORT" || return 1

    iptables -C INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport "$PORT" -j ACCEPT
    iptables-save > /etc/iptables/rules.v4 2>/dev/null

    if command -v ufw >/dev/null 2>&1; then
        ufw allow "$PORT"/tcp >/dev/null 2>&1
    fi
}

close_port(){
    local PORT="$1"
    valid_port "$PORT" || return 1

    while iptables -C INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null; do
        iptables -D INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null
    done

    iptables-save > /etc/iptables/rules.v4 2>/dev/null

    if command -v ufw >/dev/null 2>&1; then
        ufw delete allow "$PORT"/tcp >/dev/null 2>&1
    fi
}

fix_limits(){
    mkdir -p /etc/systemd/system.conf.d /etc/security/limits.d /etc/sysctl.d /etc/iptables

cat >/etc/security/limits.d/99-rustyproxy.conf <<EOF
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

cat >/etc/sysctl.d/99-rustyproxy.conf <<EOF
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 250000
net.ipv4.tcp_max_syn_backlog = 8192
net.ipv4.tcp_fin_timeout = 15
net.ipv4.tcp_tw_reuse = 1
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_congestion_control = bbr
net.core.default_qdisc = fq
EOF

    sysctl --system >/dev/null 2>&1
    ulimit -n 1048576 >/dev/null 2>&1
}

show_header(){
    clear
    msg_bar
    echo -e "${cor[5]}        WEBSOCKET PROXY PANEL${cor[0]}"
    echo -e "${cor[3]}        NEW GOLDEN DASHBOARD${cor[0]}"
    msg_bar
    echo -e " Rust/Cargo       : $(cargo_status)"
    echo -e " RustyProxy       : $(rust_status)"
    echo -e " Servicios creados: ${cor[3]}$(service_count)${cor[0]}"
    msg_bar
}

check_rust(){
    export PATH="/root/.cargo/bin:$HOME/.cargo/bin:$PATH"
    command -v cargo >/dev/null 2>&1 && return 0
    echo -e "${cor[3]}Instalando Rust/Cargo...${cor[0]}"
    golden_apt_update || return 1
    golden_install_required curl build-essential pkg-config libssl-dev iptables || return 1
    golden_install_available iptables-persistent netfilter-persistent || true
    local rustup_tmp="/tmp/golden-rustup.sh"
    golden_fetch "https://sh.rustup.rs" "$rustup_tmp" || { echo -e "${cor[2]}ERROR: no se pudo descargar rustup.${cor[0]}"; return 1; }
    golden_run_timeout 300 sh "$rustup_tmp" -y || { rm -f "$rustup_tmp"; return 1; }
    rm -f "$rustup_tmp"
    export PATH="/root/.cargo/bin:$HOME/.cargo/bin:$PATH"
    [[ -f "$HOME/.cargo/env" ]] && source "$HOME/.cargo/env"
    [[ -f "/root/.cargo/env" ]] && source "/root/.cargo/env"
    command -v cargo >/dev/null 2>&1
}

create_rust_proxy(){
    check_rust || return 1
    fix_limits
    mkdir -p "${RUSTY_DIR}/src"

cat << 'EOT' > "${RUSTY_DIR}/Cargo.toml"
[package]
name = "rustyproxy"
version = "0.1.0"
edition = "2021"

[dependencies]
tokio = { version = "1.28.2", features = ["full"] }
EOT

cat << 'EOF' > "${RUSTY_DIR}/src/main.rs"
use std::env;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::Mutex;
use tokio::time::{Duration, timeout};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let port = get_port();
    println!("rustyprox: {}", port);
    start_http(port).await?;
    Ok(())
}

async fn start_http(port: u16) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let listener = TcpListener::bind(("0.0.0.0", port)).await?;
    loop {
        let (client_stream, addr) = listener.accept().await?;
        tokio::spawn(async move {
            if let Err(e) = handle_client(client_stream).await {
                eprintln!("Error procesando cliente {}: {:?}", addr, e);
            }
        });
    }
}

async fn handle_client(client_stream: TcpStream) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let status = get_status();
    let mut client_stream = client_stream;

    client_stream.write_all(format!("HTTP/1.1 101 {}\r\n\r\n", status).as_bytes()).await?;

    let mut buffer = vec![0; 1024];
    let _ = client_stream.read(&mut buffer).await?;

    client_stream.write_all(format!("HTTP/1.1 200 {}\r\n\r\n", status).as_bytes()).await?;

    let mut addr_proxy = "127.0.0.1:22";

    let peek_result = timeout(Duration::from_secs(1), peek_stream(&client_stream))
        .await
        .unwrap_or_else(|_| Ok(String::new()))?;

    if !peek_result.is_empty() && !peek_result.contains("SSH") {
        addr_proxy = "127.0.0.1:1194";
    }

    let server_stream = TcpStream::connect(addr_proxy).await?;

    let (client_read, client_write) = client_stream.into_split();
    let (server_read, server_write) = server_stream.into_split();

    let client_read = Arc::new(Mutex::new(client_read));
    let client_write = Arc::new(Mutex::new(client_write));
    let server_read = Arc::new(Mutex::new(server_read));
    let server_write = Arc::new(Mutex::new(server_write));

    tokio::try_join!(
        transfer_data(client_read, server_write),
        transfer_data(server_read, client_write)
    )?;

    Ok(())
}

async fn transfer_data(
    read_stream: Arc<Mutex<tokio::net::tcp::OwnedReadHalf>>,
    write_stream: Arc<Mutex<tokio::net::tcp::OwnedWriteHalf>>
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let mut buffer = [0; 8192];

    loop {
        let bytes_read = {
            let mut read_guard = read_stream.lock().await;
            read_guard.read(&mut buffer).await?
        };

        if bytes_read == 0 {
            break;
        }

        let mut write_guard = write_stream.lock().await;
        write_guard.write_all(&buffer[..bytes_read]).await?;
    }

    Ok(())
}

async fn peek_stream(stream: &TcpStream) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
    let mut peek_buffer = vec![0; 8192];
    let bytes_peeked = stream.peek(&mut peek_buffer).await?;
    Ok(String::from_utf8_lossy(&peek_buffer[..bytes_peeked]).to_string())
}

fn get_port() -> u16 {
    let args: Vec<String> = env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--port" && i + 1 < args.len() {
            return args[i + 1].parse().unwrap_or(8080);
        }
    }
    8080
}

fn get_status() -> String {
    let args: Vec<String> = env::args().collect();
    for i in 1..args.len() {
        if args[i] == "--status" && i + 1 < args.len() {
            return args[i + 1].clone();
        }
    }
    "@RustyManager".to_string()
}
EOF

    echo -e "${cor[3]}Compilando RustyProxy...${cor[0]}"
    cd "$RUSTY_DIR" || return 1

    export PATH="/root/.cargo/bin:$HOME/.cargo/bin:$PATH"

    golden_run_timeout 600 cargo build --release --jobs "$(nproc)" || {
        echo -e "${cor[2]}ERROR: Falló la compilación.${cor[0]}"
        cd - &>/dev/null
        return 1
    }

    cd - &>/dev/null
    chmod +x "$BIN_FILE"

    echo -e "${cor[4]}RustyProxy instalado correctamente.${cor[0]}"
}

create_systemd_service(){
    golden_require_systemd || return 1
    local PORT="$1"
    local BANNER="$2"
    local SERVICE_FILE="/etc/systemd/system/${SERVICE_PREFIX}-${PORT}.service"

    if [[ ! -x "$BIN_FILE" ]]; then
        echo -e "${cor[2]}ERROR: RustyProxy no está instalado. Usa opción 1 primero.${cor[0]}"
        return 1
    fi

    valid_port "$PORT" || {
        echo -e "${cor[2]}ERROR: Puerto inválido.${cor[0]}"
        return 1
    }

    fix_limits

    systemctl stop "${SERVICE_PREFIX}-${PORT}" 2>/dev/null
    systemctl disable "${SERVICE_PREFIX}-${PORT}" 2>/dev/null

cat << EOF > "$SERVICE_FILE"
[Unit]
Description=Proxy WebSocket Rust puerto $PORT
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${BIN_FILE} --port $PORT --status "$BANNER"
Restart=always
RestartSec=2
User=root
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
OOMScoreAdjust=-500
StandardOutput=null
StandardError=null

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1
    systemctl restart "${SERVICE_PREFIX}-${PORT}" >/dev/null 2>&1

    open_port "$PORT"

    sleep 2

    if systemctl is-active --quiet "${SERVICE_PREFIX}-${PORT}" && ss -ltn 2>/dev/null | grep -q ":${PORT} "; then
        echo -e "${cor[4]}Proxy WebSocket iniciado correctamente.${cor[0]}"
        echo -e "Puerto : ${cor[3]}$PORT${cor[0]}"
        echo -e "Banner : ${cor[3]}$BANNER${cor[0]}"
    else
        echo -e "${cor[2]}ERROR: ${SERVICE_PREFIX}-${PORT} no inicio o no escucho el puerto.${cor[0]}"
        echo "Ejecuta: systemctl status ${SERVICE_PREFIX}-${PORT} --no-pager"
        echo "Ejecuta: journalctl -u ${SERVICE_PREFIX}-${PORT} -n 80 --no-pager"
        echo "Ejecuta: ss -ltnp | grep ':${PORT}'"
    fi
}

stop_proxy_service(){
    local PORT="$1"

    valid_port "$PORT" || {
        echo -e "${cor[2]}Puerto inválido.${cor[0]}"
        return 1
    }

    systemctl stop "${SERVICE_PREFIX}-${PORT}" 2>/dev/null
    systemctl disable "${SERVICE_PREFIX}-${PORT}" 2>/dev/null

    if systemctl is-active --quiet "${SERVICE_PREFIX}-${PORT}"; then
        echo -e "${cor[2]}No se pudo detener ${SERVICE_PREFIX}-${PORT}.${cor[0]}"
    else
        echo -e "${cor[4]}Proxy Rust puerto $PORT detenido correctamente.${cor[0]}"
    fi
}

delete_proxy_service(){
    local PORT="$1"

    valid_port "$PORT" || {
        echo -e "${cor[2]}Puerto inválido.${cor[0]}"
        return 1
    }

    systemctl stop "${SERVICE_PREFIX}-${PORT}" 2>/dev/null
    systemctl disable "${SERVICE_PREFIX}-${PORT}" 2>/dev/null

    rm -f "/etc/systemd/system/${SERVICE_PREFIX}-${PORT}.service"
    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1

    close_port "$PORT"

    echo -e "${cor[4]}Servicio ${SERVICE_PREFIX}-${PORT} eliminado completamente.${cor[0]}"
}

show_active_proxies(){
    echo -e "${cor[5]}PUERTOS WEBSOCKET ABIERTOS${cor[0]}"
    msg_bar

    local found=0

    for file in /etc/systemd/system/${SERVICE_PREFIX}-*.service; do
        [[ -f "$file" ]] || continue

        svc=$(basename "$file")
        PORT_NUM=$(echo "$svc" | grep -oE '[0-9]+')
        BANNER=$(grep 'ExecStart' "$file" | awk -F '--status ' '{print $2}' | sed 's/"//g')

        if systemctl is-active --quiet "${SERVICE_PREFIX}-${PORT_NUM}"; then
            STATUS="${cor[4]}ONLINE${cor[0]}"
        else
            STATUS="${cor[2]}OFFLINE${cor[0]}"
        fi

        echo -e " Puerto ${cor[3]}$PORT_NUM${cor[0]} : $STATUS | Banner: ${cor[5]}${BANNER:-N/A}${cor[0]}"
        found=1
    done

    if [[ "$found" == "0" ]]; then
        echo -e "${cor[2]}No hay puertos WebSocket creados.${cor[0]}"
    fi

    msg_bar
}

restart_all_services(){
    local found=0

    for file in /etc/systemd/system/${SERVICE_PREFIX}-*.service; do
        [[ -f "$file" ]] || continue
        svc=$(basename "$file" .service)
        systemctl restart "$svc" >/dev/null 2>&1
        echo -e "${cor[4]}Reiniciado:${cor[0]} $svc"
        found=1
    done

    [[ "$found" == "0" ]] && echo -e "${cor[2]}No hay servicios para reiniciar.${cor[0]}"
}

show_logs(){
    echo -ne "Puerto para ver logs: "
    read -r PORT

    valid_port "$PORT" || {
        echo -e "${cor[2]}Puerto inválido.${cor[0]}"
        return 1
    }

    journalctl -u "${SERVICE_PREFIX}-${PORT}" -n 60 --no-pager
}

uninstall_all(){
    msg_bar
    echo -e "${cor[2]}DESINSTALAR RUSTYPROXY COMPLETO${cor[0]}"
    msg_bar
    echo -ne "Confirmar desinstalación completa [s/n]: "
    read -r resp

    [[ "$resp" != "s" && "$resp" != "S" ]] && {
        echo -e "${cor[3]}Cancelado.${cor[0]}"
        return
    }

    for file in /etc/systemd/system/${SERVICE_PREFIX}-*.service; do
        [[ -f "$file" ]] || continue

        svc=$(basename "$file" .service)
        PORT_NUM=$(echo "$svc" | grep -oE '[0-9]+')

        systemctl stop "$svc" 2>/dev/null
        systemctl disable "$svc" 2>/dev/null

        close_port "$PORT_NUM"

        rm -f "$file"
        echo -e "${cor[4]}Eliminado:${cor[0]} $svc"
    done

    rm -rf "$RUSTY_DIR"

    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1

    echo -e "${cor[4]}RustyProxy eliminado completamente.${cor[0]}"
}


agregar_puerto_extra(){
    msg_bar
    echo -e "${cor[5]}AGREGAR PUERTO EXTRA WEBSOCKET${cor[0]}"
    msg_bar

    if [[ ! -x "$BIN_FILE" ]]; then
        echo -e "${cor[2]}ERROR: RustyProxy no está instalado. Usa opción 1 primero.${cor[0]}"
        return 1
    fi

    echo -ne "Puerto extra WebSocket: "
    read -r PORT

    if ! valid_port "$PORT"; then
        echo -e "${cor[2]}Puerto inválido.${cor[0]}"
        return 1
    fi

    if [[ -f "/etc/systemd/system/${SERVICE_PREFIX}-${PORT}.service" ]]; then
        echo -e "${cor[3]}Ese puerto ya existe. Se va a actualizar/reiniciar sin cambiar la lógica.${cor[0]}"
    fi

    echo -ne "Banner [@RustyManager]: "
    read -r BANNER
    BANNER="${BANNER:-@RustyManager}"

    create_systemd_service "$PORT" "$BANNER"
}

while true; do
    show_header
    show_active_proxies

    echo -e "${cor[3]}[1]${cor[0]} Instalar / Recompilar RustyProxy"
    echo -e "${cor[3]}[2]${cor[0]} Iniciar puerto WebSocket"
    echo -e "${cor[3]}[3]${cor[0]} Detener puerto WebSocket"
    echo -e "${cor[3]}[4]${cor[0]} Eliminar puerto WebSocket"
    echo -e "${cor[3]}[5]${cor[0]} Reiniciar todos los servicios"
    echo -e "${cor[3]}[6]${cor[0]} Ver logs por puerto"
    echo -e "${cor[3]}[7]${cor[0]} Desinstalar RustyProxy completo"
    echo -e "${cor[3]}[8]${cor[0]} Agregar puerto extra"
    echo -e "${cor[3]}[0]${cor[0]} Salir"
    msg_bar

    echo -ne "${cor[0]}Seleccione opción: "
    read -r opcion

    case "$opcion" in
        1)
            create_rust_proxy
            pause_menu
        ;;

        2)
            echo -ne "Puerto WebSocket a iniciar [8080]: "
            read -r PORT
            PORT="${PORT:-8080}"

            if ! valid_port "$PORT"; then
                echo -e "${cor[2]}Puerto inválido.${cor[0]}"
                pause_menu
                continue
            fi

            echo -ne "Banner [@RustyManager]: "
            read -r BANNER
            BANNER="${BANNER:-@RustyManager}"

            create_systemd_service "$PORT" "$BANNER"
            pause_menu
        ;;

        3)
            echo -ne "Puerto WebSocket a detener: "
            read -r PORT
            stop_proxy_service "$PORT"
            pause_menu
        ;;

        4)
            echo -ne "Puerto WebSocket a eliminar: "
            read -r PORT
            delete_proxy_service "$PORT"
            pause_menu
        ;;

        5)
            restart_all_services
            pause_menu
        ;;

        6)
            show_logs
            pause_menu
        ;;

        7)
            uninstall_all
            pause_menu
        ;;

        8)
            agregar_puerto_extra
            pause_menu
        ;;

        0)
            msg_bar
            echo -e "${cor[4]}Saliendo del panel WebSocket.${cor[0]}"
            msg_bar
            break
        ;;

        *)
            echo -e "${cor[2]}Opción no válida.${cor[0]}"
            sleep 1
        ;;
    esac
done