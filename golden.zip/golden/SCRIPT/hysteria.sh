#!/usr/bin/env bash

# Golden REV21: compatibilidad común, APT no interactivo, timeouts de red y progreso.
_GOLDEN_COMPAT="/etc/ger-inst/compat.sh"
[[ -r "$_GOLDEN_COMPAT" ]] || _GOLDEN_COMPAT="$(cd "$(dirname "$0")" 2>/dev/null && pwd)/compat.sh"
[[ -r "$_GOLDEN_COMPAT" ]] && . "$_GOLDEN_COMPAT"
unset _GOLDEN_COMPAT
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
shopt -s extglob

get_public_ip(){
local ip
ip=$(curl -s4 --max-time 5 ifconfig.me)
[[ -z "$ip" ]] && ip=$(curl -s4 --max-time 5 icanhazip.com)
[[ -z "$ip" ]] && ip=$(hostname -I | awk '{print $1}')
echo "$ip"
}

DOMAIN="$(get_public_ip)"
PROTOCOL="udp"
DEFAULT_PORT="17600"
DEFAULT_OBFS="RataApestosadeMierda"
DEFAULT_AUTH="Tomates"

EXECUTABLE_INSTALL_PATH="/usr/local/bin/hysteria"
SYSTEMD_SERVICES_DIR="/etc/systemd/system"
CONFIG_DIR="/etc/hysteria"
CONFIG_FILE="/etc/hysteria/config.json"
DIR="/etc/newadm/hysteria"
REG="$DIR/usuarios.db"
SERVICE="hysteria-server.service"
REPO_URL="https://github.com/apernet/hysteria"
VERSION="v1.3.5"

mkdir -p "$DIR" "$CONFIG_DIR" /etc/iptables

VERDE="\033[1;32m"
ROJO="\033[1;31m"
AMARILLO="\033[1;33m"
AZUL="\033[1;34m"
BLANCO="\033[1;37m"
RESET="\033[0m"

bar(){ echo -e "${AMARILLO}============================================================${RESET}"; }
ok(){ echo -e "${VERDE}$1${RESET}"; }
err(){ echo -e "${ROJO}$1${RESET}"; }
info(){ echo -e "${AZUL}$1${RESET}"; }
pause(){ echo -ne "${BLANCO}Enter para continuar: ${RESET}"; read -r enter; }

install_deps(){
    golden_apt_update || return 1
    golden_install_required curl wget jq openssl lsof iptables ca-certificates python3 || return 1
    golden_install_available iptables-persistent netfilter-persistent cron socat chrony locales || true
    command -v locale-gen >/dev/null 2>&1 && locale-gen C.UTF-8 >/dev/null 2>&1 || true
}

fix_time(){
    if command -v chronyd >/dev/null 2>&1 || command -v chrony >/dev/null 2>&1; then
        golden_service_enable chrony >/dev/null 2>&1 || true
        golden_service restart chrony >/dev/null 2>&1 || true
    fi
    command -v timedatectl >/dev/null 2>&1 && timedatectl set-ntp true >/dev/null 2>&1 || true
}

fix_performance(){
mkdir -p /etc/sysctl.d

cat >/etc/sysctl.d/99-agnudp-performance.conf <<'EOF'
fs.file-max = 2097152
net.core.rmem_max = 67108864
net.core.wmem_max = 67108864
net.core.rmem_default = 262144
net.core.wmem_default = 262144
net.core.netdev_max_backlog = 250000
net.core.somaxconn = 65535
net.ipv4.ip_forward = 1
net.ipv4.conf.all.rp_filter = 0
net.ipv4.tcp_congestion_control = bbr
net.core.default_qdisc = fq
net.ipv4.udp_mem = 65536 131072 262144
net.ipv4.udp_rmem_min = 8192
net.ipv4.udp_wmem_min = 8192
net.netfilter.nf_conntrack_max = 524288
EOF

cat >/etc/security/limits.d/99-agnudp.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

sysctl --system >/dev/null 2>&1
ulimit -n 1048576 >/dev/null 2>&1
}

get_iface(){
ip -4 route ls | grep default | grep -Po '(?<=dev )(\S+)' | head -1
}

get_port(){
jq -r '.listen // ""' "$CONFIG_FILE" 2>/dev/null | sed 's/://g'
}

get_obfs(){
jq -r '.obfs // ""' "$CONFIG_FILE" 2>/dev/null
}

vps_ip(){
local ip
ip=$(curl -s4 ifconfig.me)
[[ -z "$ip" ]] && ip=$(hostname -I | awk '{print $1}')
echo "$ip"
}

detect_arch(){
case "$(uname -m)" in
i386|i686) echo "386" ;;
amd64|x86_64) echo "amd64" ;;
armv8|aarch64) echo "arm64" ;;
armv7|armv7l|armv6l) echo "arm" ;;
*) echo "amd64" ;;
esac
}

install_binary(){
local arch
arch="$(detect_arch)"
local url="$REPO_URL/releases/download/$VERSION/hysteria-linux-$arch"

golden_fetch "$url" /tmp/hysteria-bin
install -m 755 /tmp/hysteria-bin "$EXECUTABLE_INSTALL_PATH"
rm -f /tmp/hysteria-bin
}

setup_ssl(){
mkdir -p "$CONFIG_DIR"

openssl genrsa -out "$CONFIG_DIR/hysteria.ca.key" 2048 >/dev/null 2>&1

openssl req -new -x509 -days 3650 \
-key "$CONFIG_DIR/hysteria.ca.key" \
-subj "/C=CN/ST=GD/L=SZ/O=Hysteria, Inc./CN=Hysteria Root CA" \
-out "$CONFIG_DIR/hysteria.ca.crt" >/dev/null 2>&1

openssl req -newkey rsa:2048 -nodes \
-keyout "$CONFIG_DIR/hysteria.server.key" \
-subj "/C=CN/ST=GD/L=SZ/O=Hysteria, Inc./CN=$DOMAIN" \
-out "$CONFIG_DIR/hysteria.server.csr" >/dev/null 2>&1

openssl x509 -req \
-extfile <(printf "subjectAltName=IP:$DOMAIN") \
-days 3650 \
-in "$CONFIG_DIR/hysteria.server.csr" \
-CA "$CONFIG_DIR/hysteria.ca.crt" \
-CAkey "$CONFIG_DIR/hysteria.ca.key" \
-CAcreateserial \
-out "$CONFIG_DIR/hysteria.server.crt" >/dev/null 2>&1
}

write_service(){
cat >"$SYSTEMD_SERVICES_DIR/hysteria-server.service" <<EOF
[Unit]
Description=AGN-UDP Service
After=network.target

[Service]
User=root
Group=root
WorkingDirectory=/etc/hysteria
ExecStart=/usr/local/bin/hysteria -config /etc/hysteria/config.json server
Restart=always
RestartSec=1
LimitNOFILE=1048576
LimitNPROC=1048576
LimitCORE=infinity
TasksMax=infinity

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload >/dev/null 2>&1
}

rebuild_config(){
local port="$1"
local obfs="$2"
local default_auth="$3"

[[ -z "$port" ]] && port="$DEFAULT_PORT"
[[ -z "$obfs" ]] && obfs="$DEFAULT_OBFS"
[[ -z "$default_auth" ]] && default_auth="$DEFAULT_AUTH"

python3 - "$CONFIG_FILE" "$REG" "$port" "$obfs" "$default_auth" <<'PY'
import sys, json, base64, pathlib

cfg = pathlib.Path(sys.argv[1])
reg = pathlib.Path(sys.argv[2])
port = sys.argv[3]
obfs = sys.argv[4]
default_auth = sys.argv[5]

passwords = []

if reg.exists():
    for line in reg.read_text(encoding="utf-8", errors="ignore").splitlines():
        parts = line.split("|", 2)
        if len(parts) == 3:
            try:
                auth = base64.b64decode(parts[2]).decode("utf-8")
                if auth not in passwords:
                    passwords.append(auth)
            except Exception:
                pass

if not passwords:
    passwords = [default_auth]

data = {
    "server": "vpn.khaledagn.com",
    "listen": ":" + str(port),
    "protocol": "udp",
    "cert": "/etc/hysteria/hysteria.server.crt",
    "key": "/etc/hysteria/hysteria.server.key",
    "up": "100 Mbps",
    "up_mbps": 100,
    "down": "100 Mbps",
    "down_mbps": 100,
    "disable_udp": False,
    "obfs": obfs,
    "auth": {
        "mode": "passwords",
        "config": passwords
    }
}

cfg.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
PY
}

open_udp(){
local p="$1"
[[ -z "$p" ]] && return
iptables -C INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null || iptables -I INPUT -p udp --dport "$p" -j ACCEPT
iptables-save > /etc/iptables/rules.v4 2>/dev/null

if command -v ufw >/dev/null 2>&1; then
ufw allow "$p"/udp >/dev/null 2>&1
fi
}

close_udp(){
local p="$1"
[[ -z "$p" ]] && return

while iptables -C INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null; do
iptables -D INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null
done

iptables-save > /etc/iptables/rules.v4 2>/dev/null

if command -v ufw >/dev/null 2>&1; then
ufw delete allow "$p"/udp >/dev/null 2>&1
fi
}

clean_nat(){
local p="$1"
local iface
iface="$(get_iface)"
[[ -z "$iface" || -z "$p" ]] && return

while iptables -t nat -C PREROUTING -i "$iface" -p udp --dport 10000:65000 -m comment --comment GOLDEN-AGNUDP -j DNAT --to-destination ":$p" 2>/dev/null; do
iptables -t nat -D PREROUTING -i "$iface" -p udp --dport 10000:65000 -m comment --comment GOLDEN-AGNUDP -j DNAT --to-destination ":$p" 2>/dev/null
done

iptables-save > /etc/iptables/rules.v4 2>/dev/null
}

setup_nat(){
local p="$1"
local iface
iface="$(get_iface)"
[[ -z "$iface" || -z "$p" ]] && return

iptables -t nat -C PREROUTING -i "$iface" -p udp --dport 10000:65000 -m comment --comment GOLDEN-AGNUDP -j DNAT --to-destination ":$p" 2>/dev/null || \
iptables -t nat -A PREROUTING -i "$iface" -p udp --dport 10000:65000 -m comment --comment GOLDEN-AGNUDP -j DNAT --to-destination ":$p"

iptables-save > /etc/iptables/rules.v4 2>/dev/null
}

restart_agnudp(){
fix_time
fix_performance
write_service
systemctl enable "$SERVICE" >/dev/null 2>&1
systemctl daemon-reload >/dev/null 2>&1
systemctl restart "$SERVICE" >/dev/null 2>&1
sleep 2
}

install_agnudp(){
golden_require_systemd || { err "Hysteria requiere systemd en esta versión del módulo."; pause; return 1; }
clear
bar
info " INSTALAR HYSTERIA UDP"
bar

install_deps
fix_time
fix_performance

mkdir -p "$DIR" "$CONFIG_DIR" /etc/iptables
touch "$REG"

echo -ne "Puerto UDP ENTER para 17600: "
read -r port
[[ -z "$port" ]] && port="$DEFAULT_PORT"

if [[ "$port" != +([0-9]) || "$port" -gt 65535 ]]; then
err "PUERTO INVALIDO"
pause
menu
fi

printf "OBFS EXACTO ENTER para usar default: "
IFS= read -r obfs
[[ -z "$obfs" ]] && obfs="$DEFAULT_OBFS"

printf "AUTH EXACTO con espacios/emojis ENTER para usar default: "
IFS= read -r auth
[[ -z "$auth" ]] && auth="$DEFAULT_AUTH"

systemctl stop "$SERVICE" >/dev/null 2>&1

install_binary
setup_ssl
write_service

mkdir -p "$DIR"
touch "$REG"

auth_b64="$(printf '%s' "$auth" | base64 -w0)"
echo "default|$(date '+%F' -d '+365 days')|$auth_b64" > "$REG"

rebuild_config "$port" "$obfs" "$auth"

open_udp "$port"
setup_nat "$port"

restart_agnudp

bar
if ss -lunp | grep -q ":$port"; then
ok " AGN-UDP INSTALADO Y ESCUCHANDO EN UDP $port"
else
err " AGN-UDP INSTALADO, PERO NO ESCUCHA"
fi
bar
echo "OBFS: [$obfs]"
echo "AUTH: [$auth]"
bar
pause
menu
}

add_user(){
clear
bar
info " AGREGAR AUTH / USUARIO"
bar

[[ ! -e "$CONFIG_FILE" ]] && {
err "Primero instala AGN-UDP"
pause
menu
}

echo -ne "Nombre usuario: "
read -r user
user="$(echo "$user" | sed 's/[^a-zA-Z0-9_-]//g')"

if [[ ${#user} -lt 2 ]]; then
err "USUARIO INVALIDO"
pause
menu
fi

printf "AUTH EXACTO con espacios/emojis: "
IFS= read -r auth

[[ -z "$auth" ]] && {
err "AUTH VACIO"
pause
menu
}

echo -ne "Días: "
read -r dias
[[ -z "$dias" ]] && dias="30"

if [[ "$dias" != +([0-9]) || "$dias" -gt 365 ]]; then
err "DIAS INVALIDOS"
pause
menu
fi

expire="$(date '+%F' -d "+$dias days")"
auth_b64="$(printf '%s' "$auth" | base64 -w0)"

grep -v "^$user|" "$REG" > "$REG.tmp" 2>/dev/null || true
mv "$REG.tmp" "$REG" 2>/dev/null || true

echo "$user|$expire|$auth_b64" >> "$REG"

port="$(get_port)"
obfs="$(get_obfs)"

rebuild_config "$port" "$obfs" "$auth"
restart_agnudp

bar
ok "AUTH AGREGADO"
echo "Usuario: $user"
echo "Expira : $expire"
echo "Auth   : [$auth]"
bar
show_user_data "$user" "$auth"
bar
pause
menu
}

show_user_data(){
local user="$1"
local auth="$2"
local ip port obfs
ip="$(vps_ip)"
port="$(get_port)"
obfs="$(get_obfs)"

echo "IP/Host : $ip"
echo "Puerto  : $port"
echo "Obfs    : [$obfs]"
echo "Auth    : [$auth]"
echo "Link    : hysteria://$ip:$port?protocol=udp&auth=$(printf '%s' "$auth" | jq -sRr @uri)&obfs=$(printf '%s' "$obfs" | jq -sRr @uri)#AGN-$user"
}

list_users(){
clear
bar
info " USUARIOS / AUTH REGISTRADOS"
bar

[[ ! -e "$REG" ]] && touch "$REG"

if [[ ! -s "$REG" ]]; then
err "NO HAY USUARIOS"
bar
pause
menu
fi

while IFS='|' read -r user expire auth_b64; do
auth="$(printf '%s' "$auth_b64" | base64 -d 2>/dev/null)"
echo -e "${VERDE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo "Usuario: $user"
echo "Expira : $expire"
echo "Auth   : [$auth]"
echo ""
show_user_data "$user" "$auth"
echo ""
done < "$REG"

echo -e "${VERDE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
pause
menu
}

del_user(){
clear
bar
info " ELIMINAR USUARIO"
bar

[[ ! -e "$REG" ]] && touch "$REG"

if [[ ! -s "$REG" ]]; then
err "NO HAY USUARIOS"
bar
pause
menu
fi

nl -w1 -s') ' "$REG" | awk -F'|' '{print $1" | Expira: "$2}'
bar

echo -ne "Número o usuario exacto a eliminar: "
IFS= read -r input

if [[ -z "$input" ]]; then
err "USUARIO INVALIDO"
pause
menu
fi

if [[ "$input" == +([0-9]) ]]; then
user="$(sed -n "${input}p" "$REG" | cut -d'|' -f1)"
else
user="$input"
fi

if [[ -z "$user" ]]; then
err "USUARIO NO EXISTE"
pause
menu
fi

if ! awk -F'|' -v u="$user" '$1==u {found=1} END{exit !found}' "$REG"; then
err "USUARIO NO EXISTE"
pause
menu
fi

tmpreg=$(mktemp)
awk -F'|' -v u="$user" '$1 != u {print $0}' "$REG" > "$tmpreg"
mv "$tmpreg" "$REG"

port="$(get_port)"
obfs="$(get_obfs)"

rebuild_config "$port" "$obfs" "$DEFAULT_AUTH"
restart_agnudp

bar
ok "USUARIO ELIMINADO CORRECTAMENTE: $user"
bar
pause
menu
}

clean_expired(){
clear
bar
info " LIMPIAR EXPIRADOS"
bar

[[ ! -e "$REG" ]] && touch "$REG"

now="$(date +%s)"
tmpreg="$(mktemp)"

while IFS='|' read -r user expire auth_b64; do
[[ -z "$user" ]] && continue
expsec="$(date +%s -d "$expire" 2>/dev/null)"

if [[ -n "$expsec" && "$now" -gt "$expsec" ]]; then
echo "Eliminado: $user"
else
echo "$user|$expire|$auth_b64" >> "$tmpreg"
fi
done < "$REG"

mv "$tmpreg" "$REG"

port="$(get_port)"
obfs="$(get_obfs)"
rebuild_config "$port" "$obfs" "$DEFAULT_AUTH"
restart_agnudp

bar
ok "LIMPIEZA COMPLETADA"
bar
pause
menu
}

change_port(){
clear
bar
info " CAMBIAR PUERTO UDP"
bar

oldport="$(get_port)"
echo "Puerto actual: $oldport"
echo -ne "Nuevo puerto UDP: "
read -r port

if [[ -z "$port" || "$port" != +([0-9]) || "$port" -gt 65535 ]]; then
err "PUERTO INVALIDO"
pause
menu
fi

obfs="$(get_obfs)"
rebuild_config "$port" "$obfs" "$DEFAULT_AUTH"

close_udp "$oldport"
clean_nat "$oldport"
open_udp "$port"
setup_nat "$port"

restart_agnudp

bar
ok "PUERTO CAMBIADO A $port"
bar
pause
menu
}

change_obfs(){
clear
bar
info " CAMBIAR OBFS"
bar

printf "Nuevo OBFS EXACTO con espacios/emojis: "
IFS= read -r obfs

[[ -z "$obfs" ]] && {
err "OBFS VACIO"
pause
menu
}

port="$(get_port)"
rebuild_config "$port" "$obfs" "$DEFAULT_AUTH"
restart_agnudp

bar
ok "OBFS CAMBIADO"
echo "OBFS: [$obfs]"
bar
pause
menu
}

status_panel(){
clear
bar
info " ESTADO HYSTERIA UDP"
bar

if [[ -x "$EXECUTABLE_INSTALL_PATH" ]]; then
ok "HYSTERIA: INSTALADO"
"$EXECUTABLE_INSTALL_PATH" -v 2>/dev/null || true
else
err "HYSTERIA: NO INSTALADO"
fi

if systemctl is-active --quiet "$SERVICE"; then
ok "SERVICIO: ACTIVO"
else
err "SERVICIO: INACTIVO"
fi

bar
echo "Puerto UDP : $(get_port)"
echo "OBFS       : [$(get_obfs)]"
echo "Interface  : $(get_iface)"
bar
ss -lunp | grep hysteria || err "NO HAY PUERTO UDP ESCUCHANDO"
bar
pause
menu
}

repair_service(){
clear
bar
info " REPARANDO AGN-UDP"
bar

fix_time
fix_performance
write_service

port="$(get_port)"
open_udp "$port"
setup_nat "$port"

restart_agnudp

systemctl status "$SERVICE" --no-pager -l
bar
ss -lunp | grep hysteria || err "NO ESTA ESCUCHANDO UDP"
bar
pause
menu
}

uninstall_agnudp(){
clear
bar
info " DESINSTALAR AGN-UDP COMPLETO"
bar

port="$(get_port)"

read -p "Confirmar desinstalación completa [s/n]: " resp
[[ "$resp" != "s" ]] && menu

systemctl stop "$SERVICE" >/dev/null 2>&1
systemctl disable "$SERVICE" >/dev/null 2>&1
pkill -9 -x hysteria >/dev/null 2>&1

close_udp "$port"
clean_nat "$port"

rm -f "$EXECUTABLE_INSTALL_PATH"
rm -f "$SYSTEMD_SERVICES_DIR/hysteria-server.service"
rm -f "$SYSTEMD_SERVICES_DIR/hysteria-server@.service"
rm -rf "$CONFIG_DIR"
rm -rf "$DIR"

systemctl daemon-reload >/dev/null 2>&1

iptables-save > /etc/iptables/rules.v4 2>/dev/null

bar
ok "AGN-UDP ELIMINADO COMPLETAMENTE"
bar
pause
menu
}

menu(){
clear
bar
echo -e "${AZUL} PANEL HYSTERIA UDP ${ROJO}[ GOLDEN MX ]${RESET}"
bar

if [[ -x "$EXECUTABLE_INSTALL_PATH" ]]; then
ok "HYSTERIA: INSTALADO"
else
err "HYSTERIA: NO INSTALADO"
fi

if systemctl is-active --quiet "$SERVICE"; then
ok "SERVICIO: ACTIVO"
else
err "SERVICIO: INACTIVO"
fi

bar
echo "Puerto UDP : $(get_port 2>/dev/null)"
echo "OBFS       : [$(get_obfs 2>/dev/null)]"
bar

echo -e "${VERDE}[1]${RESET} INSTALAR AGN-UDP"
echo -e "${VERDE}[2]${RESET} CAMBIAR PUERTO UDP"
echo -e "${VERDE}[3]${RESET} CAMBIAR OBFS"
bar
echo -e "${VERDE}[4]${RESET} AGREGAR AUTH / USUARIO"
echo -e "${VERDE}[5]${RESET} ELIMINAR USUARIO"
echo -e "${VERDE}[6]${RESET} MOSTRAR USUARIOS + DATOS"
echo -e "${VERDE}[7]${RESET} LIMPIAR EXPIRADOS"
bar
echo -e "${VERDE}[8]${RESET} ESTADO GENERAL"
echo -e "${VERDE}[9]${RESET} REPARAR SERVICIO"
echo -e "${VERDE}[10]${RESET} DESINSTALAR COMPLETO"
echo -e "${VERDE}[0]${RESET} SALIR"
bar

echo -ne "Seleccione: "
read -r op

case "$op" in
1) install_agnudp ;;
2) change_port ;;
3) change_obfs ;;
4) add_user ;;
5) del_user ;;
6) list_users ;;
7) clean_expired ;;
8) status_panel ;;
9) repair_service ;;
10) uninstall_agnudp ;;
0) exit ;;
*) menu ;;
esac
}

menu