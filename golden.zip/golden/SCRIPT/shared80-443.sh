#!/usr/bin/env bash
# ================================================================
# SSL + V2RAY/XRAY + PROXYGO 80/443 MANAGER V4.5 PROXYGO RECONNECT + FAST HANDSHAKE FIX - INDEPENDIENTE
# Target: Ubuntu 20.04/22.04/24.04 + Debian 11/12/13 (apt/systemd)
# Public TCP/443 is owned by HAProxy.
#   - SSH-over-SSL: TLS -> HAProxy -> local OpenSSH :22
#   - V2Ray/Xray:   TLS -> HAProxy -> local Xray :10000
# HAProxy terminates TLS and classifies the decrypted first bytes:
#   SSH-... => SSH backend; anything else with a payload => Xray.
# This lets both services use the SAME public TCP/443.
# ================================================================

set -o pipefail
export DEBIAN_FRONTEND=noninteractive

C_RESET='\033[0m'
C_GOLD='\033[1;33m'
C_GREEN='\033[1;32m'
C_RED='\033[1;31m'
C_CYAN='\033[1;36m'
C_WHITE='\033[1;37m'
C_GRAY='\033[0;37m'

BASE_DIR='/etc/ssl-v2ray443-manager'
STATE_FILE="$BASE_DIR/state.env"
USERS_FILE="$BASE_DIR/xray-users.json"
BACKUP_DIR="$BASE_DIR/backups"
XRAY_CONFIG='/usr/local/etc/xray/config.json'
XRAY_BIN='/usr/local/bin/xray'
XRAY_PORT='10000'
HA_CERT_DIR='/etc/haproxy/certs'
HA_CERT="$HA_CERT_DIR/shared443.pem"
HA_CFG='/etc/haproxy/haproxy.cfg'
INFO_FILE='/root/SSL_V2RAY_PROXYGO_80_443_INFO.txt'
XRAY80_PORT='10080'
PROXYGO_BIN='/usr/local/bin/proxygo'
PROXYGO_SRC_DIR='/opt/newgolden-proxygo'
PROXYGO_DIR='/etc/proxygo'
PROXYGO_LOCAL_PORT='18080'
PROXYGO_SSH_SHIM_PORT='18022'
PROXYGO_SSH_SHIM_BIN='/usr/local/bin/proxygo-ssh-clean'
PROXYGO_SSH_SHIM_DIR='/opt/proxygo-ssh-clean'
PROXYGO_SSH_SHIM_SERVICE='/etc/systemd/system/proxygo_ssh_clean.service'
AUTO_TUNE_STAMP="$BASE_DIR/.auto-tune-profile"
AUTO_TUNE_SYSCTL='/etc/sysctl.d/99-ssl-xray-proxygo-manager.conf'
AUTO_PROFILE='AUTO'
AUTO_CPU=1
AUTO_MEM_MB=512
HAPROXY_MAXCONN=8192
AUTO_SOMAXCONN=16384
AUTO_BACKLOG=32768
AUTO_TCPBUF=16777216
AUTO_FILEMAX=1048576
AUTO_NOFILE=1048576
AUTO_CONNTRACK=262144
AUTO_SWAPPINESS=10

DOMAIN=''
EMAIL=''
CERT_MODE='self-signed'
XRAY_PROTOCOL='vless'
XRAY_TRANSPORT='websocket'
XRAY_PATH='/v2ray'
XRAY_GRPC_SERVICE='v2raygrpc'
XRAY_XHTTP_MODE='auto'

# Puerto 80 compartido: ProxyGo es el backend por defecto.
XRAY80_ENABLED='0'
XRAY80_PROTOCOL='vless'
XRAY80_TRANSPORT='websocket'
XRAY80_PATH='/v2ray80'
XRAY80_GRPC_SERVICE='v2ray80grpc'
XRAY80_XHTTP_MODE='auto'
PROXYGO_TARGET_PORT='22'
PROXYGO_BANNER='OK'

require_root() {
  if [[ $(id -u) -ne 0 ]]; then
    echo -e "${C_RED}ERROR:${C_RESET} ejecuta como root: sudo bash $0"
    exit 1
  fi
}

bar() {
  echo -e "${C_GOLD}=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=${C_RESET}"
}

pause() {
  echo
  read -r -p 'ENTER para continuar...' _
}

safe_clear() {
  command -v clear >/dev/null 2>&1 && clear || printf '\033c'
}

ensure_dirs() {
  mkdir -p "$BASE_DIR" "$BACKUP_DIR" "$HA_CERT_DIR" /usr/local/etc/xray
  if [[ ! -f "$USERS_FILE" ]]; then
    printf '[]\n' > "$USERS_FILE"
    chmod 600 "$USERS_FILE"
  fi
}

migrate_users_file() {
  ensure_dirs
  command -v jq >/dev/null 2>&1 || return 0
  jq empty "$USERS_FILE" >/dev/null 2>&1 || { printf '[]\n' > "$USERS_FILE"; chmod 600 "$USERS_FILE"; return 0; }
  local tmp
  tmp=$(mktemp)
  jq 'map(
        . + {
          port: ((.port // 443) | tonumber),
          path: (.path // ""),
          host: (.host // ""),
          created: (.created // "")
        }
      )' "$USERS_FILE" > "$tmp" || { rm -f "$tmp"; return 1; }
  install -m 600 "$tmp" "$USERS_FILE"
  rm -f "$tmp"
}

load_state() {
  ensure_dirs
  if [[ -f "$STATE_FILE" ]]; then
    # shellcheck disable=SC1090
    source "$STATE_FILE"
  fi
  migrate_users_file >/dev/null 2>&1 || true
}

save_state() {
  ensure_dirs
  cat > "$STATE_FILE" <<EOF
DOMAIN=$(printf '%q' "$DOMAIN")
EMAIL=$(printf '%q' "$EMAIL")
CERT_MODE=$(printf '%q' "$CERT_MODE")
XRAY_PROTOCOL=$(printf '%q' "$XRAY_PROTOCOL")
XRAY_TRANSPORT=$(printf '%q' "$XRAY_TRANSPORT")
XRAY_PATH=$(printf '%q' "$XRAY_PATH")
XRAY_GRPC_SERVICE=$(printf '%q' "$XRAY_GRPC_SERVICE")
XRAY_XHTTP_MODE=$(printf '%q' "$XRAY_XHTTP_MODE")
XRAY80_ENABLED=$(printf '%q' "$XRAY80_ENABLED")
XRAY80_PROTOCOL=$(printf '%q' "$XRAY80_PROTOCOL")
XRAY80_TRANSPORT=$(printf '%q' "$XRAY80_TRANSPORT")
XRAY80_PATH=$(printf '%q' "$XRAY80_PATH")
XRAY80_GRPC_SERVICE=$(printf '%q' "$XRAY80_GRPC_SERVICE")
XRAY80_XHTTP_MODE=$(printf '%q' "$XRAY80_XHTTP_MODE")
PROXYGO_TARGET_PORT=$(printf '%q' "$PROXYGO_TARGET_PORT")
PROXYGO_BANNER=$(printf '%q' "$PROXYGO_BANNER")
EOF
  chmod 600 "$STATE_FILE"
}

service_is_active() {
  systemctl is-active --quiet "$1" 2>/dev/null
}

onoff() {
  if service_is_active "$1"; then
    echo -e "${C_GREEN}ON${C_RESET}"
  else
    echo -e "${C_RED}OFF${C_RESET}"
  fi
}

public_ip() {
  local ip=''
  ip=$(curl -4fsS --max-time 4 https://api.ipify.org 2>/dev/null || true)
  [[ -n "$ip" ]] || ip=$(hostname -I 2>/dev/null | awk '{print $1}')
  printf '%s' "$ip"
}

host_for_clients() {
  if [[ -n "$DOMAIN" ]]; then
    printf '%s' "$DOMAIN"
  else
    public_ip
  fi
}

backup_file_once() {
  local f="$1" tag="$2"
  [[ -f "$f" ]] || return 0
  if ! compgen -G "$BACKUP_DIR/${tag}-*.bak" >/dev/null; then
    cp -a "$f" "$BACKUP_DIR/${tag}-$(date +%Y%m%d-%H%M%S).bak"
  fi
}

install_base() {
  echo -e "${C_CYAN}Instalando dependencias base...${C_RESET}"
  apt-get update -y || return 1
  apt-get install -y ca-certificates curl openssl haproxy openssh-server jq uuid-runtime certbot iproute2 procps golang-go lsof || return 1
  systemctl enable ssh >/dev/null 2>&1 || systemctl enable sshd >/dev/null 2>&1 || true
  systemctl restart ssh >/dev/null 2>&1 || systemctl restart sshd >/dev/null 2>&1 || true
  echo -e "${C_GREEN}Dependencias listas.${C_RESET}"
}

make_self_signed() {
  local cn
  cn="${DOMAIN:-$(hostname -f 2>/dev/null || hostname)}"
  mkdir -p "$HA_CERT_DIR"
  openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
    -keyout "$BASE_DIR/selfsigned.key" \
    -out "$BASE_DIR/selfsigned.crt" \
    -subj "/CN=${cn}" >/dev/null 2>&1 || return 1
  cat "$BASE_DIR/selfsigned.crt" "$BASE_DIR/selfsigned.key" > "$HA_CERT"
  chmod 600 "$HA_CERT"
  CERT_MODE='self-signed'
  save_state
}

configure_certificate() {
  install_base || return 1
  load_state
  safe_clear
  bar
  echo -e "${C_GOLD}        CERTIFICADO TLS PARA SSL + V2RAY 443${C_RESET}"
  bar
  echo 'Para produccion se recomienda un dominio apuntando a esta VPS.'
  echo 'Si lo dejas vacio se creara un certificado autofirmado.'
  echo
  read -r -p "Dominio [${DOMAIN:-ninguno}]: " in_domain
  if [[ -n "$in_domain" ]]; then
    DOMAIN="${in_domain,,}"
  fi
  if [[ -n "$DOMAIN" ]]; then
    read -r -p "Email Let's Encrypt [${EMAIL:-opcional}]: " in_email
    [[ -n "$in_email" ]] && EMAIL="$in_email"
  fi
  save_state

  if [[ -z "$DOMAIN" ]]; then
    make_self_signed || return 1
    echo -e "${C_GREEN}Certificado autofirmado creado.${C_RESET}"
    write_haproxy_config >/dev/null 2>&1 || true
    systemctl restart haproxy >/dev/null 2>&1 || true
    return 0
  fi

  echo "Solicitando Let's Encrypt para: $DOMAIN"
  mkdir -p "$HA_CERT_DIR"
  local args=(certonly --standalone --preferred-challenges http --non-interactive --agree-tos -d "$DOMAIN")
  if [[ -n "$EMAIL" ]]; then
    args+=(--email "$EMAIL")
  else
    args+=(--register-unsafely-without-email)
  fi

  # Only port 80 is needed for the HTTP challenge. Stop services that may own it.
  local stopped_haproxy=0
  if ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq '(^|:)80$'; then
    if service_is_active haproxy; then
      systemctl stop haproxy || true
      stopped_haproxy=1
    fi
  fi

  if certbot "${args[@]}"; then
    cat "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" \
        "/etc/letsencrypt/live/${DOMAIN}/privkey.pem" > "$HA_CERT"
    chmod 600 "$HA_CERT"
    CERT_MODE='letsencrypt'
    save_state
    mkdir -p /etc/letsencrypt/renewal-hooks/deploy
    cat > /etc/letsencrypt/renewal-hooks/deploy/ssl-v2ray443-haproxy.sh <<EOF
#!/usr/bin/env bash
set -e
cat "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" "/etc/letsencrypt/live/${DOMAIN}/privkey.pem" > "${HA_CERT}"
chmod 600 "${HA_CERT}"
systemctl reload haproxy
EOF
    chmod 700 /etc/letsencrypt/renewal-hooks/deploy/ssl-v2ray443-haproxy.sh
    echo -e "${C_GREEN}Let's Encrypt instalado.${C_RESET}"
  else
    echo -e "${C_RED}Let's Encrypt fallo. Se usara certificado autofirmado.${C_RESET}"
    make_self_signed || return 1
  fi

  [[ $stopped_haproxy -eq 1 ]] && systemctl start haproxy >/dev/null 2>&1 || true
  write_haproxy_config >/dev/null 2>&1 || true
  systemctl restart haproxy >/dev/null 2>&1 || true
}

write_haproxy_config() {
  ensure_dirs
  load_state
  detect_auto_tune_values
  [[ -s "$HA_CERT" ]] || make_self_signed || return 1
  backup_file_once "$HA_CFG" 'haproxy.cfg'

  local x80_acl=''
  local x80_backend=''
  if [[ "$XRAY80_ENABLED" == '1' ]]; then
    # PORT 80 SHARING FIX:
    # ProxyGo NEW GOLDEN remains the default/backend and is not modified.
    # Xray traffic is identified by the transport signature instead of relying
    # only on the literal Path. This is required because Xray normalizes an
    # HTTP path without a leading slash (e.g. alex -> /alex) and HTTP clients
    # percent-encode spaces/UTF-8 on the wire.
    local route_path route_path_no_query route_path_uri
    route_path_no_query="${XRAY80_PATH%%\?*}"
    [[ -n "$route_path_no_query" ]] || route_path_no_query='/'
    [[ "$route_path_no_query" == /* ]] || route_path_no_query="/$route_path_no_query"
    route_path_uri=$(jq -nr --arg v "$route_path_no_query" '$v|@uri')
    route_path_uri="${route_path_uri//%2F//}"

    case "$XRAY80_TRANSPORT" in
      websocket)
        # Genuine Xray WebSocket must match BOTH its normalized wire Path and
        # the WebSocket handshake (including Sec-WebSocket-Key).  ProxyGo stays
        # the default backend, so generic HTTP injector payloads containing
        # "Upgrade: websocket" are not stolen by Xray.
        x80_acl=$(cat <<EOF
    acl is_xray80_path    req.payload(0,0) -m sub -i " ${route_path_uri}"
    acl is_xray80_upgrade req.payload(0,0) -m sub -i "Upgrade: websocket"
    acl is_xray80_wskey   req.payload(0,0) -m sub -i "Sec-WebSocket-Key:"
    tcp-request content accept if is_xray80_path is_xray80_upgrade is_xray80_wskey
    use_backend xray_80 if is_xray80_path is_xray80_upgrade is_xray80_wskey
EOF
)
        ;;
      httpupgrade)
        # HTTPUpgrade does not require the WebSocket key used by real WS.
        # Keep the configured wire Path in the discriminator so ProxyGo remains
        # the fallback for unrelated/custom Upgrade payloads.
        x80_acl=$(cat <<EOF
    acl is_xray80_path    req.payload(0,0) -m sub -i " ${route_path_uri}"
    acl is_xray80_upgrade req.payload(0,0) -m sub -i "Upgrade: websocket"
    acl is_xray80_connup  req.payload(0,0) -m sub -i "Connection: Upgrade"
    tcp-request content accept if is_xray80_path is_xray80_upgrade is_xray80_connup
    use_backend xray_80 if is_xray80_path is_xray80_upgrade is_xray80_connup
EOF
)
        ;;
      grpc)
        x80_acl=$(cat <<'EOF'
    acl is_xray80_h2 req.payload(0,14) -m str "PRI * HTTP/2.0"
    tcp-request content accept if is_xray80_h2
    use_backend xray_80 if is_xray80_h2
EOF
)
        ;;
      xhttp)
        # XHTTP can arrive over HTTP/1.1 or HTTP/2. For HTTP/1.1 match the
        # normalized percent-encoded wire path; for h2 route by the preface.
        x80_acl=$(cat <<EOF
    acl is_xray80_path req.payload(0,0) -m sub -i " ${route_path_uri}"
    acl is_xray80_h2 req.payload(0,14) -m str "PRI * HTTP/2.0"
    tcp-request content accept if is_xray80_path
    tcp-request content accept if is_xray80_h2
    use_backend xray_80 if is_xray80_path
    use_backend xray_80 if is_xray80_h2
EOF
)
        ;;
      *)
        echo 'ERROR: transporte Xray80 no soportado para sharing en 80.' >&2
        return 1
        ;;
    esac

    x80_backend=$(cat <<EOF

backend xray_80
    mode tcp
    server xray80 127.0.0.1:${XRAY80_PORT} check
EOF
)
  fi

  cat > "$HA_CFG" <<EOF
global
    log /dev/log local0
    log /dev/log local1 notice
    daemon
    user haproxy
    group haproxy
    maxconn ${HAPROXY_MAXCONN:-8192}
    ssl-default-bind-options no-sslv3 no-tlsv10 no-tlsv11
    stats socket /run/haproxy/admin.sock mode 660 level admin expose-fd listeners

defaults
    log global
    mode tcp
    option tcplog
    option tcpka
    timeout connect 5s
    timeout client  2h
    timeout server  2h
    timeout tunnel  24h

# ---------------------------------------------------------------
# TCP/443 COMPARTIDO
# HAProxy termina TLS. SSH comienza con SSH- y va a OpenSSH.
# Todo otro payload va al perfil Xray 443.
# ---------------------------------------------------------------
frontend shared_ssl_v2ray_443
    bind *:443 ssl crt ${HA_CERT} alpn h2,http/1.1
    mode tcp
    tcp-request inspect-delay 400ms
    acl enough_payload req.len ge 4
    acl is_ssh req.payload(0,4) -m str SSH-
    tcp-request content accept if enough_payload
    use_backend ssh_direct if is_ssh
    use_backend xray_selected if enough_payload !is_ssh
    default_backend ssh_direct

backend ssh_direct
    mode tcp
    server ssh1 127.0.0.1:22 check

backend xray_selected
    mode tcp
    server xray1 127.0.0.1:${XRAY_PORT} check

# ---------------------------------------------------------------
# TCP/80 COMPARTIDO
# ProxyGo NEW GOLDEN es el backend por defecto.
# Solo el path Xray configurado / h2c se desvia a Xray local.
# Esto preserva el comportamiento ProxyGo que ya funciona en Golden MX.
# ---------------------------------------------------------------
frontend shared_proxygo_v2ray_80
    bind *:80
    mode tcp
    tcp-request inspect-delay 200ms
${x80_acl}
    default_backend proxygo_80

backend proxygo_80
    mode tcp
    server proxygo1 127.0.0.1:${PROXYGO_LOCAL_PORT} check${x80_backend}
EOF

  if ! haproxy -c -f "$HA_CFG"; then
    echo -e "${C_RED}ERROR: la configuracion HAProxy no paso validacion.${C_RESET}"
    return 1
  fi
  systemctl enable haproxy >/dev/null 2>&1 || true
  systemctl restart haproxy || return 1
  return 0
}

install_haproxy_ssl() {
  install_base || return 1
  load_state
  if [[ ! -s "$HA_CERT" ]]; then
    echo 'Primero se preparara el certificado TLS.'
    configure_certificate || return 1
  fi
  write_haproxy_config || return 1
  echo -e "${C_GREEN}HAProxy SSL directo activo en el puerto publico 443.${C_RESET}"
  echo 'Backend SSH: 127.0.0.1:22'
}

install_xray_core() {
  install_base || return 1
  echo -e "${C_CYAN}Instalando/actualizando Xray-core desde el instalador oficial XTLS...${C_RESET}"
  curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh -o /tmp/xray-install-release.sh || return 1
  bash /tmp/xray-install-release.sh install || return 1
  if [[ ! -x "$XRAY_BIN" ]]; then
    echo -e "${C_RED}Xray no quedo instalado en $XRAY_BIN${C_RESET}"
    return 1
  fi
  systemctl enable xray >/dev/null 2>&1 || true
  echo -e "${C_GREEN}Xray-core instalado.${C_RESET}"
}

transport_name() {
  case "$XRAY_TRANSPORT" in
    websocket) echo 'WebSocket' ;;
    xhttp) echo 'XHTTP' ;;
    grpc) echo 'gRPC' ;;
    raw) echo 'RAW/TCP' ;;
    httpupgrade) echo 'HTTPUpgrade' ;;
    *) echo "$XRAY_TRANSPORT" ;;
  esac
}

profile_name() {
  echo "${XRAY_PROTOCOL^^} + $(transport_name) + TLS"
}

xray_settings_for_protocol() {
  local proto="$1" public_port="$2" clients
  case "$proto" in
    vmess)
      clients=$(jq --argjson port "$public_port" '[.[] | select(((.port // 443)|tonumber)==$port) | {id:.uuid, level:0, email:(.name + "-" + ($port|tostring) + "@local")}]' "$USERS_FILE") || return 1
      jq -nc --argjson c "$clients" '{clients:$c}'
      ;;
    vless)
      clients=$(jq --argjson port "$public_port" '[.[] | select(((.port // 443)|tonumber)==$port) | {id:.uuid, level:0, email:(.name + "-" + ($port|tostring) + "@local")}]' "$USERS_FILE") || return 1
      jq -nc --argjson c "$clients" '{clients:$c,decryption:"none"}'
      ;;
    trojan)
      clients=$(jq --argjson port "$public_port" '[.[] | select(((.port // 443)|tonumber)==$port) | {password:.password, level:0, email:(.name + "-" + ($port|tostring) + "@local")}]' "$USERS_FILE") || return 1
      jq -nc --argjson c "$clients" '{clients:$c}'
      ;;
    *) return 1 ;;
  esac
}

xray_stream_for() {
  local transport="$1" path="$2" grpc="$3" xmode="$4"
  case "$transport" in
    websocket) jq -nc --arg p "$path" '{network:"ws",security:"none",wsSettings:{path:$p}}' ;;
    xhttp) jq -nc --arg p "$path" --arg m "$xmode" '{network:"xhttp",security:"none",xhttpSettings:{path:$p,mode:$m}}' ;;
    grpc) jq -nc --arg s "$grpc" '{network:"grpc",security:"none",grpcSettings:{serviceName:$s,multiMode:false}}' ;;
    raw) jq -nc '{network:"tcp",security:"none",tcpSettings:{header:{type:"none"}}}' ;;
    httpupgrade) jq -nc --arg p "$path" '{network:"httpupgrade",security:"none",httpupgradeSettings:{path:$p}}' ;;
    *) return 1 ;;
  esac
}

build_xray_config() {
  load_state
  [[ -x "$XRAY_BIN" ]] || { echo 'Xray no esta instalado.'; return 1; }
  [[ -f "$USERS_FILE" ]] || printf '[]
' > "$USERS_FILE"

  local set443 stream443 inbound443 inbounds tmp
  set443=$(xray_settings_for_protocol "$XRAY_PROTOCOL" 443) || return 1
  stream443=$(xray_stream_for "$XRAY_TRANSPORT" "$XRAY_PATH" "$XRAY_GRPC_SERVICE" "$XRAY_XHTTP_MODE") || return 1
  inbound443=$(jq -nc --arg proto "$XRAY_PROTOCOL" --argjson settings "$set443" --argjson stream "$stream443" --argjson port "$XRAY_PORT" '{tag:"shared443-in",listen:"127.0.0.1",port:$port,protocol:$proto,settings:$settings,streamSettings:$stream}')
  inbounds=$(jq -nc --argjson a "$inbound443" '[$a]')

  if [[ "$XRAY80_ENABLED" == '1' ]]; then
    case "$XRAY80_TRANSPORT" in
      websocket|xhttp|grpc|httpupgrade) ;;
      *) echo 'Puerto 80 compartido solo admite WS/XHTTP/gRPC/HTTPUpgrade.'; return 1 ;;
    esac
    local set80 stream80 inbound80
    set80=$(xray_settings_for_protocol "$XRAY80_PROTOCOL" 80) || return 1
    stream80=$(xray_stream_for "$XRAY80_TRANSPORT" "$XRAY80_PATH" "$XRAY80_GRPC_SERVICE" "$XRAY80_XHTTP_MODE") || return 1
    inbound80=$(jq -nc --arg proto "$XRAY80_PROTOCOL" --argjson settings "$set80" --argjson stream "$stream80" --argjson port "$XRAY80_PORT" '{tag:"shared80-in",listen:"127.0.0.1",port:$port,protocol:$proto,settings:$settings,streamSettings:$stream}')
    inbounds=$(jq -nc --argjson a "$inbounds" --argjson b "$inbound80" '$a + [$b]')
  fi

  tmp=$(mktemp)
  jq -n --argjson inbounds "$inbounds" '{log:{loglevel:"warning"},inbounds:$inbounds,outbounds:[{tag:"direct",protocol:"freedom",settings:{}},{tag:"blocked",protocol:"blackhole",settings:{}}]}' > "$tmp" || { rm -f "$tmp"; return 1; }

  backup_file_once "$XRAY_CONFIG" 'xray-config.json'
  install -m 644 "$tmp" "$XRAY_CONFIG"
  rm -f "$tmp"

  if ! "$XRAY_BIN" run -test -config "$XRAY_CONFIG" >/tmp/xray-test.log 2>&1; then
    if ! "$XRAY_BIN" -test -config "$XRAY_CONFIG" >/tmp/xray-test.log 2>&1; then
      echo -e "${C_RED}ERROR: Xray rechazo la configuracion.${C_RESET}"
      cat /tmp/xray-test.log
      return 1
    fi
  fi

  systemctl daemon-reload
  systemctl enable xray >/dev/null 2>&1 || true
  systemctl restart xray || return 1
  return 0
}

choose_xray_profile() {
  load_state
  safe_clear
  bar
  echo -e "${C_GOLD}     ELEGIR PROTOCOLO / TRANSPORTE V2RAY - PUERTO 443${C_RESET}"
  bar
  echo '[1] VMESS + WEBSOCKET + TLS'
  echo '[2] VLESS + WEBSOCKET + TLS'
  echo '[3] VLESS + XHTTP + TLS'
  echo '[4] VLESS + gRPC + TLS'
  echo '[5] VLESS + RAW/TCP + TLS'
  echo '[6] TROJAN + RAW/TCP + TLS'
  echo '[7] VMESS + RAW/TCP + TLS'
  echo '[8] VLESS + HTTPUPGRADE + TLS'
  echo '[0] VOLVER'
  bar
  read -r -p 'Seleccione: ' op
  case "$op" in
    1) XRAY_PROTOCOL='vmess'; XRAY_TRANSPORT='websocket' ;;
    2) XRAY_PROTOCOL='vless'; XRAY_TRANSPORT='websocket' ;;
    3) XRAY_PROTOCOL='vless'; XRAY_TRANSPORT='xhttp' ;;
    4) XRAY_PROTOCOL='vless'; XRAY_TRANSPORT='grpc' ;;
    5) XRAY_PROTOCOL='vless'; XRAY_TRANSPORT='raw' ;;
    6) XRAY_PROTOCOL='trojan'; XRAY_TRANSPORT='raw' ;;
    7) XRAY_PROTOCOL='vmess'; XRAY_TRANSPORT='raw' ;;
    8) XRAY_PROTOCOL='vless'; XRAY_TRANSPORT='httpupgrade' ;;
    0) return 0 ;;
    *) echo 'Opcion invalida.'; pause; return 0 ;;
  esac

  if [[ "$XRAY_TRANSPORT" == 'websocket' || "$XRAY_TRANSPORT" == 'xhttp' || "$XRAY_TRANSPORT" == 'httpupgrade' ]]; then
    printf "Path EXACTO ENTER para usar [${XRAY_PATH}]: "
    IFS= read -r p
    XRAY_PATH=$(normalize_path "$p" "$XRAY_PATH")
  fi
  if [[ "$XRAY_TRANSPORT" == 'grpc' ]]; then
    read -r -p "ServiceName gRPC [${XRAY_GRPC_SERVICE}]: " s
    [[ -n "$s" ]] && XRAY_GRPC_SERVICE="$s"
  fi
  if [[ "$XRAY_TRANSPORT" == 'xhttp' ]]; then
    echo 'Modo XHTTP recomendado: auto'
    read -r -p "Modo [${XRAY_XHTTP_MODE}]: " m
    [[ -n "$m" ]] && XRAY_XHTTP_MODE="$m"
  fi

  save_state
  if [[ -x "$XRAY_BIN" ]]; then
    if build_xray_config; then
      write_haproxy_config >/dev/null 2>&1 || true
      echo -e "${C_GREEN}Perfil aplicado: $(profile_name)${C_RESET}"
    fi
  else
    echo -e "${C_GOLD}Perfil guardado. Instala Xray-core para aplicarlo.${C_RESET}"
  fi
  pause
}

xray80_profile_name() {
  [[ "$XRAY80_ENABLED" == '1' ]] || { echo 'DESACTIVADO'; return; }
  local t
  case "$XRAY80_TRANSPORT" in
    websocket) t='WebSocket' ;;
    xhttp) t='XHTTP' ;;
    grpc) t='gRPC/h2c' ;;
    httpupgrade) t='HTTPUpgrade' ;;
    *) t="$XRAY80_TRANSPORT" ;;
  esac
  echo "${XRAY80_PROTOCOL^^} + ${t} (SIN TLS)"
}

choose_xray80_profile() {
  load_state
  safe_clear
  bar
  echo -e "${C_GOLD}      V2RAY/XRAY EN PUERTO 80 COMPARTIDO CON PROXYGO${C_RESET}"
  bar
  echo 'ProxyGo NEW GOLDEN sigue siendo el backend por defecto del puerto 80.'
  echo 'Xray se identifica por path HTTP o por HTTP/2 h2c.'
  echo 'RAW/TCP y Trojan RAW no se ofrecen aqui porque no se pueden distinguir'
  echo 'de ProxyGo de forma segura en el mismo TCP/80.'
  bar
  echo '[1] VMESS + WEBSOCKET'
  echo '[2] VLESS + WEBSOCKET'
  echo '[3] VLESS + XHTTP'
  echo '[4] VLESS + HTTPUPGRADE'
  echo '[5] VLESS + gRPC / h2c'
  echo '[6] DESACTIVAR XRAY EN 80 (ProxyGo queda solo)'
  echo '[0] VOLVER'
  bar
  read -r -p 'Seleccione: ' op
  case "$op" in
    1) XRAY80_ENABLED='1'; XRAY80_PROTOCOL='vmess'; XRAY80_TRANSPORT='websocket' ;;
    2) XRAY80_ENABLED='1'; XRAY80_PROTOCOL='vless'; XRAY80_TRANSPORT='websocket' ;;
    3) XRAY80_ENABLED='1'; XRAY80_PROTOCOL='vless'; XRAY80_TRANSPORT='xhttp' ;;
    4) XRAY80_ENABLED='1'; XRAY80_PROTOCOL='vless'; XRAY80_TRANSPORT='httpupgrade' ;;
    5) XRAY80_ENABLED='1'; XRAY80_PROTOCOL='vless'; XRAY80_TRANSPORT='grpc' ;;
    6) XRAY80_ENABLED='0'; save_state; [[ -x "$XRAY_BIN" ]] && build_xray_config >/dev/null 2>&1 || true; write_haproxy_config >/dev/null 2>&1 || true; echo 'Xray 80 desactivado; ProxyGo sigue en 80.'; pause; return 0 ;;
    0) return 0 ;;
    *) echo 'Opcion invalida.'; pause; return 0 ;;
  esac

  if [[ "$XRAY80_TRANSPORT" == 'websocket' || "$XRAY80_TRANSPORT" == 'xhttp' || "$XRAY80_TRANSPORT" == 'httpupgrade' ]]; then
    printf "Path EXACTO Xray80 ENTER para usar [${XRAY80_PATH}]: "
    IFS= read -r p
    XRAY80_PATH=$(normalize_path "$p" "$XRAY80_PATH")
  fi
  if [[ "$XRAY80_TRANSPORT" == 'grpc' ]]; then
    read -r -p "ServiceName gRPC [${XRAY80_GRPC_SERVICE}]: " s
    [[ -n "$s" ]] && XRAY80_GRPC_SERVICE="$s"
  fi
  if [[ "$XRAY80_TRANSPORT" == 'xhttp' ]]; then
    read -r -p "Modo XHTTP [${XRAY80_XHTTP_MODE}]: " m
    [[ -n "$m" ]] && XRAY80_XHTTP_MODE="$m"
  fi
  save_state
  [[ -x "$XRAY_BIN" ]] && build_xray_config || true
  write_haproxy_config || true
  echo -e "${C_GREEN}Perfil 80 aplicado: $(xray80_profile_name)${C_RESET}"
  pause
}

valid_username() {
  [[ "$1" =~ ^[A-Za-z0-9._-]{1,32}$ ]]
}

valid_uuid() {
  [[ "$1" =~ ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ]]
}

normalize_path() {
  local path="$1"
  local def="$2"

  # Misma logica del PANEL XRAY PROFESIONAL [ GOLDEN MX / XTLS + xHTTP ]:
  # si esta vacio usa el valor por defecto; si escribes algo, se respeta
  # EXACTAMENTE como fue capturado. No agrega /, no recorta espacios.
  [[ -z "$path" ]] && path="$def"

  echo "$path"
}

generate_default_path() {
  local port="$1" user="$2" rnd
  rnd=$(openssl rand -hex 4 2>/dev/null || printf '%08x' "$RANDOM")
  printf '/xray-%s-%s-%s' "$port" "$user" "$rnd"
}

generate_uuid_value() {
  local u=''
  if [[ -x "$XRAY_BIN" ]]; then
    u=$($XRAY_BIN uuid 2>/dev/null | head -n1 || true)
  fi
  if [[ -z "$u" ]] && command -v uuidgen >/dev/null 2>&1; then
    u=$(uuidgen 2>/dev/null || true)
  fi
  if [[ -z "$u" && -r /proc/sys/kernel/random/uuid ]]; then
    u=$(cat /proc/sys/kernel/random/uuid 2>/dev/null || true)
  fi
  if [[ -z "$u" ]]; then
    local h
    h=$(openssl rand -hex 16)
    u="${h:0:8}-${h:8:4}-${h:12:4}-${h:16:4}-${h:20:12}"
  fi
  printf '%s' "${u,,}"
}

users_on_port() {
  local port="$1"
  jq --argjson port "$port" '[.[] | select(((.port // 443)|tonumber)==$port)] | length' "$USERS_FILE" 2>/dev/null || echo 0
}

create_xray_user() {
  load_state
  ensure_dirs
  migrate_users_file || { echo 'No se pudo preparar la base de usuarios.'; pause; return 0; }

  safe_clear
  bar
  echo -e "${C_GOLD}           CREAR USUARIO V2RAY/XRAY - PUERTO 80/443${C_RESET}"
  bar
  echo "[1] PUERTO 443  -> $(profile_name)"
  if [[ "$XRAY80_ENABLED" == '1' ]]; then
    echo "[2] PUERTO 80   -> $(xray80_profile_name)"
  else
    echo -e "[2] PUERTO 80   -> ${C_RED}DESACTIVADO${C_RESET} (configuralo primero en opcion 7)"
  fi
  echo '[0] VOLVER'
  bar

  local sel public_port proto transport current_path current_grpc current_mode security
  read -r -p 'Selecciona el puerto para este usuario: ' sel
  case "$sel" in
    1|443)
      public_port=443
      proto="$XRAY_PROTOCOL"
      transport="$XRAY_TRANSPORT"
      current_path="$XRAY_PATH"
      current_grpc="$XRAY_GRPC_SERVICE"
      current_mode="$XRAY_XHTTP_MODE"
      security='tls'
      ;;
    2|80)
      if [[ "$XRAY80_ENABLED" != '1' ]]; then
        echo 'Xray en puerto 80 esta desactivado. Activalo/configuralo en la opcion 7.'
        pause; return 0
      fi
      public_port=80
      proto="$XRAY80_PROTOCOL"
      transport="$XRAY80_TRANSPORT"
      current_path="$XRAY80_PATH"
      current_grpc="$XRAY80_GRPC_SERVICE"
      current_mode="$XRAY80_XHTTP_MODE"
      security='none'
      ;;
    0) return 0 ;;
    *) echo 'Puerto/opcion invalida.'; pause; return 0 ;;
  esac

  echo
  echo "Puerto seleccionado : $public_port"
  echo "Protocolo           : ${proto^^}"
  echo "Transporte          : $transport"
  echo "Seguridad           : $security"
  [[ "$transport" == 'websocket' || "$transport" == 'xhttp' || "$transport" == 'httpupgrade' ]] && echo "Path actual          : $current_path"
  [[ "$transport" == 'grpc' ]] && echo "ServiceName actual   : $current_grpc"
  bar

  local name existing_count path_input selected_path service_input selected_service host_input host uuid password cred_input tmp created
  read -r -p 'Nombre del usuario V2RAY: ' name
  if ! valid_username "$name"; then
    echo 'Nombre invalido. Usa letras, numeros, punto, guion o guion bajo.'
    pause; return 0
  fi
  if jq -e --arg n "$name" --argjson port "$public_port" '.[] | select(.name==$n and (((.port // 443)|tonumber)==$port))' "$USERS_FILE" >/dev/null; then
    echo "Ese usuario ya existe en el puerto $public_port."
    pause; return 0
  fi

  existing_count=$(users_on_port "$public_port")
  selected_path="$current_path"
  selected_service="$current_grpc"

  if [[ "$transport" == 'websocket' || "$transport" == 'xhttp' || "$transport" == 'httpupgrade' ]]; then
    # MISMA LOGICA DEL PANEL XRAY PROFESIONAL GOLDEN MX:
    # IFS= read -r conserva los espacios de ambos extremos y NO agrega '/'.
    # ENTER reutiliza exactamente el Path actual del inbound.
    printf 'Path EXACTO ENTER para usar el del puerto: '
    IFS= read -r path_input

    if [[ -z "$path_input" ]]; then
      selected_path="$current_path"
    elif [[ "$path_input" == 'AUTO' ]]; then
      selected_path=$(generate_default_path "$public_port" "$name")
    else
      # Asignacion DIRECTA: ninguna normalizacion, trim, sed ni slash automatico.
      selected_path="$path_input"
    fi

    # El Path pertenece al inbound del puerto. Igual que Golden MX, si el usuario
    # escribe uno nuevo se aplica directamente al inbound y a los usuarios de ese puerto.
  elif [[ "$transport" == 'grpc' ]]; then
    if [[ "$existing_count" -gt 0 ]]; then
      read -r -p "ServiceName gRPC [$current_grpc] (ENTER conserva): " service_input
      selected_service="${service_input:-$current_grpc}"
    else
      read -r -p 'ServiceName gRPC (ENTER = automatico): ' service_input
      selected_service="${service_input:-grpc-${public_port}-${name}-$(openssl rand -hex 3)}"
    fi
  fi

  host=$(host_for_clients)
  read -r -p "Host/SNI para link [$host] (ENTER = automatico): " host_input
  [[ -n "$host_input" ]] && host="$host_input"

  if [[ "$proto" == 'trojan' ]]; then
    read -r -p 'Password personalizado (ENTER = automatico): ' cred_input
    password="${cred_input:-$(openssl rand -hex 16)}"
    uuid=$(generate_uuid_value)
  else
    read -r -p 'UUID personalizado (ENTER = automatico): ' cred_input
    if [[ -z "$cred_input" ]]; then
      uuid=$(generate_uuid_value)
    else
      uuid="$cred_input"
    fi
    if ! valid_uuid "$uuid"; then
      echo 'UUID INVALIDO. Usa formato UUID correcto o deja ENTER para automatico.'
      pause; return 0
    fi
    uuid="${uuid,,}"
    if jq -e --arg u "$uuid" '.[] | select(.uuid==$u)' "$USERS_FILE" >/dev/null; then
      echo 'Ese UUID ya existe. Usa otro o deja ENTER para generar uno.'
      pause; return 0
    fi
    password=$(openssl rand -hex 16)
  fi

  # El Path/ServiceName pertenece al inbound del puerto, igual que en GOLDEN MX.
  if [[ "$public_port" -eq 443 ]]; then
    [[ -n "$selected_path" ]] && XRAY_PATH="$selected_path"
    [[ -n "$selected_service" ]] && XRAY_GRPC_SERVICE="$selected_service"
  else
    [[ -n "$selected_path" ]] && XRAY80_PATH="$selected_path"
    [[ -n "$selected_service" ]] && XRAY80_GRPC_SERVICE="$selected_service"
  fi
  save_state

  # Si se cambio el Path, sincronizarlo en los registros del mismo puerto.
  if [[ -n "$selected_path" ]]; then
    tmp=$(mktemp)
    jq --argjson port "$public_port" --arg path "$selected_path" \
      'map(if (((.port // 443)|tonumber)==$port) then .path=$path else . end)' "$USERS_FILE" > "$tmp" || { rm -f "$tmp"; return 1; }
    install -m 600 "$tmp" "$USERS_FILE"
    rm -f "$tmp"
  fi

  created=$(date '+%F %T')
  tmp=$(mktemp)
  jq --arg n "$name" --arg u "$uuid" --arg p "$password" --argjson port "$public_port" --arg host "$host" --arg path "$selected_path" --arg created "$created" \
    '. + [{name:$n,uuid:$u,password:$p,port:$port,host:$host,path:$path,created:$created}]' "$USERS_FILE" > "$tmp" || { rm -f "$tmp"; return 1; }
  install -m 600 "$tmp" "$USERS_FILE"
  rm -f "$tmp"

  if [[ -x "$XRAY_BIN" ]]; then
    if ! build_xray_config; then
      echo 'ERROR: no se pudo aplicar el usuario a Xray.'
      pause; return 0
    fi
  fi
  write_haproxy_config >/dev/null 2>&1 || true

  bar
  echo -e "${C_GREEN}USUARIO CREADO CORRECTAMENTE${C_RESET}"
  echo "Usuario : $name"
  echo "Puerto  : $public_port"
  if [[ "$proto" == 'trojan' ]]; then echo "Password: $password"; else echo "UUID    : $uuid"; fi
  [[ "$transport" == 'websocket' || "$transport" == 'xhttp' || "$transport" == 'httpupgrade' ]] && printf 'Path    : [%s]\n' "$selected_path"
  [[ "$transport" == 'grpc' ]] && echo "gRPC    : $selected_service"
  bar
  if [[ "$public_port" -eq 443 ]]; then show_one_xray_user "$name"; else show_one_xray_user80 "$name"; fi
  pause
}

delete_xray_user() {
  load_state
  ensure_dirs
  migrate_users_file || true
  local port name tmp count
  safe_clear
  bar
  echo -e "${C_GOLD}              ELIMINAR USUARIO V2RAY/XRAY${C_RESET}"
  bar
  jq -r '.[] | "- " + .name + "  Puerto:" + (((.port // 443)|tonumber)|tostring)' "$USERS_FILE" 2>/dev/null || true
  bar
  read -r -p 'Puerto del usuario [443/80]: ' port
  [[ "$port" == '443' || "$port" == '80' ]] || { echo 'Puerto invalido.'; pause; return 0; }
  read -r -p 'Usuario V2RAY a eliminar: ' name
  if ! jq -e --arg n "$name" --argjson port "$port" '.[] | select(.name==$n and (((.port // 443)|tonumber)==$port))' "$USERS_FILE" >/dev/null; then
    echo "No existe ese usuario en el puerto $port."
    pause; return 0
  fi
  tmp=$(mktemp)
  jq --arg n "$name" --argjson port "$port" '[.[] | select(.name!=$n or (((.port // 443)|tonumber)!=$port))]' "$USERS_FILE" > "$tmp" || { rm -f "$tmp"; return 1; }
  install -m 600 "$tmp" "$USERS_FILE"
  rm -f "$tmp"
  [[ -x "$XRAY_BIN" ]] && build_xray_config || true
  write_haproxy_config >/dev/null 2>&1 || true
  echo -e "${C_GREEN}Usuario eliminado del puerto $port.${C_RESET}"
  pause
}

uri_encode() {
  jq -nr --arg v "$1" '$v|@uri'
}

show_one_xray_user() {
  load_state
  local name="$1" row uuid pass host label p_enc s_enc name_enc net vmjson link row_path
  row=$(jq -c --arg n "$name" '.[] | select(.name==$n and (((.port // 443)|tonumber)==443))' "$USERS_FILE" | head -n1)
  [[ -n "$row" ]] || return 1
  uuid=$(jq -r '.uuid' <<<"$row")
  pass=$(jq -r '.password' <<<"$row")
  host=$(jq -r '.host // empty' <<<"$row"); [[ -n "$host" ]] || host=$(host_for_clients)
  row_path=$(jq -r '.path // empty' <<<"$row"); [[ -n "$row_path" ]] || row_path="$XRAY_PATH"
  label="${name}-443"
  name_enc=$(uri_encode "$label")
  p_enc=$(uri_encode "$row_path")
  s_enc=$(uri_encode "$XRAY_GRPC_SERVICE")

  bar
  echo -e "${C_WHITE}USUARIO:${C_RESET} $name"
  echo "Perfil : $(profile_name)"
  echo "Host   : $host"
  echo 'Puerto : 443'
  [[ -n "$DOMAIN" ]] && echo "SNI    : $DOMAIN"
  [[ "$CERT_MODE" == 'self-signed' ]] && echo -e "${C_GOLD}TLS inseguro/allowInsecure: ACTIVAR en el cliente${C_RESET}"

  case "$XRAY_PROTOCOL" in
    vless)
      case "$XRAY_TRANSPORT" in
        websocket) link="vless://${uuid}@${host}:443?encryption=none&security=tls&sni=$(uri_encode "$DOMAIN")&type=ws&host=$(uri_encode "$DOMAIN")&path=${p_enc}#${name_enc}" ;;
        xhttp) link="vless://${uuid}@${host}:443?encryption=none&security=tls&sni=$(uri_encode "$DOMAIN")&type=xhttp&path=${p_enc}&mode=$(uri_encode "$XRAY_XHTTP_MODE")#${name_enc}" ;;
        grpc) link="vless://${uuid}@${host}:443?encryption=none&security=tls&sni=$(uri_encode "$DOMAIN")&type=grpc&serviceName=${s_enc}#${name_enc}" ;;
        raw) link="vless://${uuid}@${host}:443?encryption=none&security=tls&sni=$(uri_encode "$DOMAIN")&type=tcp#${name_enc}" ;;
        httpupgrade) link="vless://${uuid}@${host}:443?encryption=none&security=tls&sni=$(uri_encode "$DOMAIN")&type=httpupgrade&host=$(uri_encode "$DOMAIN")&path=${p_enc}#${name_enc}" ;;
      esac
      echo "UUID   : $uuid"
      ;;
    vmess)
      case "$XRAY_TRANSPORT" in websocket) net='ws' ;; grpc) net='grpc' ;; raw) net='tcp' ;; xhttp) net='xhttp' ;; httpupgrade) net='httpupgrade' ;; *) net='tcp' ;; esac
      vmjson=$(jq -nc --arg v '2' --arg ps "$label" --arg add "$host" --arg port '443' --arg id "$uuid" --arg aid '0' --arg scy 'auto' --arg net "$net" --arg type 'none' --arg host "$DOMAIN" --arg path "$row_path" --arg tls 'tls' --arg sni "$DOMAIN" --arg serviceName "$XRAY_GRPC_SERVICE" '{v:$v,ps:$ps,add:$add,port:$port,id:$id,aid:$aid,scy:$scy,net:$net,type:$type,host:$host,path:(if $net=="grpc" then $serviceName else $path end),tls:$tls,sni:$sni}')
      link="vmess://$(printf '%s' "$vmjson" | base64 -w0)"
      echo "UUID   : $uuid"
      ;;
    trojan)
      link="trojan://${pass}@${host}:443?security=tls&sni=$(uri_encode "$DOMAIN")&type=tcp#${name_enc}"
      echo "Password: $pass"
      ;;
  esac
  case "$XRAY_TRANSPORT" in websocket|httpupgrade) echo "Path   : $row_path" ;; xhttp) echo "Path   : $row_path"; echo "XHTTP  : $XRAY_XHTTP_MODE" ;; grpc) echo "gRPC   : $XRAY_GRPC_SERVICE" ;; esac
  echo; echo 'LINK:'; echo "$link"; bar
}

show_one_xray_user80() {
  load_state
  [[ "$XRAY80_ENABLED" == '1' ]] || return 0
  local name="$1" row uuid host label name_enc p_enc s_enc link vmjson net row_path
  row=$(jq -c --arg n "$name" '.[] | select(.name==$n and (((.port // 443)|tonumber)==80))' "$USERS_FILE" | head -n1)
  [[ -n "$row" ]] || return 1
  uuid=$(jq -r '.uuid' <<<"$row")
  host=$(jq -r '.host // empty' <<<"$row"); [[ -n "$host" ]] || host=$(host_for_clients)
  row_path=$(jq -r '.path // empty' <<<"$row"); [[ -n "$row_path" ]] || row_path="$XRAY80_PATH"
  label="${name}-80"
  name_enc=$(uri_encode "$label")
  p_enc=$(uri_encode "$row_path")
  s_enc=$(uri_encode "$XRAY80_GRPC_SERVICE")
  echo
  echo -e "${C_GOLD}PUERTO 80 COMPARTIDO CON PROXYGO:${C_RESET}"
  echo "Perfil : $(xray80_profile_name)"
  echo "Host   : $host"
  echo 'Puerto : 80'
  echo 'TLS    : OFF'
  case "$XRAY80_PROTOCOL" in
    vless)
      case "$XRAY80_TRANSPORT" in
        websocket) link="vless://${uuid}@${host}:80?encryption=none&security=none&type=ws&host=$(uri_encode "$DOMAIN")&path=${p_enc}#${name_enc}" ;;
        xhttp) link="vless://${uuid}@${host}:80?encryption=none&security=none&type=xhttp&path=${p_enc}&mode=$(uri_encode "$XRAY80_XHTTP_MODE")#${name_enc}" ;;
        grpc) link="vless://${uuid}@${host}:80?encryption=none&security=none&type=grpc&serviceName=${s_enc}#${name_enc}" ;;
        httpupgrade) link="vless://${uuid}@${host}:80?encryption=none&security=none&type=httpupgrade&host=$(uri_encode "$DOMAIN")&path=${p_enc}#${name_enc}" ;;
      esac
      echo "UUID   : $uuid"
      ;;
    vmess)
      case "$XRAY80_TRANSPORT" in websocket) net='ws' ;; *) net="$XRAY80_TRANSPORT" ;; esac
      vmjson=$(jq -nc --arg v '2' --arg ps "$label" --arg add "$host" --arg port '80' --arg id "$uuid" --arg aid '0' --arg scy 'auto' --arg net "$net" --arg type 'none' --arg host "$DOMAIN" --arg path "$row_path" --arg tls '' '{v:$v,ps:$ps,add:$add,port:$port,id:$id,aid:$aid,scy:$scy,net:$net,type:$type,host:$host,path:$path,tls:$tls}')
      link="vmess://$(printf '%s' "$vmjson" | base64 -w0)"
      echo "UUID   : $uuid"
      ;;
  esac
  case "$XRAY80_TRANSPORT" in websocket|httpupgrade) echo "Path   : $row_path" ;; xhttp) echo "Path   : $row_path"; echo "XHTTP  : $XRAY80_XHTTP_MODE" ;; grpc) echo "gRPC   : $XRAY80_GRPC_SERVICE" ;; esac
  echo 'LINK 80:'; echo "$link"; bar
}

show_xray_users() {
  load_state
  ensure_dirs
  migrate_users_file || true
  safe_clear
  bar
  echo -e "${C_GOLD}          USUARIOS + LINKS V2RAY/XRAY 80 / 443${C_RESET}"
  bar
  local count c443 c80
  count=$(jq 'length' "$USERS_FILE")
  c443=$(users_on_port 443)
  c80=$(users_on_port 80)
  echo "Perfil 443 : $(profile_name)"
  echo "Perfil 80  : $(xray80_profile_name)"
  echo "Usuarios   : $count total | 443=$c443 | 80=$c80"
  echo
  if [[ "$count" -eq 0 ]]; then
    echo 'No hay usuarios V2RAY creados.'
  else
    while IFS=$'\t' read -r name port; do
      if [[ "$port" == '80' ]]; then show_one_xray_user80 "$name"; else show_one_xray_user "$name"; fi
      echo
    done < <(jq -r '.[] | [.name, (((.port // 443)|tonumber)|tostring)] | @tsv' "$USERS_FILE")
  fi
  write_info_file >/dev/null 2>&1 || true
  pause
}

create_ssh_user() {
  local user pass
  read -r -p 'Nuevo usuario SSH: ' user
  if ! [[ "$user" =~ ^[a-z_][a-z0-9_-]{0,30}$ ]]; then
    echo 'Nombre Linux invalido.'; pause; return 0
  fi
  if id "$user" >/dev/null 2>&1; then
    echo 'El usuario ya existe.'; pause; return 0
  fi
  read -r -s -p 'Password SSH: ' pass; echo
  [[ -n "$pass" ]] || { echo 'Password vacio no permitido.'; pause; return 0; }
  useradd -m -s /bin/bash "$user" || { pause; return 0; }
  printf '%s:%s\n' "$user" "$pass" | chpasswd
  echo -e "${C_GREEN}Usuario SSH creado.${C_RESET}"
  echo 'Conexion SSL: servidor/IP + puerto 443 + este usuario/password.'
  pause
}

delete_ssh_user() {
  local user
  read -r -p 'Usuario SSH a eliminar: ' user
  if [[ "$user" == 'root' ]]; then
    echo 'No se permite borrar root desde este manager.'; pause; return 0
  fi
  id "$user" >/dev/null 2>&1 || { echo 'No existe.'; pause; return 0; }
  userdel -r "$user" 2>/dev/null || userdel "$user"
  echo -e "${C_GREEN}Usuario SSH eliminado.${C_RESET}"
  pause
}

ssh_users_menu() {
  while true; do
    safe_clear
    bar
    echo -e "${C_GOLD}              USUARIOS SSH PARA SSL DIRECTO${C_RESET}"
    bar
    echo '[1] CREAR USUARIO SSH'
    echo '[2] ELIMINAR USUARIO SSH'
    echo '[3] MOSTRAR USUARIOS SSH'
    echo '[0] VOLVER'
    bar
    read -r -p 'Seleccione: ' op
    case "$op" in
      1) create_ssh_user ;;
      2) delete_ssh_user ;;
      3) awk -F: '$3>=1000 && $1!="nobody" {print $1}' /etc/passwd; pause ;;
      0) return 0 ;;
      *) echo 'Opcion invalida.'; sleep 1 ;;
    esac
  done
}

# =====================================================================
# PROXYGO NEW GOLDEN - MOTOR GOLDEN MX EXACTO
# Conserva la secuencia compatible de Golden MX:
#   101 -> descarta payload/inyeccion inicial -> 200 <banner> -> SSH backend.
# FIX V3.6: el Golden original hacia un solo Read(1024). Si el payload llegaba
# fragmentado o superaba 1024 bytes, podian quedar bytes de inyeccion pendientes
# y contaminar el handshake SSH. Aqui se drena la inyeccion completa por rafagas,
# sin interpretar su contenido: acepta payloads HTTP/WS raros, UTF-8 y fragmentados.
# El LISTEN sigue local 127.0.0.1:18080 para compartir :80 con Xray via HAProxy.
# =====================================================================
proxygo_compile_golden() {
  install_base || return 1
  mkdir -p "$PROXYGO_SRC_DIR" "$PROXYGO_DIR"
  cat > "$PROXYGO_SRC_DIR/main.go" <<'EOF'
package main

import (
	"bytes"
	"flag"
	"fmt"
	"io"
	"net"
	"time"
)

func findSSHIdent(b []byte) int {
	needles := [][]byte{[]byte("SSH-2.0-"), []byte("SSH-1.99-")}
	best := -1
	for _, needle := range needles {
		from := 0
		for from < len(b) {
			i := bytes.Index(b[from:], needle)
			if i < 0 { break }
			i += from
			if i == 0 || b[i-1] == '\n' || b[i-1] == '\r' {
				if best < 0 || i < best { best = i }
				break
			}
			from = i + 1
		}
	}
	return best
}

func closeWrite(c net.Conn) {
	if t, ok := c.(*net.TCPConn); ok { _ = t.CloseWrite() }
}

func handle(client net.Conn, target string, banner string) {
	defer client.Close()

	if tcp, ok := client.(*net.TCPConn); ok {
		_ = tcp.SetNoDelay(true)
		_ = tcp.SetKeepAlive(true)
		_ = tcp.SetKeepAlivePeriod(60 * time.Second)
	}

	if banner == "" {
		banner = "OK"
	}

	// Primera respuesta fija
	_, _ = client.Write([]byte("HTTP/1.1 101 Connection Established\r\n\r\n"))

	// Consumir SOLO la inyección inicial. Si el cliente encadena su identificación
	// SSH en el mismo paquete (común al reconectar), preservarla para no perder KEX.
	client.SetReadDeadline(time.Now().Add(1500 * time.Millisecond))
	buffer := make([]byte, 4096)
	n, _ := client.Read(buffer)
	client.SetReadDeadline(time.Time{})
	var pendingSSH []byte
	if n > 0 {
		if idx := findSSHIdent(buffer[:n]); idx >= 0 {
			pendingSSH = append([]byte(nil), buffer[idx:n]...)
		}
	}

	// Mantener exactamente el banner/protocolo existente.
	_, _ = client.Write([]byte(fmt.Sprintf("HTTP/1.1 200 %s\r\n\r\n", banner)))

	server, err := net.DialTimeout("tcp", target, 10*time.Second)
	if err != nil {
		return
	}
	defer server.Close()

	if tcp, ok := server.(*net.TCPConn); ok {
		_ = tcp.SetNoDelay(true)
		_ = tcp.SetKeepAlive(true)
		_ = tcp.SetKeepAlivePeriod(60 * time.Second)
	}

	// Si SSH llegó junto con el payload inicial, entregarlo antes del copy normal.
	if len(pendingSSH) > 0 {
		if _, err := server.Write(pendingSSH); err != nil { return }
	}

	done := make(chan struct{}, 2)

	go func() {
		_, _ = io.Copy(server, client)
		closeWrite(server)
		done <- struct{}{}
	}()

	go func() {
		_, _ = io.Copy(client, server)
		closeWrite(client)
		done <- struct{}{}
	}()

	// Al terminar una mitad, cerrar la sesión completa de forma determinista.
	// Evita sockets viejos retenidos que contaminen la siguiente reconexión.
	<-done
}

func main() {
	listen := flag.String("listen", "0.0.0.0:80", "listen address")
	target := flag.String("target", "127.0.0.1:22", "target address")
	banner := flag.String("banner", "OK", "banner en respuesta 200")
	flag.Parse()

	ln, err := net.Listen("tcp", *listen)
	if err != nil {
		panic(err)
	}

	fmt.Println("ProxyGo ONLINE", *listen, "->", *target, "BANNER:", *banner)

	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go handle(conn, *target, *banner)
	}
}
EOF
  (cd "$PROXYGO_SRC_DIR" && go build -ldflags='-s -w' -o "$PROXYGO_BIN" main.go) || return 1
  chmod 755 "$PROXYGO_BIN"
  "$PROXYGO_BIN" -h >/dev/null 2>&1 || return 1
  sha256sum "$PROXYGO_BIN" > "$PROXYGO_DIR/.binary.sha256"
  printf 'NEW-GOLDEN exact-v4.3-ssh-compat %s\n' "$(date '+%F %T')" > "$PROXYGO_DIR/.golden-installed"
}

# =====================================================================
# V4.3 - SSH compatibility shim for ProxyGo on modern OpenSSH.
# ProxyGo itself remains byte-identical to NEW GOLDEN.  The shim sits only
# between ProxyGo and the local sshd.  It forwards the server banner unchanged
# and strips any HTTP injector residue that reaches the backend before the real
# SSH client identification (SSH-2.0-/SSH-1.99-).  After the identification,
# it becomes a transparent TCP tunnel.
# =====================================================================
cleanup_v42_shared80_bridge() {
  systemctl disable --now shared80_router.service >/dev/null 2>&1 || true
  pkill -TERM -x multi80-shared-router >/dev/null 2>&1 || true
  sleep 0.2
  pkill -KILL -x multi80-shared-router >/dev/null 2>&1 || true
  rm -f /etc/systemd/system/shared80_router.service /usr/local/bin/multi80-shared-router /etc/multi80-shared-router.json
  rm -rf /opt/multi80-shared-router
  systemctl daemon-reload >/dev/null 2>&1 || true
}

compile_proxygo_ssh_shim() {
  install_base || return 1
  mkdir -p "$PROXYGO_SSH_SHIM_DIR"
  cat > "$PROXYGO_SSH_SHIM_DIR/main.go" <<'EOF'
package main

import (
    "bytes"
    "flag"
    "io"
    "net"
    "sync"
    "time"
)

const (
    gateTimeout = 6 * time.Second
    maxPrefix   = 256 * 1024
)

func tune(c net.Conn) {
    if t, ok := c.(*net.TCPConn); ok {
        _ = t.SetNoDelay(true)
        _ = t.SetKeepAlive(true)
        _ = t.SetKeepAlivePeriod(30 * time.Second)
    }
}

func findIdent(b []byte) int {
    needles := [][]byte{[]byte("SSH-2.0-"), []byte("SSH-1.99-")}
    best := -1
    for _, n := range needles {
        from := 0
        for from < len(b) {
            i := bytes.Index(b[from:], n)
            if i < 0 { break }
            i += from
            // Accept at the beginning of the stream or after a line break.
            if i == 0 || b[i-1] == '\n' || b[i-1] == '\r' {
                if best < 0 || i < best { best = i }
                break
            }
            from = i + 1
        }
    }
    return best
}

func gateClientToServer(client, server net.Conn) error {
    _ = client.SetReadDeadline(time.Now().Add(gateTimeout))
    defer client.SetReadDeadline(time.Time{})

    buf := make([]byte, 8192)
    acc := make([]byte, 0, 8192)
    for len(acc) < maxPrefix {
        n, err := client.Read(buf)
        if n > 0 {
            acc = append(acc, buf[:n]...)
            if idx := findIdent(acc); idx >= 0 {
                if _, werr := server.Write(acc[idx:]); werr != nil { return werr }
                _ = client.SetReadDeadline(time.Time{})
                _, err = io.Copy(server, client)
                return err
            }
            // Keep only a bounded tail while looking for a split SSH marker.
            if len(acc) > 64*1024 {
                acc = append([]byte(nil), acc[len(acc)-64*1024:]...)
            }
        }
        if err != nil { return err }
    }
    return io.ErrUnexpectedEOF
}

func handle(client net.Conn, target string) {
    defer client.Close()
    tune(client)

    server, err := net.DialTimeout("tcp", target, 5*time.Second)
    if err != nil { return }
    defer server.Close()
    tune(server)

    var wg sync.WaitGroup
    wg.Add(2)

    // Server -> ProxyGo is never modified. OpenSSH banner/KEX go through raw.
    go func() {
        defer wg.Done()
        _, _ = io.Copy(client, server)
    }()

    // ProxyGo -> sshd is gated until the actual SSH client identification.
    go func() {
        defer wg.Done()
        _ = gateClientToServer(client, server)
    }()

    wg.Wait()
}

func main() {
    listen := flag.String("listen", "127.0.0.1:18022", "listen address")
    target := flag.String("target", "127.0.0.1:22", "target address")
    flag.Parse()

    ln, err := net.Listen("tcp", *listen)
    if err != nil { panic(err) }
    for {
        c, err := ln.Accept()
        if err != nil { continue }
        go handle(c, *target)
    }
}
EOF
  (cd "$PROXYGO_SSH_SHIM_DIR" && go build -ldflags='-s -w' -o "$PROXYGO_SSH_SHIM_BIN" main.go) || return 1
  chmod 755 "$PROXYGO_SSH_SHIM_BIN"
  "$PROXYGO_SSH_SHIM_BIN" -h >/dev/null 2>&1 || return 1
}

write_proxygo_ssh_shim_service() {
  load_state
  [[ -x "$PROXYGO_SSH_SHIM_BIN" ]] || compile_proxygo_ssh_shim || return 1
  cat > "$PROXYGO_SSH_SHIM_SERVICE" <<EOF
[Unit]
Description=ProxyGo SSH clean compatibility shim
After=network-online.target ssh.service
Wants=network-online.target

[Service]
Type=simple
ExecStart=${PROXYGO_SSH_SHIM_BIN} -listen 127.0.0.1:${PROXYGO_SSH_SHIM_PORT} -target 127.0.0.1:${PROXYGO_TARGET_PORT}
Restart=always
RestartSec=1
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
KillSignal=SIGTERM
TimeoutStartSec=15
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable proxygo_ssh_clean.service >/dev/null 2>&1 || true
  systemctl restart proxygo_ssh_clean.service || return 1
  systemctl is-active --quiet proxygo_ssh_clean.service || return 1
}

proxygo_write_shared80_service() {
  load_state
  cleanup_v42_shared80_bridge
  [[ -x "$PROXYGO_BIN" ]] || proxygo_compile_golden || return 1
  write_proxygo_ssh_shim_service || return 1
  cat > /etc/systemd/system/proxygo_shared80.service <<EOF
[Unit]
Description=ProxyGo NEW GOLDEN shared public 80 backend
After=network-online.target ssh.service proxygo_ssh_clean.service
Wants=network-online.target
Requires=proxygo_ssh_clean.service

[Service]
Type=simple
ExecStart=${PROXYGO_BIN} -listen 127.0.0.1:${PROXYGO_LOCAL_PORT} -target 127.0.0.1:${PROXYGO_SSH_SHIM_PORT} -banner "${PROXYGO_BANNER}"
Restart=always
RestartSec=1
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
KillSignal=SIGTERM
TimeoutStartSec=15
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable proxygo_shared80.service >/dev/null 2>&1 || true
  systemctl restart proxygo_shared80.service || return 1
  systemctl is-active --quiet proxygo_shared80.service || return 1
  write_haproxy_config >/dev/null 2>&1 || return 1
}

proxygo_write_extra_service() {
  local pub="$1" target="$2" banner="$3"
  [[ "$pub" =~ ^[0-9]+$ && "$pub" -ge 1 && "$pub" -le 65535 ]] || return 1
  [[ "$target" =~ ^[0-9]+$ && "$target" -ge 1 && "$target" -le 65535 ]] || return 1
  [[ "$pub" != '80' && "$pub" != '443' ]] || { echo '80 y 443 estan reservados para HAProxy compartido.'; return 1; }
  cat > "/etc/systemd/system/proxygo_${pub}.service" <<EOF
[Unit]
Description=ProxyGo NEW GOLDEN ${pub} to ${target}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${PROXYGO_BIN} -listen 0.0.0.0:${pub} -target 127.0.0.1:${target} -banner "${banner}"
Restart=always
RestartSec=1
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
KillSignal=SIGTERM
TimeoutStartSec=15
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now "proxygo_${pub}.service"
}

proxygo_extra_add() {
  [[ -x "$PROXYGO_BIN" ]] || { echo 'Primero instala ProxyGo.'; pause; return; }
  local target pub banner
  read -r -p 'Puerto local destino [22]: ' target; target="${target:-22}"
  ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)${target}$" || { echo 'Ese puerto local no esta escuchando.'; pause; return; }
  read -r -p 'Puerto publico ProxyGo dedicado: ' pub
  ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq "(^|:)${pub}$" && { echo 'Ese puerto ya esta en uso.'; pause; return; }
  read -r -p 'Banner [OK]: ' banner; banner="${banner:-OK}"
  if proxygo_write_extra_service "$pub" "$target" "$banner"; then echo 'Puerto ProxyGo agregado.'; else echo 'No se pudo agregar.'; fi
  pause
}

proxygo_extra_close() {
  local ports pub
  ports=$(find /etc/systemd/system -maxdepth 1 -type f -name 'proxygo_[0-9]*.service' -printf '%f\n' 2>/dev/null | sed -n 's/^proxygo_\([0-9][0-9]*\)\.service$/\1/p' | sort -n)
  [[ -n "$ports" ]] || { echo 'No hay puertos ProxyGo dedicados.'; pause; return; }
  echo "$ports" | sed 's/^/ - /'
  read -r -p 'Puerto a cerrar: ' pub
  echo "$ports" | grep -wxq "$pub" || { echo 'No pertenece a ProxyGo.'; pause; return; }
  systemctl disable --now "proxygo_${pub}.service" >/dev/null 2>&1 || true
  rm -f "/etc/systemd/system/proxygo_${pub}.service"
  systemctl daemon-reload
  echo "Puerto ${pub} cerrado."
  pause
}

proxygo_restart_all() {
  systemctl restart proxygo_ssh_clean.service >/dev/null 2>&1 || true
  local u
  for u in proxygo_shared80.service /etc/systemd/system/proxygo_[0-9]*.service; do
    [[ "$u" == /* ]] && u=$(basename "$u")
    systemctl cat "$u" >/dev/null 2>&1 || continue
    systemctl restart "$u" >/dev/null 2>&1 || true
  done
}

proxygo_uninstall() {
  read -r -p 'Escribe SI para desinstalar ProxyGo: ' ok
  [[ "$ok" == 'SI' ]] || return
  local f
  systemctl disable --now proxygo_shared80.service >/dev/null 2>&1 || true
  systemctl disable --now proxygo_ssh_clean.service >/dev/null 2>&1 || true
  for f in /etc/systemd/system/proxygo_[0-9]*.service; do
    [[ -e "$f" ]] || continue
    systemctl disable --now "$(basename "$f")" >/dev/null 2>&1 || true
  done
  rm -f /etc/systemd/system/proxygo_shared80.service /etc/systemd/system/proxygo_[0-9]*.service "$PROXYGO_SSH_SHIM_SERVICE"
  pkill -x proxygo-ssh-clean >/dev/null 2>&1 || true
  rm -f "$PROXYGO_SSH_SHIM_BIN"
  rm -rf "$PROXYGO_SSH_SHIM_DIR"
  pkill -x proxygo >/dev/null 2>&1 || true
  rm -f "$PROXYGO_BIN"
  rm -rf "$PROXYGO_SRC_DIR" "$PROXYGO_DIR"
  systemctl daemon-reload
  write_haproxy_config >/dev/null 2>&1 || true
  echo 'ProxyGo eliminado; Xray/SSL permanecen.'
  pause
}

proxygo_menu() {
  while true; do
    load_state
    safe_clear
    bar
    echo -e "${C_GOLD}              PROXYGO - NEW GOLDEN (GOLDEN EXACT + SSH COMPAT)${C_RESET}"
    bar
    if [[ -x "$PROXYGO_BIN" ]]; then echo -e " CORE        : ${C_GREEN}INSTALADO${C_RESET}"; else echo -e " CORE        : ${C_RED}NO INSTALADO${C_RESET}"; fi
    printf ' SHARED 80   : '; onoff proxygo_shared80.service
    echo " BACKEND     : 127.0.0.1:${PROXYGO_TARGET_PORT} via compat :${PROXYGO_SSH_SHIM_PORT}"
    echo " BANNER      : ${PROXYGO_BANNER}"
    echo ' PUBLICO 80  : HAProxy -> ProxyGo local 18080 (default)'
    bar
    echo '[1] INSTALAR / REPARAR PROXYGO GOLDEN'
    echo '[2] ACTIVAR / REPARAR PROXYGO EN 80 COMPARTIDO'
    echo '[3] CAMBIAR BACKEND LOCAL DEL PROXYGO 80'
    echo '[4] CAMBIAR BANNER DEL PROXYGO 80'
    echo '[5] AGREGAR PUERTO PROXYGO DEDICADO'
    echo '[6] CERRAR PUERTO PROXYGO DEDICADO'
    echo '[7] REINICIAR PROXYGO'
    echo '[8] DESINSTALAR PROXYGO'
    echo '[0] VOLVER'
    bar
    read -r -p 'Seleccione: ' op
    case "$op" in
      1) proxygo_compile_golden && proxygo_write_shared80_service; pause ;;
      2) proxygo_write_shared80_service; pause ;;
      3) read -r -p "Puerto local destino [${PROXYGO_TARGET_PORT}]: " p; [[ -n "$p" ]] && PROXYGO_TARGET_PORT="$p"; save_state; proxygo_write_shared80_service; pause ;;
      4) read -r -p "Banner [${PROXYGO_BANNER}]: " b; [[ -n "$b" ]] && PROXYGO_BANNER="$b"; save_state; proxygo_write_shared80_service; pause ;;
      5) proxygo_extra_add ;;
      6) proxygo_extra_close ;;
      7) proxygo_restart_all; echo 'ProxyGo reiniciado.'; pause ;;
      8) proxygo_uninstall ;;
      0) return ;;
      *) echo 'Opcion invalida.'; sleep 1 ;;
    esac
  done
}

status_general() {
  load_state
  safe_clear
  bar
  echo -e "${C_GOLD}     ESTADO SSL + XRAY + PROXYGO 80/443 - INDEPENDIENTE${C_RESET}"
  bar
  printf 'HAProxy      : '; onoff haproxy
  printf 'OpenSSH      : '; if service_is_active ssh || service_is_active sshd; then echo -e "${C_GREEN}ON${C_RESET}"; else echo -e "${C_RED}OFF${C_RESET}"; fi
  printf 'Xray         : '; onoff xray
  printf 'ProxyGo 80   : '; onoff proxygo_shared80.service
  echo "Xray 443     : $(profile_name)"
  echo "Xray 80      : $(xray80_profile_name)"
  echo "Certificado  : $CERT_MODE"
  echo "Dominio      : ${DOMAIN:-SIN DOMINIO}"
  echo "IP publica   : $(public_ip)"
  echo 'Publicos     : TCP/443 SSL+Xray | TCP/80 ProxyGo+Xray HTTP-like'
  echo "Locales      : SSH:22 XR443:${XRAY_PORT} XR80:${XRAY80_PORT} PG80:${PROXYGO_LOCAL_PORT}"
  echo "Usuarios XR  : $(jq 'length' "$USERS_FILE" 2>/dev/null || echo 0)"
  bar
  ss -lntp 2>/dev/null | grep -E '(:22|:80|:443|:10000|:10080|:18080)([[:space:]]|$)' || echo 'No se detectaron los puertos esperados.'
  bar
  pause
}

diagnostics() {
  load_state
  safe_clear
  bar
  echo -e "${C_GOLD}                    DIAGNOSTICO${C_RESET}"
  bar
  echo '[HAProxy config]'
  if command -v haproxy >/dev/null 2>&1 && [[ -f "$HA_CFG" ]]; then
    haproxy -c -f "$HA_CFG" || true
  else
    echo 'HAProxy no instalado/configurado.'
  fi
  echo
  echo '[Xray config]'
  if [[ -x "$XRAY_BIN" && -f "$XRAY_CONFIG" ]]; then
    "$XRAY_BIN" run -test -config "$XRAY_CONFIG" 2>&1 || "$XRAY_BIN" -test -config "$XRAY_CONFIG" 2>&1 || true
  else
    echo 'Xray no instalado/configurado.'
  fi
  echo
  echo '[Servicios]'
  systemctl --no-pager --full status haproxy xray ssh proxygo_shared80 2>/dev/null | sed -n '1,100p' || true
  echo
  echo '[Ultimos logs HAProxy/Xray]'
  journalctl -u haproxy -u xray -u proxygo_shared80 -n 50 --no-pager 2>/dev/null || true
  pause
}

restart_services() {
  systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || true
  systemctl restart xray 2>/dev/null || true
  proxygo_restart_all
  systemctl restart haproxy 2>/dev/null || true
  echo -e "${C_GREEN}Servicios reiniciados.${C_RESET}"
  pause
}

renew_certificate() {
  load_state
  if [[ "$CERT_MODE" != 'letsencrypt' || -z "$DOMAIN" ]]; then
    echo 'No hay certificado Lets Encrypt activo. Usa CONFIGURAR CERTIFICADO.'
    pause
    return 0
  fi
  certbot renew --force-renewal || true
  if [[ -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" ]]; then
    cat "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" "/etc/letsencrypt/live/${DOMAIN}/privkey.pem" > "$HA_CERT"
    chmod 600 "$HA_CERT"
    systemctl reload haproxy || true
  fi
  pause
}

detect_auto_tune_values() {
  local mem_kb cpu mem_tier cpu_tier tier
  cpu=$(nproc 2>/dev/null || true)
  [[ "$cpu" =~ ^[0-9]+$ && "$cpu" -ge 1 ]] || cpu=$(grep -c '^processor' /proc/cpuinfo 2>/dev/null || echo 1)
  [[ "$cpu" =~ ^[0-9]+$ && "$cpu" -ge 1 ]] || cpu=1
  mem_kb=$(awk '/^MemTotal:/ {print $2; exit}' /proc/meminfo 2>/dev/null)
  [[ "$mem_kb" =~ ^[0-9]+$ ]] || mem_kb=524288
  AUTO_CPU="$cpu"
  AUTO_MEM_MB=$((mem_kb / 1024))
  (( AUTO_MEM_MB > 0 )) || AUTO_MEM_MB=512

  # El tier efectivo usa el recurso mas limitado (CPU o RAM), para no
  # sobreconfigurar una VPS con mucha RAM pero pocos vCPU, o al reves.
  if (( AUTO_MEM_MB < 1536 )); then mem_tier=1
  elif (( AUTO_MEM_MB < 4096 )); then mem_tier=2
  elif (( AUTO_MEM_MB < 8192 )); then mem_tier=3
  elif (( AUTO_MEM_MB < 16384 )); then mem_tier=4
  else mem_tier=5
  fi

  if (( AUTO_CPU <= 1 )); then cpu_tier=1
  elif (( AUTO_CPU <= 2 )); then cpu_tier=2
  elif (( AUTO_CPU <= 4 )); then cpu_tier=3
  elif (( AUTO_CPU <= 8 )); then cpu_tier=4
  else cpu_tier=5
  fi
  (( mem_tier < cpu_tier )) && tier=$mem_tier || tier=$cpu_tier

  case "$tier" in
    1)
      AUTO_PROFILE='MICRO'
      HAPROXY_MAXCONN=4096
      AUTO_SOMAXCONN=8192
      AUTO_BACKLOG=16384
      AUTO_TCPBUF=8388608
      AUTO_FILEMAX=524288
      AUTO_NOFILE=262144
      AUTO_CONNTRACK=131072
      AUTO_SWAPPINESS=15
      ;;
    2)
      AUTO_PROFILE='SMALL'
      HAPROXY_MAXCONN=8192
      AUTO_SOMAXCONN=16384
      AUTO_BACKLOG=32768
      AUTO_TCPBUF=16777216
      AUTO_FILEMAX=1048576
      AUTO_NOFILE=1048576
      AUTO_CONNTRACK=262144
      AUTO_SWAPPINESS=10
      ;;
    3)
      AUTO_PROFILE='MEDIUM'
      HAPROXY_MAXCONN=16384
      AUTO_SOMAXCONN=32768
      AUTO_BACKLOG=65536
      AUTO_TCPBUF=33554432
      AUTO_FILEMAX=2097152
      AUTO_NOFILE=1048576
      AUTO_CONNTRACK=524288
      AUTO_SWAPPINESS=5
      ;;
    4)
      AUTO_PROFILE='LARGE'
      HAPROXY_MAXCONN=32768
      AUTO_SOMAXCONN=65535
      AUTO_BACKLOG=131072
      AUTO_TCPBUF=67108864
      AUTO_FILEMAX=4194304
      AUTO_NOFILE=1048576
      AUTO_CONNTRACK=1048576
      AUTO_SWAPPINESS=5
      ;;
    *)
      AUTO_PROFILE='XLARGE'
      HAPROXY_MAXCONN=65535
      AUTO_SOMAXCONN=65535
      AUTO_BACKLOG=262144
      AUTO_TCPBUF=67108864
      AUTO_FILEMAX=8388608
      AUTO_NOFILE=1048576
      AUTO_CONNTRACK=2097152
      AUTO_SWAPPINESS=1
      ;;
  esac
}

auto_tune_signature() {
  detect_auto_tune_values
  printf '%s|cpu=%s|mem=%s|kernel=%s|hp=%s|backlog=%s|buf=%s' \
    "$AUTO_PROFILE" "$AUTO_CPU" "$AUTO_MEM_MB" "$(uname -r 2>/dev/null || echo unknown)" \
    "$HAPROXY_MAXCONN" "$AUTO_BACKLOG" "$AUTO_TCPBUF"
}

optimize_auto_vps() {
  local quiet=0 no_pause=0 signature available_cc bbr_enabled=0 f
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --quiet) quiet=1 ;;
      --no-pause) no_pause=1 ;;
    esac
    shift
  done

  detect_auto_tune_values
  signature=$(auto_tune_signature)

  cat > "$AUTO_TUNE_SYSCTL" <<EOF
# AUTO-TUNE V3.8 - generado segun recursos reales de la VPS.
# Perfil: ${AUTO_PROFILE} | CPU: ${AUTO_CPU} | RAM: ${AUTO_MEM_MB} MiB
# Los buffers TCP son MAXIMOS dinamicos; no se reservan completos por conexion.
fs.file-max = ${AUTO_FILEMAX}
fs.nr_open = ${AUTO_NOFILE}
net.core.somaxconn = ${AUTO_SOMAXCONN}
net.core.netdev_max_backlog = ${AUTO_BACKLOG}
net.core.rmem_max = ${AUTO_TCPBUF}
net.core.wmem_max = ${AUTO_TCPBUF}
net.ipv4.tcp_max_syn_backlog = ${AUTO_SOMAXCONN}
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fin_timeout = 15
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 15
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_syncookies = 1
net.ipv4.tcp_rmem = 4096 262144 ${AUTO_TCPBUF}
net.ipv4.tcp_wmem = 4096 262144 ${AUTO_TCPBUF}
vm.swappiness = ${AUTO_SWAPPINESS}
EOF

  # FQ reduce colas entre flujos. BBR se activa solo cuando el kernel realmente
  # lo ofrece; si no, se conserva el congestion-control del sistema y solo FQ.
  modprobe tcp_bbr >/dev/null 2>&1 || true
  available_cc=$(sysctl -n net.ipv4.tcp_available_congestion_control 2>/dev/null || true)
  if grep -qw bbr <<<"$available_cc"; then
    cat >> "$AUTO_TUNE_SYSCTL" <<'EOF'
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF
    bbr_enabled=1
  else
    cat >> "$AUTO_TUNE_SYSCTL" <<'EOF'
net.core.default_qdisc = fq
EOF
  fi

  # Conntrack solo si el kernel expone ese parametro. Ayuda en hosts con muchas
  # conexiones concurrentes sin asumir que todos los VPS cargan netfilter igual.
  if sysctl -a 2>/dev/null | grep -q '^net.netfilter.nf_conntrack_max '; then
    printf 'net.netfilter.nf_conntrack_max = %s\n' "$AUTO_CONNTRACK" >> "$AUTO_TUNE_SYSCTL"
  fi

  sysctl --system >/dev/null 2>&1 || true

  mkdir -p /etc/systemd/system/haproxy.service.d /etc/systemd/system/xray.service.d
  cat > /etc/systemd/system/haproxy.service.d/99-shared-manager.conf <<EOF
[Unit]
After=network-online.target
Wants=network-online.target
[Service]
Restart=always
RestartSec=1
LimitNOFILE=${AUTO_NOFILE}
LimitNPROC=infinity
TasksMax=infinity
EOF
  cat > /etc/systemd/system/xray.service.d/99-shared-manager.conf <<EOF
[Unit]
After=network-online.target
Wants=network-online.target
[Service]
Restart=always
RestartSec=1
LimitNOFILE=${AUTO_NOFILE}
LimitNPROC=infinity
TasksMax=infinity
EOF

  # Aplicar los mismos limites a ProxyGo ya instalado sin cambiar su motor.
  for f in /etc/systemd/system/proxygo_shared80.service /etc/systemd/system/proxygo_[0-9]*.service; do
    [[ -e "$f" ]] || continue
    mkdir -p "/etc/systemd/system/$(basename "$f").d"
    cat > "/etc/systemd/system/$(basename "$f").d/99-auto-tune.conf" <<EOF
[Service]
LimitNOFILE=${AUTO_NOFILE}
LimitNPROC=infinity
TasksMax=infinity
EOF
  done

  systemctl daemon-reload >/dev/null 2>&1 || true

  # Si HAProxy ya estaba instalado desde una version anterior, ajustar SOLO su
  # limite global maxconn al perfil detectado y recargar sin tocar las ACL/rutas.
  if [[ -s "$HA_CFG" ]] && command -v haproxy >/dev/null 2>&1; then
    local ha_tmp
    ha_tmp=$(mktemp)
    cp -a "$HA_CFG" "$ha_tmp" 2>/dev/null || true
    sed -i "0,/^[[:space:]]*maxconn[[:space:]][0-9][0-9]*/s//    maxconn ${HAPROXY_MAXCONN}/" "$HA_CFG" 2>/dev/null || true
    if haproxy -c -f "$HA_CFG" >/dev/null 2>&1; then
      systemctl reload haproxy >/dev/null 2>&1 || true
    elif [[ -s "$ha_tmp" ]]; then
      cp -a "$ha_tmp" "$HA_CFG" >/dev/null 2>&1 || true
    fi
    rm -f "$ha_tmp"
  fi

  printf '%s\n' "$signature" > "$AUTO_TUNE_STAMP"
  chmod 600 "$AUTO_TUNE_STAMP" 2>/dev/null || true

  if (( quiet == 0 )); then
    echo -e "${C_GREEN}AUTO-TUNE aplicado segun el hardware real de esta VPS.${C_RESET}"
    echo "Perfil       : $AUTO_PROFILE"
    echo "CPU / RAM    : ${AUTO_CPU} vCPU / ${AUTO_MEM_MB} MiB"
    echo "HAProxy max  : ${HAPROXY_MAXCONN} conexiones concurrentes (limite de configuracion)"
    echo "Backlog      : ${AUTO_BACKLOG}"
    echo "TCP buf max  : $((AUTO_TCPBUF / 1024 / 1024)) MiB dinamicos"
    echo "NOFILE       : ${AUTO_NOFILE} por servicio"
    if (( bbr_enabled == 1 )); then echo 'Colas/CC     : FQ + BBR'; else echo 'Colas/CC     : FQ + congestion-control del kernel'; fi
    echo 'Objetivo     : alta concurrencia + baja latencia bajo carga, sin reservar RAM fija.'
    echo 'Nota         : el ping base depende de distancia/ruta/ISP; ningun sysctl puede reducir esa latencia fisica.'
  fi
  (( no_pause == 1 )) || pause
}

auto_optimize_if_needed() {
  local current previous
  current=$(auto_tune_signature)
  previous=$(cat "$AUTO_TUNE_STAMP" 2>/dev/null || true)
  if [[ "$current" != "$previous" || ! -s "$AUTO_TUNE_SYSCTL" ]]; then
    optimize_auto_vps --quiet --no-pause >/dev/null 2>&1 || true
  fi
}

enable_boot_fast() {
  systemctl enable ssh >/dev/null 2>&1 || systemctl enable sshd >/dev/null 2>&1 || true
  systemctl enable haproxy >/dev/null 2>&1 || true
  [[ -f /etc/systemd/system/xray.service || -f /lib/systemd/system/xray.service ]] && systemctl enable xray >/dev/null 2>&1 || true
  [[ -f /etc/systemd/system/proxygo_shared80.service ]] && systemctl enable proxygo_shared80 >/dev/null 2>&1 || true
  local f
  for f in /etc/systemd/system/proxygo_[0-9]*.service; do [[ -e "$f" ]] && systemctl enable "$(basename "$f")" >/dev/null 2>&1 || true; done
  systemctl daemon-reload
  systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || true
  [[ -f /etc/systemd/system/xray.service || -f /lib/systemd/system/xray.service ]] && systemctl restart xray >/dev/null 2>&1 || true
  [[ -f /etc/systemd/system/proxygo_shared80.service ]] && systemctl restart proxygo_shared80 >/dev/null 2>&1 || true
  systemctl restart haproxy >/dev/null 2>&1 || true
}

boot_test() {
  enable_boot_fast
  safe_clear
  bar
  echo -e "${C_GOLD}             AUTO-BOOT / PUERTOS DESPUES DE REINICIO${C_RESET}"
  bar
  systemctl is-enabled haproxy 2>/dev/null || true
  systemctl is-enabled xray 2>/dev/null || true
  systemctl is-enabled proxygo_shared80 2>/dev/null || true
  echo
  ss -lntp 2>/dev/null | grep -E '(:80|:443|:10000|:10080|:18080)([[:space:]]|$)' || true
  bar
  echo 'Los servicios usan systemd enable + Restart=always/RestartSec=1.'
  pause
}

write_info_file() {
  load_state
  ensure_dirs
  local host
  host=$(host_for_clients)
  {
    echo 'SSL + V2RAY/XRAY + PROXYGO 80/443 MANAGER'
    echo '==========================================='
    echo "Host/IP      : $host"
    echo 'Puertos publicos: 443 TCP (SSL+Xray) / 80 TCP (ProxyGo+Xray HTTP-like)'
    echo "Certificado  : $CERT_MODE"
    echo "Dominio/SNI  : ${DOMAIN:-SIN DOMINIO}"
    echo
    echo 'SSL DIRECTO / SSH'
    echo '-----------------'
    echo "Servidor : $host"
    echo 'Puerto   : 443'
    echo 'Backend  : OpenSSH local :22'
    echo
    echo 'PROXYGO NEW GOLDEN'
    echo '------------------'
    echo 'Publico  : 80 (a traves de HAProxy)'
    echo "Local    : 127.0.0.1:${PROXYGO_LOCAL_PORT}"
    echo "Destino  : 127.0.0.1:${PROXYGO_TARGET_PORT}"
    echo "Banner   : ${PROXYGO_BANNER}"
    echo
    echo 'V2RAY/XRAY'
    echo '-----------'
    echo "Perfil 443: $(profile_name)"
    echo "Path 443  : $XRAY_PATH"
    echo "Perfil 80 : $(xray80_profile_name)"
    echo "Path 80   : $XRAY80_PATH"
    echo
    echo 'Usuarios V2Ray:'
    jq -r '.[] | "- " + .name + " PORT=" + (((.port // 443)|tonumber)|tostring) + " UUID=" + .uuid + " PASS=" + .password + " PATH=" + (.path // "")' "$USERS_FILE" 2>/dev/null || true
  } > "$INFO_FILE"
  chmod 600 "$INFO_FILE"
}

install_everything() {
  load_state
  install_base || { pause; return 0; }
  if [[ ! -s "$HA_CERT" ]]; then configure_certificate || { pause; return 0; }; fi
  install_xray_core || { pause; return 0; }
  if [[ $(jq 'length' "$USERS_FILE" 2>/dev/null || echo 0) -eq 0 ]]; then
    local uuid pass
    uuid=$(generate_uuid_value)
    pass=$(openssl rand -hex 16)
    jq -n --arg u "$uuid" --arg p "$pass" '[{name:"cliente1",uuid:$u,password:$p,port:443,host:"",path:"",created:""}]' > "$USERS_FILE"
    chmod 600 "$USERS_FILE"
  fi
  proxygo_compile_golden || { pause; return 0; }
  proxygo_write_shared80_service || { pause; return 0; }
  build_xray_config || { pause; return 0; }
  write_haproxy_config || { pause; return 0; }
  optimize_auto_vps --quiet --no-pause >/dev/null 2>&1 || true
  enable_boot_fast
  write_info_file
  echo -e "${C_GREEN}INSTALACION BASE COMPLETA: 443 + 80 COMPARTIDOS.${C_RESET}"
  echo '443: SSL directo + Xray | 80: ProxyGo NEW GOLDEN + Xray HTTP-like opcional'
  pause
}

uninstall_xray_only() {
  read -r -p 'Escribe SI para desinstalar SOLO Xray: ' ok
  [[ "$ok" == 'SI' ]] || return 0

  # Parar primero cualquier instancia conocida y cualquier proceso residual Xray.
  systemctl disable --now xray.service 2>/dev/null || true
  systemctl disable --now xray 2>/dev/null || true
  pkill -TERM -x xray 2>/dev/null || true
  sleep 1
  pkill -KILL -x xray 2>/dev/null || true

  # El instalador oficial puede no existir en /tmp despues de reiniciar; descargarlo si hace falta.
  if [[ ! -s /tmp/xray-install-release.sh ]]; then
    curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh -o /tmp/xray-install-release.sh || true
  fi
  if [[ -s /tmp/xray-install-release.sh ]]; then
    bash /tmp/xray-install-release.sh remove --purge || true
  fi

  rm -f "$XRAY_CONFIG"
  rm -f /etc/systemd/system/xray.service /etc/systemd/system/xray@.service
  rm -rf /etc/systemd/system/xray.service.d
  systemctl daemon-reload
  systemctl reset-failed xray.service 2>/dev/null || true

  echo
  if ss -lntp 2>/dev/null | grep -Eq ':(10000|10080)([[:space:]]|$)'; then
    echo -e "${C_RED}ATENCION: aun existe un listener en 10000/10080:${C_RESET}"
    ss -lntp 2>/dev/null | grep -E ':(10000|10080)([[:space:]]|$)' || true
  else
    echo -e "${C_GREEN}Xray eliminado y puertos locales 10000/10080 cerrados.${C_RESET}"
  fi
  echo 'HAProxy SSL/SSH y ProxyGo quedan intactos.'
  pause
}

cleanup_proxygo_for_full_uninstall() {
  # No llamar proxygo_uninstall() aqui porque esa funcion vuelve a escribir/reiniciar HAProxy.
  systemctl disable --now proxygo_shared80.service 2>/dev/null || true
  systemctl disable --now proxygo_ssh_clean.service 2>/dev/null || true
  local f unit
  for f in /etc/systemd/system/proxygo_[0-9]*.service; do
    [[ -e "$f" ]] || continue
    unit=$(basename "$f")
    systemctl disable --now "$unit" 2>/dev/null || true
  done
  pkill -TERM -x proxygo 2>/dev/null || true
  sleep 1
  pkill -KILL -x proxygo 2>/dev/null || true
  rm -f /etc/systemd/system/proxygo_shared80.service /etc/systemd/system/proxygo_[0-9]*.service "$PROXYGO_SSH_SHIM_SERVICE"
  pkill -TERM -x proxygo-ssh-clean 2>/dev/null || true
  rm -f "$PROXYGO_SSH_SHIM_BIN"
  rm -rf "$PROXYGO_SSH_SHIM_DIR"
  rm -f "$PROXYGO_BIN"
  rm -rf "$PROXYGO_SRC_DIR" "$PROXYGO_DIR"
}

show_remaining_manager_listeners() {
  local left
  left=$(ss -lntp 2>/dev/null | grep -E ':(80|443|10000|10080|18080|18022)([[:space:]]|$)' || true)
  if [[ -n "$left" ]]; then
    echo -e "${C_RED}Quedan listeners en puertos usados por el manager:${C_RESET}"
    printf '%s\n' "$left"
    echo 'Si aparece un proceso distinto de haproxy/xray/proxygo, pertenece a otro servicio de la VPS.'
    return 1
  fi
  echo -e "${C_GREEN}PASS: 80/443/10000/10080/18080/18022 sin listeners del manager.${C_RESET}"
  return 0
}

uninstall_all() {
  read -r -p 'PELIGRO: escribe BORRAR para quitar HAProxy/Xray/ProxyGo y este manager: ' ok
  [[ "$ok" == 'BORRAR' ]] || return 0

  echo 'Deteniendo servicios del manager...'
  # Quitar autoarranque ANTES de matar procesos para que systemd no los levante otra vez.
  systemctl disable --now haproxy.service 2>/dev/null || true
  systemctl disable --now haproxy 2>/dev/null || true
  systemctl disable --now xray.service 2>/dev/null || true
  systemctl disable --now xray 2>/dev/null || true
  cleanup_proxygo_for_full_uninstall

  pkill -TERM -x xray 2>/dev/null || true
  pkill -TERM -x haproxy 2>/dev/null || true
  sleep 1
  pkill -KILL -x xray 2>/dev/null || true
  pkill -KILL -x haproxy 2>/dev/null || true

  # Desinstalar Xray aunque /tmp se haya limpiado tras un reboot.
  if [[ ! -s /tmp/xray-install-release.sh ]]; then
    curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh -o /tmp/xray-install-release.sh || true
  fi
  if [[ -s /tmp/xray-install-release.sh ]]; then
    bash /tmp/xray-install-release.sh remove --purge || true
  fi

  # Restaurar HAProxy previo solo como archivo, pero dejar el servicio DETENIDO/DESHABILITADO.
  local hbak
  hbak=$(find "$BACKUP_DIR" -maxdepth 1 -name 'haproxy.cfg-*.bak' 2>/dev/null | sort | head -n1)
  if [[ -n "$hbak" ]]; then
    cp -a "$hbak" "$HA_CFG"
  else
    rm -f "$HA_CFG"
  fi

  rm -f "$XRAY_CONFIG"
  rm -f /etc/systemd/system/xray.service /etc/systemd/system/xray@.service
  rm -rf /etc/systemd/system/haproxy.service.d /etc/systemd/system/xray.service.d
  rm -f /etc/sysctl.d/99-ssl-v2ray443-manager.conf /etc/sysctl.d/99-ssl-xray-proxygo-manager.conf
  rm -f /etc/letsencrypt/renewal-hooks/deploy/ssl-v2ray443-haproxy.sh
  rm -f "$INFO_FILE" "$HA_CERT"

  # El estado y usuarios del manager tambien se eliminan en DESINSTALAR TODO.
  rm -rf "$BASE_DIR"

  systemctl daemon-reload
  systemctl reset-failed haproxy.service xray.service proxygo_shared80.service 2>/dev/null || true

  # Ultimo barrido solo de procesos propios por si quedaron hijos fuera de systemd.
  pkill -KILL -x xray 2>/dev/null || true
  pkill -KILL -x proxygo 2>/dev/null || true
  pkill -KILL -x haproxy 2>/dev/null || true
  sleep 1

  echo
  bar
  echo -e "${C_GOLD}             RESULTADO DESINSTALACION COMPLETA${C_RESET}"
  bar
  printf 'HAProxy : '; service_is_active haproxy && echo -e "${C_RED}ACTIVO${C_RESET}" || echo -e "${C_GREEN}INACTIVO${C_RESET}"
  printf 'Xray    : '; service_is_active xray && echo -e "${C_RED}ACTIVO${C_RESET}" || echo -e "${C_GREEN}INACTIVO${C_RESET}"
  printf 'ProxyGo : '; service_is_active proxygo_shared80 && echo -e "${C_RED}ACTIVO${C_RESET}" || echo -e "${C_GREEN}INACTIVO${C_RESET}"
  show_remaining_manager_listeners || true
  bar
  echo 'Los usuarios Linux/SSH NO fueron borrados. SSH :22 queda intacto.'
  echo 'El script multi_80_443.sh se conserva para que puedas reinstalarlo si quieres.'
  echo
  read -r -p 'ENTER para salir del manager...' _
  exit 0
}

main_menu() {
  while true; do
    load_state
    safe_clear
    bar
    echo -e "${C_GOLD} SSL + V2RAY/XRAY + PROXYGO [ 80/443 SHARED MANAGER V4.5 ]${C_RESET}"
    bar
    printf ' HAPROXY     : '; if service_is_active haproxy; then echo -e "${C_GREEN}ACTIVO${C_RESET}"; else echo -e "${C_RED}INACTIVO${C_RESET}"; fi
    printf ' XRAY        : '; if service_is_active xray; then echo -e "${C_GREEN}ACTIVO${C_RESET}"; else echo -e "${C_RED}INACTIVO${C_RESET}"; fi
    printf ' PROXYGO 80  : '; if service_is_active proxygo_shared80; then echo -e "${C_GREEN}ACTIVO${C_RESET}"; else echo -e "${C_RED}INACTIVO${C_RESET}"; fi
    echo " XRAY 443    : $(profile_name)"
    echo " XRAY 80     : $(xray80_profile_name)"
    echo ' PUBLICOS    : TCP 443 + TCP 80 COMPARTIDOS'
    bar
    echo '[1]  INSTALAR / PREPARAR TODO'
    echo '[2]  HAPROXY SSL DIRECTO + SHARING 443/80'
    echo '[3]  CONFIGURAR / RENOVAR CERTIFICADO TLS'
    echo '[4]  PROXYGO NEW GOLDEN (IGUAL MOTOR GOLDEN MX)'
    echo '[5]  INSTALAR / ACTUALIZAR XRAY-CORE'
    echo '[6]  ELEGIR V2RAY/XRAY PARA PUERTO 443'
    echo '[7]  ELEGIR V2RAY/XRAY PARA PUERTO 80 COMPARTIDO'
    echo '[8]  CREAR USUARIO V2RAY'
    echo '[9]  ELIMINAR USUARIO V2RAY'
    echo '[10] MOSTRAR USUARIOS + LINKS V2RAY 80/443'
    echo '[11] USUARIOS SSH PARA SSL DIRECTO'
    echo '[12] ESTADO GENERAL / PUERTOS'
    echo '[13] DIAGNOSTICO'
    echo '[14] REINICIAR SERVICIOS'
    echo '[15] REAPLICAR AUTO-OPTIMIZACION SEGUN HARDWARE'
    echo '[16] AUTO-BOOT / LEVANTAR PUERTOS AL REINICIAR'
    echo '[17] DESINSTALAR SOLO XRAY'
    echo '[18] DESINSTALAR TODO EL MANAGER'
    echo '[0]  SALIR'
    bar
    read -r -p 'Seleccione una Opcion: ' op
    case "$op" in
      1) install_everything ;;
      2) install_haproxy_ssl; write_haproxy_config; pause ;;
      3) configure_certificate; pause ;;
      4) proxygo_menu ;;
      5) install_xray_core; build_xray_config >/dev/null 2>&1 || true; enable_boot_fast; pause ;;
      6) choose_xray_profile ;;
      7) choose_xray80_profile ;;
      8) create_xray_user ;;
      9) delete_xray_user ;;
      10) show_xray_users ;;
      11) ssh_users_menu ;;
      12) status_general ;;
      13) diagnostics ;;
      14) restart_services ;;
      15) optimize_auto_vps ;;
      16) boot_test ;;
      17) uninstall_xray_only ;;
      18) uninstall_all ;;
      0) safe_clear; exit 0 ;;
      *) echo 'Opcion invalida.'; sleep 1 ;;
    esac
  done
}

require_root
ensure_dirs
load_state
auto_optimize_if_needed
main_menu
