#!/usr/bin/env bash
# SSH PAYLOAD BRIDGE — administrador para NEW-GOLDEN ADM PRO.
# Motor PAYLOAD_FLEX PRE_TEST, aislado por puerto; conserva usuarios y protocolos.
# Sin descargas, sin dependencias externas y sin modificar OpenSSH ni otros protocolos.
set -u
umask 022
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

CONFIG_DIR=/etc/golden-ssh-payload
ENGINE=/etc/ger-frm/ssh-payload-core.sh
[[ -f "$ENGINE" ]] || ENGINE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)/ssh-payload-core.sh"
[[ -r "$ENGINE" ]] || { echo '[ERROR] Falta el motor ssh-payload-core.sh'; exit 1; }
[[ $EUID -eq 0 ]] || { echo '[ERROR] Ejecuta como root.'; exit 1; }

W=$'\033[1;37m'; Y=$'\033[0;33m'; R=$'\033[1;31m'; G=$'\033[1;32m'; D=$'\033[0;36m'; N=$'\033[0m'
bar(){ printf '%s=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=%s\n' "$Y" "$N"; }
valid_port(){ [[ "$1" =~ ^[0-9]{1,5}$ ]] && (( 10#$1 >= 1 && 10#$1 <= 65535 )); }
ask_port(){
    local label="$1" def="${2:-}" value
    while :; do
        read -r -p "$label${def:+ [$def]}: " value || return 1
        value=${value:-$def}
        if valid_port "$value"; then
            REPLY=$((10#$value))
            return 0
        fi
        echo -e "${R}Puerto invalido: debe ser un numero entre 1 y 65535.${N}"
    done
}
port_owned(){
    local p="$1"
    [[ -f "$CONFIG_DIR/port-${p}.json" && -f "/opt/golden-ssh-payload/port-${p}/.installed-by-golden-ssh-payload" && -f "/etc/systemd/system/golden-ssh-payload-${p}.service" ]]
}
ports(){
    local f p
    for f in "$CONFIG_DIR"/port-*.json; do
        [[ -f "$f" && ! -L "$f" ]] || continue
        p="${f##*/}"; p="${p#port-}"; p="${p%.json}"
        valid_port "$p" || continue
        port_owned "$p" && printf '%s\n' "$p"
    done | sort -n -u
}
count_ports(){ local a; a="$(ports)"; [[ -n "$a" ]] && printf '%s\n' "$a" | wc -l || printf '0\n'; }
service_name(){ printf 'golden-ssh-payload-%s.service' "$1"; }
state(){
    local p="$1"
    if run_core --puerto "$p" --activo >/dev/null 2>&1; then
        printf '%sON%s' "$G" "$N"
    else
        printf '%sOFF%s' "$R" "$N"
    fi
}
show_status(){
    local p total
    total="$(count_ports)"
    if [[ "$total" -eq 0 ]]; then
        printf '%s[DESINSTALADO]%s SSH PAYLOAD BRIDGE no instalado\n' "$R" "$N"
        printf '%s[OFFLINE]%s No hay puertos SSH PAYLOAD activos\n' "$R" "$N"
    else
        printf '%s[INSTALADO]%s Puertos configurados: %s\n' "$G" "$N" "$total"
        while IFS= read -r p; do
            [[ -n "$p" ]] || continue
            printf '  TCP %-5s [%b]\n' "$p" "$(state "$p")"
        done < <(ports)
    fi
    printf '%sCompatibilidad:%s payload TCP flexible; puertos libres 1..65535.\n' "$D" "$N"
    printf '%sAviso:%s SSH local ve el origen 127.0.0.1; revisar limites por IP.\n' "$D" "$N"
}
pause(){ local x; read -r -p 'Presiona ENTER para continuar...' x || true; }
run_core(){ bash "$ENGINE" "$@"; }

install_port(){
    local p="${1:-}" ssh
    if [[ -z "$p" ]]; then
        ask_port 'Puerto publico TCP libre (1-65535; puedes cambiar 80)' '80' || return 1
        p="$REPLY"
    fi
    if port_owned "$p"; then
        echo -e "${Y}[AVISO]${N} Ya tienes el puerto $p configurado. Usa ABRIR PUERTO o REINICIAR."
        return 1
    fi
    ask_port 'Puerto del SSH local existente' '22' || return 1
    ssh="$REPLY"
    if [[ "$p" == "$ssh" ]]; then
        echo -e "${R}El puerto publico y el SSH local deben ser diferentes.${N}"
        return 1
    fi
    echo -e "${Y}Instalando solo el puerto TCP $p -> SSH local 127.0.0.1:$ssh...${N}"
    run_core --puerto "$p" --ssh "$ssh" || return 1
    echo -e "${G}Puerto TCP $p instalado, habilitado para iniciar con la VPS.${N}"
}
choose_existing(){
    local p list
    list="$(ports)"
    if [[ -z "$list" ]]; then
        echo -e "${R}No hay puertos instalados.${N}"
        return 1
    fi
    echo "Puertos disponibles: $(printf '%s ' $list)"
    ask_port 'Elige el puerto TCP' || return 1
    p="$REPLY"
    port_owned "$p" || { echo -e "${R}Este puerto no pertenece a SSH PAYLOAD BRIDGE.${N}"; return 1; }
    REPLY="$p"
}
open_port(){
    local p
    echo "Puertos configurados: $(ports | tr '\n' ' ')"
    ask_port 'Puerto TCP a abrir o agregar (1-65535)' || return 1; p="$REPLY"
    if ! port_owned "$p"; then
        install_port "$p"
        return $?
    fi
    if run_core --puerto "$p" --activo >/dev/null 2>&1; then
        echo -e "${G}El puerto $p ya esta activo.${N}"; return 0
    fi
    if run_core --puerto "$p" --abrir; then
        echo -e "${G}Puerto $p activo.${N}"
    else
        echo -e "${R}No se pudo abrir: revisa si otro servicio ocupa ese puerto. No se detuvo ninguno.${N}"
        return 1
    fi
}
close_port(){
    local p
    choose_existing || return 1; p="$REPLY"
    echo -e "${Y}Se desconectaran los clientes de TCP $p. Se conserva la configuracion.${N}"
    local ans; read -r -p '¿Cerrar este puerto? [s/N]: ' ans || return 1
    [[ "$ans" == [sS] ]] || return 0
    run_core --puerto "$p" --cerrar && echo -e "${G}Puerto $p cerrado.${N}"
}
restart_port(){
    local p
    choose_existing || return 1; p="$REPLY"
    if ! run_core --puerto "$p" --activo >/dev/null 2>&1; then
        echo -e "${Y}El puerto $p esta cerrado. Usa ABRIR PUERTO.${N}"; return 1
    fi
    if run_core --puerto "$p" --reiniciar; then
        echo -e "${G}Puerto $p reiniciado.${N}"
    fi
}
probe_port(){ local p; choose_existing || return 1; p="$REPLY"; run_core --puerto "$p" --probar; }
update_ports(){
    local p list bad=0
    list="$(ports)"
    [[ -n "$list" ]] || { echo 'No hay puertos instalados.'; return 1; }
    echo 'Se actualiza solo este motor. Cada puerto activo se reinicia; los cerrados siguen cerrados.'
    while IFS= read -r p; do
        [[ -n "$p" ]] || continue
        echo "Actualizando TCP $p..."
        run_core --puerto "$p" --actualizar || bad=1
    done <<< "$list"
    (( bad == 0 )) || { echo -e "${R}Algun puerto no pudo actualizarse; revisa el mensaje anterior.${N}"; return 1; }
    echo -e "${G}Motores actualizados; configuraciones conservadas.${N}"
}
set_response(){
    local p code
    choose_existing || return 1; p="$REPLY"
    echo '200: compatible con el payload original y la mayoria de inyectores.'
    echo '101: solo para inyectores que esperan Upgrade raw (SSH sin tramas WebSocket).'
    read -r -p 'Respuesta HTTP [200]: ' code || return 1
    code=${code:-200}
    [[ "$code" == 200 || "$code" == 101 ]] || { echo 'Respuesta invalida: usa 200 o 101.'; return 1; }
    run_core --puerto "$p" --actualizar --respuesta "$code"
}
uninstall_all(){
    local list p ans bad=0
    list="$(ports)"
    [[ -n "$list" ]] || { echo -e "${Y}No hay puertos instalados.${N}"; return 0; }
    echo -e "${R}Se borraran solamente los servicios y configuraciones de SSH PAYLOAD BRIDGE.${N}"
    echo 'SSH, usuarios, ProxyGo, otros protocolos y firewall permanecen intactos.'
    read -r -p 'Escribe DESINSTALAR para confirmar: ' ans || return 1
    [[ "$ans" == DESINSTALAR ]] || { echo 'Cancelado.'; return 0; }
    while IFS= read -r p; do
        [[ -n "$p" ]] || continue
        run_core --puerto "$p" --desinstalar || bad=1
    done <<< "$list"
    if (( bad )); then
        echo -e "${R}Algunos puertos no se retiraron. Comprueba los estados.${N}"
        return 1
    fi
    echo -e "${G}Desinstalacion completada: solo SSH PAYLOAD BRIDGE.${N}"
}

while :; do
    [[ -t 1 ]] && clear || true
    bar
    printf '%s          SSH PAYLOAD BRIDGE - NEW GOLDEN%s\n' "$W" "$N"
    bar
    show_status
    bar
    printf '%s           ADMINISTRADOR SSH PAYLOAD%s\n' "$W" "$N"
    printf '%s                 NEW-GOLDEN ADM PRO%s\n' "$R" "$N"
    bar
    printf '%s[1]%s  INSTALAR SSH PAYLOAD BRIDGE\n' "$G" "$N"
    printf '%s[2]%s  ABRIR PUERTO SSH PAYLOAD\n' "$G" "$N"
    printf '%s[3]%s  AGREGAR MAS PUERTOS SSH PAYLOAD\n' "$G" "$N"
    printf '%s[4]%s  CERRAR PUERTO SSH PAYLOAD\n' "$G" "$N"
    printf '%s[5]%s  REINICIAR SSH PAYLOAD BRIDGE\n' "$G" "$N"
    printf '%s[6]%s  DESINSTALAR SSH PAYLOAD BRIDGE\n' "$R" "$N"
    printf '%s[7]%s  PROBAR CONEXION SSH PAYLOAD\n' "$G" "$N"
    printf '%s[8]%s  ACTUALIZAR MOTOR (CONSERVAR PUERTOS)\n' "$G" "$N"
    printf '%s[9]%s  RESPUESTA DEL INYECTOR (200 / 101)\n' "$G" "$N"
    printf '%s[0]%s  VOLVER\n' "$R" "$N"
    bar
    read -r -p 'Selecciona una opcion: ' choice || break
    case "$choice" in
        1|3) install_port || true; pause ;;
        2) open_port || true; pause ;;
        4) close_port || true; pause ;;
        5) restart_port || true; pause ;;
        6) uninstall_all || true; pause ;;
        7) probe_port || true; pause ;;
        8) update_ports || true; pause ;;
        9) set_response || true; pause ;;
        0) break ;;
        *) echo 'Opcion invalida.'; pause ;;
    esac
done
