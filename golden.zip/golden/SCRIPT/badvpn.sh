#!/bin/bash

# Golden REV23: compatibilidad común, APT no interactivo, timeouts de red y progreso.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
# BADVPN UDPGW - Ubuntu/Debian compatible
# New Golden / Golden MX - Juegos online

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive

# ===== CONFIG =====
BIN="/usr/local/bin/badvpn-udpgw"
PORTS_FILE="/etc/badvpn-ports.conf"
SERVICE_TEMPLATE="/etc/systemd/system/badvpn-udpgw@.service"
SYSCTL_FILE="/etc/sysctl.d/99-badvpn-extremo.conf"
LIMITS_FILE="/etc/security/limits.d/99-badvpn-extremo.conf"
LOG="/tmp/badvpn-extremo.log"
DEFAULT_PORTS="7200 7300 7400"

# ===== COLORES =====
R='\033[1;31m'; G='\033[1;32m'; Y='\033[1;33m'; B='\033[1;34m'; W='\033[1;37m'; N='\033[0m'
linea(){ echo -e "${B}════════════════════════════════════════${N}"; }
pausa(){ echo; read -rp "Presiona ENTER para continuar..." _; }

root_check(){
    if [[ $EUID -ne 0 ]]; then
        echo -e "${R}Ejecuta como root: sudo su${N}"
        exit 1
    fi
}

valid_port(){ [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 && "$1" -le 65535 ]]; }

crear_ports_default(){
    [[ -f "$PORTS_FILE" ]] && return 0
    : > "$PORTS_FILE"
    for p in $DEFAULT_PORTS; do echo "$p" >> "$PORTS_FILE"; done
}

limpiar_dpkg_suave(){
    # No toca Apache ni elimina paquetes. Solo desbloquea dpkg si quedó pendiente.
    golden_apt_wait || return 1
    apt-get -f install -y >/dev/null 2>&1 || true
}

apt_run(){
    DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a apt-get \
      -o DPkg::Lock::Timeout=300 \
      -o Acquire::Retries=3 \
      -o Acquire::http::Timeout=25 \
      -o Acquire::https::Timeout=25 \
      -o Dpkg::Use-Pty=0 "$@"
}

instalar_dependencias(){
    limpiar_dpkg_suave || return 1
    golden_apt_update || return 1
    golden_install_required wget curl ca-certificates procps || return 1
    golden_install_iproute || return 1
}

instalar_badvpn_bin(){
    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null || true
        chmod +x "$BIN" 2>/dev/null || true
    fi

    [[ -x "$BIN" ]] && return 0

    # Primero intenta el paquete nativo de la distribución: es mucho más rápido
    # y evita compilar en Ubuntu/Debian cuando el binario ya está disponible.
    apt_run install -y badvpn >>"$LOG" 2>&1 || true
    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN"
        chmod +x "$BIN"
        return 0
    fi

    echo "Paquete badvpn no disponible; instalando herramientas de compilación..." >>"$LOG"
    golden_install_required git cmake make gcc g++ build-essential >>"$LOG" 2>&1 || return 1

    rm -rf /tmp/badvpn-src
    timeout 90 git clone --depth=1 https://github.com/ambrop72/badvpn.git /tmp/badvpn-src >>"$LOG" 2>&1 || return 1
    mkdir -p /tmp/badvpn-src/build
    cd /tmp/badvpn-src/build || return 1
    golden_run_timeout 180 cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 >>"$LOG" 2>&1 || return 1
    golden_run_timeout 300 make -j"$(nproc)" >>"$LOG" 2>&1 || return 1

    if [[ -x /tmp/badvpn-src/build/udpgw/badvpn-udpgw ]]; then
        cp /tmp/badvpn-src/build/udpgw/badvpn-udpgw "$BIN"
        chmod +x "$BIN"
        return 0
    fi
    return 1
}

optimizar_sistema(){
cat > "$SYSCTL_FILE" <<'EOS'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576
net.core.optmem_max = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.udp_rmem_min = 16384
net.ipv4.udp_wmem_min = 16384
net.ipv4.udp_mem = 3145728 4194304 8388608
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOS
    sysctl --system >/dev/null 2>&1 || true

cat > "$LIMITS_FILE" <<'EOS'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOS
}

crear_servicio_template(){
    if golden_has_systemd; then
cat > "$SERVICE_TEMPLATE" <<EOF2
[Unit]
Description=BADVPN UDPGW puerto %i - juegos online extremo
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$BIN --listen-addr 0.0.0.0:%i --max-clients 20000 --max-connections-for-client 30
Restart=always
RestartSec=1
StartLimitIntervalSec=0
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Nice=-5
OOMScoreAdjust=-900
KillMode=process
TimeoutStartSec=10
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
EOF2
        golden_daemon_reload
    fi
}

badvpn_service_name(){
    local p="$1"
    if golden_has_systemd; then
        printf 'badvpn-udpgw@%s' "$p"
    else
        printf 'badvpn-udpgw-%s' "$p"
    fi
}

crear_servicio_legacy(){
    local p="$1" svc="/etc/init.d/badvpn-udpgw-$1" pid="/var/run/badvpn-udpgw-$1.pid"
    golden_has_systemd && return 0
    cat >"$svc" <<EOF2
#!/bin/sh
### BEGIN INIT INFO
# Provides:          badvpn-udpgw-$p
# Required-Start:    \$network \$remote_fs
# Required-Stop:     \$network \$remote_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: BadVPN UDPGW puerto $p
### END INIT INFO
PIDFILE="$pid"
BIN="$BIN"
PORT="$p"
case "\$1" in
  start)
    if [ -s "\$PIDFILE" ]; then
      P=\$(cat "\$PIDFILE")
      if kill -0 "\$P" 2>/dev/null; then exit 0; fi
    fi
    rm -f "\$PIDFILE"
    nohup "\$BIN" --listen-addr 0.0.0.0:\$PORT --max-clients 20000 --max-connections-for-client 30 >/var/log/badvpn-udpgw-\$PORT.log 2>&1 &
    echo \$! >"\$PIDFILE"
    ;;
  stop)
    if [ -s "\$PIDFILE" ]; then
      P=\$(cat "\$PIDFILE")
      kill "\$P" 2>/dev/null || true
      I=0
      while kill -0 "\$P" 2>/dev/null && [ \$I -lt 5 ]; do sleep 1; I=\$((I+1)); done
      kill -9 "\$P" 2>/dev/null || true
    fi
    rm -f "\$PIDFILE"
    ;;
  restart) "\$0" stop; sleep 1; "\$0" start ;;
  status)
    [ -s "\$PIDFILE" ] || exit 1
    P=\$(cat "\$PIDFILE")
    kill -0 "\$P" 2>/dev/null
    ;;
  *) echo "Uso: \$0 {start|stop|restart|status}"; exit 2 ;;
esac
EOF2
    chmod 0755 "$svc"
    command -v update-rc.d >/dev/null 2>&1 && update-rc.d "badvpn-udpgw-$p" defaults >/dev/null 2>&1 || true
}



abrir_firewall_puerto(){
    local p="$1"
    command -v ufw >/dev/null 2>&1 && ufw allow "$p"/tcp >/dev/null 2>&1 || true
    command -v iptables >/dev/null 2>&1 && iptables -C INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || iptables -I INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || true
}

start_port(){
    local p="$1" svc
    valid_port "$p" || return 1
    abrir_firewall_puerto "$p"
    crear_servicio_template
    crear_servicio_legacy "$p"
    svc="$(badvpn_service_name "$p")"
    golden_service_enable "$svc" >/dev/null 2>&1 || true
    golden_service restart "$svc" >/dev/null 2>&1 || return 1
    sleep 1
    ss -ltnp 2>/dev/null | grep -q ":$p " || return 1
}


stop_port(){
    local p="$1" svc
    svc="$(badvpn_service_name "$p")"
    golden_service stop "$svc" >/dev/null 2>&1 || true
    golden_service_disable "$svc" >/dev/null 2>&1 || true
    if ! golden_has_systemd; then
        rm -f "/etc/init.d/$svc" "/var/run/$svc.pid"
    fi
}


instalar_activar(){
    clear; linea
    echo -e "${G}INSTALAR / ACTIVAR BADVPN EXTREMO SIMPLE${N}"
    linea
    echo "Puertos default: $DEFAULT_PORTS"
    linea
    : > "$LOG"

    echo -e "${Y}[1/5] Instalando dependencias...${N}"
    instalar_dependencias || { echo -e "${R}ERROR instalando dependencias. Revisa: $LOG${N}"; pausa; return 1; }

    echo -e "${Y}[2/5] Instalando badvpn-udpgw...${N}"
    instalar_badvpn_bin || { echo -e "${R}ERROR instalando badvpn-udpgw. Revisa: $LOG${N}"; pausa; return 1; }

    echo -e "${Y}[3/5] Optimizando sistema...${N}"
    optimizar_sistema

    echo -e "${Y}[4/5] Creando servicios por puerto...${N}"
    crear_ports_default
    crear_servicio_template

    echo -e "${Y}[5/5] Iniciando puertos...${N}"
    while read -r p; do
        [[ -z "$p" ]] && continue
        start_port "$p"
    done < "$PORTS_FILE"

    sleep 1
    linea
    echo -e "${G}BADVPN ACTIVADO${N}"
    estado_corto
    pausa
}

agregar_puerto(){
    clear; linea
    echo -e "${G}AGREGAR PUERTO BADVPN${N}"
    linea
    crear_ports_default
    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea
    read -rp "Nuevo puerto: " p
    valid_port "$p" || { echo -e "${R}Puerto inválido${N}"; pausa; return 1; }
    grep -qx "$p" "$PORTS_FILE" && { echo -e "${Y}Ese puerto ya existe${N}"; pausa; return 0; }
    echo "$p" >> "$PORTS_FILE"
    crear_servicio_template
    start_port "$p"
    echo -e "${G}Puerto agregado: $p${N}"
    pausa
}

eliminar_puerto(){
    clear; linea
    echo -e "${R}ELIMINAR PUERTO BADVPN${N}"
    linea
    [[ ! -f "$PORTS_FILE" ]] && { echo "No hay puertos."; pausa; return 0; }
    cat "$PORTS_FILE"
    linea
    read -rp "Puerto a eliminar: " p
    valid_port "$p" || { echo -e "${R}Puerto inválido${N}"; pausa; return 1; }
    stop_port "$p"
    grep -vx "$p" "$PORTS_FILE" > /tmp/badvpn-ports.tmp || true
    mv /tmp/badvpn-ports.tmp "$PORTS_FILE"
    echo -e "${G}Puerto eliminado: $p${N}"
    pausa
}

reiniciar_todo(){
    clear; linea
    echo -e "${Y}REINICIANDO BADVPN${N}"
    linea
    [[ ! -f "$PORTS_FILE" ]] && crear_ports_default
    crear_servicio_template
    while read -r p; do
        [[ -z "$p" ]] && continue
        start_port "$p"
    done < "$PORTS_FILE"
    echo -e "${G}Reinicio completado${N}"
    estado_corto
    pausa
}

estado_corto(){
    [[ ! -f "$PORTS_FILE" ]] && crear_ports_default
    echo
    echo -e "${W}ESTADO:${N}"
    while read -r p; do
        [[ -z "$p" ]] && continue
        local svc
        svc="$(badvpn_service_name "$p")"
        if golden_service_active "$svc" && ss -ltnp 2>/dev/null | grep -q ":$p "; then
            echo -e "  ${G}ON ${N} BADVPN puerto $p"
        elif golden_service_active "$svc"; then
            echo -e "  ${Y}RUN${N} servicio activo pero socket no visible $p"
        else
            echo -e "  ${R}OFF${N} BADVPN puerto $p"
        fi
    done < "$PORTS_FILE"
}


ver_estado(){
    clear; linea
    echo -e "${G}ESTADO BADVPN UDPGW${N}"
    linea
    estado_corto
    linea
    echo "Sockets activos:"
    ss -ltnp 2>/dev/null | grep badvpn || echo "No hay sockets BADVPN activos"
    linea
    pausa
}

desinstalar(){
    clear; linea
    echo -e "${R}DESINSTALAR BADVPN${N}"
    linea
    read -rp "¿Eliminar BADVPN completo? [s/n]: " r
    [[ "$r" != "s" && "$r" != "S" ]] && return 0

    if [[ -f "$PORTS_FILE" ]]; then
        while read -r p; do
            [[ -n "$p" ]] && stop_port "$p"
        done < "$PORTS_FILE"
    fi

    if golden_has_systemd; then
        local u
        while IFS= read -r u; do
            [[ -n "$u" ]] || continue
            golden_service stop "$u" >/dev/null 2>&1 || true
            golden_service_disable "$u" >/dev/null 2>&1 || true
        done < <(systemctl list-units 'badvpn-udpgw@*' --all --no-legend 2>/dev/null | awk '{print $1}')
        rm -f "$SERVICE_TEMPLATE"
        golden_daemon_reload
        systemctl reset-failed >/dev/null 2>&1 || true
    else
        rm -f /etc/init.d/badvpn-udpgw-* /var/run/badvpn-udpgw-*.pid
    fi

    rm -f "$PORTS_FILE" "$SYSCTL_FILE" "$LIMITS_FILE"
    sysctl --system >/dev/null 2>&1 || true
    echo -e "${G}BADVPN eliminado correctamente${N}"
    pausa
}


menu(){
    root_check
    while true; do
        clear
        linea
        echo -e "${G}      BADVPN UDPGW EXTREMO SIMPLE${N}"
        echo -e "${Y}        Optimizado para juegos online${N}"
        linea
        estado_corto
        linea
        echo -e "${G}[1]${N} Instalar / Activar"
        echo -e "${G}[2]${N} Agregar puerto"
        echo -e "${G}[3]${N} Eliminar puerto"
        echo -e "${G}[4]${N} Reiniciar BADVPN"
        echo -e "${G}[5]${N} Ver estado"
        echo -e "${R}[6]${N} Desinstalar"
        echo -e "${R}[0]${N} Salir"
        linea
        read -rp "Opción: " op
        case "$op" in
            1) instalar_activar ;;
            2) agregar_puerto ;;
            3) eliminar_puerto ;;
            4) reiniciar_todo ;;
            5) ver_estado ;;
            6) desinstalar ;;
            0) exit 0 ;;
            *) echo "Opción inválida"; sleep 1 ;;
        esac
    done
}

menu
