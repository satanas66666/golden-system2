#!/usr/bin/env bash
# SSH PAYLOAD BRIDGE — motor multipuerto basado en VPS POST SSH Compat v1 PRE_TEST.
# Uso: sudo bash ssh-payload-core.sh
# Opcional: --puerto 80 --ssh 22 --ip 0.0.0.0
# Gestion: --probar | --estado | --desinstalar | --ayuda
# Linux con systemd y Python >= 3.8. No instala ni reconfigura OpenSSH.
#
# Video revisado (23 octubre 2026):
# 157.137.204.53:80 -> 200 Connection established -> banner OpenSSH.
# 64.177.93.4:80 -> 400 Bad Request -> reemplazo local por 200 -> cierre.
# El video no identifica el software instalado en esas VPS. Este adaptador
# implementa el comportamiento visible; no es una copia del software ajeno.
#
# En HTTP Custom: TU_IP:PUERTO@TU_USUARIO:TU_CLAVE; Use Payload ON, SSL OFF.
# Mantener el payload original. Los usuarios deben existir en el SSH local.
# No usa el usuario demo ni la contrasena de la VPS ajena.
# Los limites/checkuser basados en la IP del cliente requieren revision:
# sshd vera la IP 127.0.0.1 del adaptador, no la IP externa del cliente.
#
# El puerto debe estar libre y permitido en el firewall del proveedor/VPS.
# Si ya esta ocupado, aborta sin detener servicios ni modificar el firewall.
# Para comprobar primero por Wi-Fi en otro puerto:
# sudo bash ssh-payload-core.sh --puerto 8080 --ssh 22
# En ese caso usar TU_IP:8080 en la app. El puerto alternativo no garantiza
# que una red movil permita ese mismo acceso.
#
# No cambia sshd_config, cuentas, PAM, paneles, DNS, algoritmos SSH, pagos,
# firewall o servicios existentes. Solo comunica con 127.0.0.1:PUERTO_SSH.
# No es un proxy abierto a destinos arbitrarios ni se conecta a twitter.com.
# El servidor responde 200 solo tras obtener un banner SSH real del backend.
# La prueba incluida verifica HTTP+banner; probar en la app autenticacion,
# DNS, navegacion, limites por usuario y conectar/desconectar varias veces.
# No garantiza conectividad en una red ajena, ni la replica de su configuracion.
# Referencias: https://docs.python.org/3/library/asyncio-stream.html
# https://www.rfc-editor.org/rfc/rfc4253
# https://www.freedesktop.org/software/systemd/man/systemd.exec.html

set -Eeuo pipefail
umask 022
# Rutas calculadas tras leer --puerto. Cada puerto es una instancia aislada.
APP_DIR=""
SERVER=""
CONFIG=""
CONFIG_DIR=/etc/golden-ssh-payload
UNIT=""
SERVICE=""
PORT=80
SSH_PORT=22
BIND_IP=0.0.0.0
ACTION=install
CREATED=0
INSTALLED=0

fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
need_value() { [[ $# -ge 2 && -n ${2:-} ]] || fail "Falta el valor de $1"; }
usage() {
    cat <<'HELP'
SSH PAYLOAD BRIDGE v1 PRE_TEST
Instala un adaptador de payload HTTP al SSH de ESTA VPS.

  sudo bash ssh-payload-core.sh --puerto 80 --ssh 22
  sudo bash ssh-payload-core.sh --probar
  sudo bash ssh-payload-core.sh --estado
  sudo bash ssh-payload-core.sh --desinstalar

Opciones:
  --puerto N    Puerto publico del adaptador (80 por defecto).
  --ssh N       Puerto del SSH local existente (22 por defecto).
  --ip IPv4    IP de escucha (0.0.0.0 por defecto, todas las IPv4).

Usa tus propios usuarios SSH. El instalador no crea cuentas ni claves.
Se detiene si el puerto esta ocupado. No cambia paneles ni firewall.
El SSH local vera las conexiones como 127.0.0.1; comprobar cualquier
limite/checkuser que dependa de la IP externa antes de usar en produccion.
HELP
}

while (($#)); do
    case "$1" in
        --puerto) need_value "$@"; PORT=$2; shift 2 ;;
        --ssh) need_value "$@"; SSH_PORT=$2; shift 2 ;;
        --ip) need_value "$@"; BIND_IP=$2; shift 2 ;;
        --probar) ACTION=probe; shift ;;
        --estado) ACTION=status; shift ;;
        --desinstalar) ACTION=uninstall; shift ;;
        --ayuda|--help|-h) usage; exit 0 ;;
        *) fail "Opcion desconocida: $1. Consulta --ayuda." ;;
    esac
done

# No interpolar el puerto en rutas ni nombres de unidades hasta validarlo.
[[ "$PORT" =~ ^[0-9]{1,5}$ ]] || fail "Puerto invalido (1..65535)."
(( 10#$PORT >= 1 && 10#$PORT <= 65535 )) || fail "Puerto fuera de rango."
PORT=$((10#$PORT))
APP_DIR="/opt/golden-ssh-payload/port-${PORT}"
SERVER="${APP_DIR}/payload_ssh.py"
CONFIG="${CONFIG_DIR}/port-${PORT}.json"
UNIT="/etc/systemd/system/golden-ssh-payload-${PORT}.service"
SERVICE="golden-ssh-payload-${PORT}.service"

[[ ${EUID} -eq 0 ]] || fail "Ejecuta con sudo bash este_archivo.sh"
command -v systemctl >/dev/null || fail "Esta VPS necesita systemd. No se cambio nada."
[[ -d /run/systemd/system ]] || fail "systemd no esta activo. No se cambio nada."

if [[ $ACTION == status ]]; then
    systemctl --no-pager --full status "$SERVICE"
    exit $?
fi

if [[ $ACTION == uninstall ]]; then
    [[ -f $APP_DIR/.installed-by-golden-ssh-payload && -f $CONFIG && -f $UNIT ]] || fail "No se encontro una instalacion propia y completa; no se borrara nada."
    systemctl disable --now "$SERVICE"
    rm -f -- "$UNIT" "$CONFIG" "$SERVER" "$APP_DIR/.installed-by-golden-ssh-payload"
    rmdir -- "$APP_DIR" 2>/dev/null || true
    rmdir -- /opt/golden-ssh-payload "$CONFIG_DIR" 2>/dev/null || true
    systemctl daemon-reload
    printf 'SSH PAYLOAD BRIDGE desinstalado. SSH y demas servicios conservados.\n'
    exit 0
fi

PYTHON=$(command -v python3) || fail "Falta Python 3. Instala python3 con el gestor de tu distribucion y vuelve a ejecutar."
"$PYTHON" -c 'import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)' || fail "Se necesita Python 3.8 o superior."
[[ $PYTHON =~ ^/[A-Za-z0-9_./+-]+$ ]] || fail "La ruta de Python necesita una instalacion estandar sin espacios."
PYTHON=$(readlink -f -- "$PYTHON")

if [[ $ACTION == probe ]]; then
    [[ -f $SERVER && -f $CONFIG ]] || fail "Primero instala el adaptador."
    exec "$PYTHON" "$SERVER" --config "$CONFIG" --probe
fi

printf '\nSSH PAYLOAD BRIDGE v1 PRE_TEST\n'
printf 'Comprobando SSH local y puerto publico antes de instalar...\n'

# Solo una instalacion nueva: no sustituye archivos o servicios existentes.
[[ ! -e $APP_DIR && ! -L $APP_DIR && ! -e $CONFIG && ! -L $CONFIG && ! -e $UNIT && ! -L $UNIT ]] || fail "Ya existen archivos del adaptador. Usa --estado o --probar. Para cambiar puertos, desinstala primero con --desinstalar."
LOAD_STATE=$(systemctl show "$SERVICE" --property=LoadState --value)
[[ $LOAD_STATE == not-found ]] || fail "Ya existe una unidad con ese nombre; no se sustituira."

"$PYTHON" - "$PORT" "$SSH_PORT" "$BIND_IP" <<'PREFLIGHT'
import ipaddress, socket, sys
try:
    listen, ssh_port = int(sys.argv[1]), int(sys.argv[2])
    if not (1 <= listen <= 65535 and 1 <= ssh_port <= 65535) or listen == ssh_port:
        raise ValueError('Los puertos deben estar entre 1 y 65535 y ser diferentes.')
    address = ipaddress.ip_address(sys.argv[3])
    if address.version != 4:
        raise ValueError('Esta version escucha en IPv4.')
    with socket.create_connection(('127.0.0.1', ssh_port), timeout=5) as ssh:
        ssh.settimeout(5)
        banner = bytearray()
        while not banner.endswith(b'\n') and len(banner) < 1024:
            part = ssh.recv(1)
            if not part:
                break
            banner.extend(part)
        if not banner.startswith((b'SSH-2.0-', b'SSH-1.99-')):
            raise ValueError('El puerto local indicado no presenta un banner SSH real.')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        # Sin SO_REUSEPORT: nunca comparte un puerto con otro servicio.
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((str(address), listen))
        listener.listen(1)
except (OSError, ValueError) as exc:
    print('ERROR de comprobacion: ' + str(exc), file=sys.stderr)
    print('Si el puerto esta ocupado, revisa: sudo ss -ltnp', file=sys.stderr)
    print('No se detuvo ningun servicio. Puedes probar --puerto 8080.', file=sys.stderr)
    sys.exit(1)
print('SSH local disponible y puerto de escucha libre.')
PREFLIGHT

rollback() {
    local result=$?
    trap - EXIT
    if (( CREATED && ! INSTALLED )); then
        printf '\nLa instalacion no termino; retirando solo el adaptador nuevo.\n' >&2
        systemctl disable --now "$SERVICE" >/dev/null 2>&1 || true
        rm -f -- "$UNIT" "$CONFIG" "$SERVER" "$APP_DIR/.installed-by-golden-ssh-payload"
        rmdir -- "$APP_DIR" 2>/dev/null || true
        rmdir -- /opt/golden-ssh-payload "$CONFIG_DIR" 2>/dev/null || true
        systemctl daemon-reload || true
    fi
    exit "$result"
}
trap rollback EXIT
mkdir -p -m 755 -- /opt/golden-ssh-payload "$CONFIG_DIR"
mkdir -m 755 -- "$APP_DIR"
CREATED=1
printf 'Golden SSH Payload Bridge 1.0.0\n' > "$APP_DIR/.installed-by-golden-ssh-payload"

"$PYTHON" - "$CONFIG" "$PORT" "$SSH_PORT" "$BIND_IP" <<'CONFIG_PY'
import json, os, sys
with open(sys.argv[1], 'x', encoding='utf-8') as handle:
    json.dump({'listen_host': sys.argv[4], 'listen_port': int(sys.argv[2]),
               'ssh_port': int(sys.argv[3]), 'max_connections': 512}, handle, indent=2)
    handle.write('\n')
os.chmod(sys.argv[1], 0o644)
CONFIG_PY

cat > "$SERVER" <<'PAYLOAD_SSH_PY'
#!/usr/bin/env python3
"""SSH PAYLOAD BRIDGE POST -> SSH local. No resuelve ni conecta al Host del payload."""
import argparse
import asyncio
import contextlib
import ipaddress
import json
import logging
import re
import signal
import socket
import sys
import time

VERSION = "1.0.0 PRE_TEST"
HEADER_LIMIT = 16384
HEADER_TIMEOUT = 15.0
LEGACY_SETTLE = 0.25
CHUNK = 65536
HTTP_OK = b"HTTP/1.1 200 Connection established\r\n\r\n"
DELIMITER = re.compile(br"\r?\n\r?\n")
LEGACY_END = re.compile(br"(?:\r?\n)Content-Type:[^\r\n]*\r?\n$", re.I)
LOG = logging.getLogger("golden-ssh-payload")
PAYLOAD_VIDEO = (
    b"POST / HTTP/1.1\n"
    b"Host: twitter.com\n"
    b"User-Agent: Mozila/5.0(Macintosh;Intel Mac OS X 11_3)AppleWebkit/537.6\n"
    b"Content-Lenght: 4507\n"
    b"Content-Type:application/\r\n"
)


class BadRequest(Exception):
    pass


def validate_header(header):
    lines = header.replace(b"\r\n", b"\n").split(b"\n")
    fields = lines[0].split()
    if len(fields) != 3 or fields[0] not in (b"POST", b"GET", b"CONNECT"):
        raise BadRequest("metodo no admitido")
    if fields[2] not in (b"HTTP/1.0", b"HTTP/1.1"):
        raise BadRequest("version no admitida")
    if fields[0] != b"CONNECT" and fields[1] != b"/":
        raise BadRequest("ruta no admitida")
    for line in lines[1:]:
        if line and (b":" not in line or b"\x00" in line):
            raise BadRequest("cabecera incompleta")
    # Adaptador de protocolo, no servidor web: no lee un cuerpo de 4507 bytes.
    # Tampoco interpreta Host, CONNECT target, Content-Length o Content-Lenght
    # como destinos ni instrucciones de reenvio.


async def read_preamble(reader):
    data = bytearray()
    deadline = time.monotonic() + HEADER_TIMEOUT
    while True:
        end = DELIMITER.search(data)
        if end:
            if end.end() > HEADER_LIMIT:
                raise BadRequest("cabecera demasiado larga")
            header, tail = bytes(data[:end.start()]), bytes(data[end.end():])
            validate_header(header)
            return tail
        # Tambien conserva un banner SSH enviado junto al payload sin linea vacia.
        marker = data.find(b"\nSSH-")
        if marker >= 0:
            header = bytes(data[:marker + 1])
            if LEGACY_END.search(header):
                validate_header(header)
                return bytes(data[marker + 1:])
        if len(data) >= HEADER_LIMIT:
            raise BadRequest("cabecera demasiado larga")
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise BadRequest("tiempo de cabecera agotado")
        legacy_ready = LEGACY_END.search(data) is not None
        wait = min(remaining, LEGACY_SETTLE) if legacy_ready else remaining
        try:
            part = await asyncio.wait_for(reader.read(min(4096, HEADER_LIMIT - len(data))), wait)
        except asyncio.TimeoutError:
            if legacy_ready:
                validate_header(bytes(data))
                return b""
            raise BadRequest("tiempo de cabecera agotado")
        if not part:
            raise BadRequest("cliente cerrado antes de negociar")
        data.extend(part)


def tune_socket(writer):
    sock = writer.get_extra_info("socket")
    if sock is None:
        return
    with contextlib.suppress(OSError):
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    for name, value in (("TCP_KEEPIDLE", 120), ("TCP_KEEPINTVL", 30), ("TCP_KEEPCNT", 5)):
        option = getattr(socket, name, None)
        if option is not None:
            with contextlib.suppress(OSError):
                sock.setsockopt(socket.IPPROTO_TCP, option, value)


async def close_writer(writer):
    if writer is not None:
        writer.close()
        with contextlib.suppress(Exception):
            await asyncio.wait_for(writer.wait_closed(), 2)


async def send_error(writer, status):
    with contextlib.suppress(Exception):
        writer.write(b"HTTP/1.1 " + status + b"\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
        await asyncio.wait_for(writer.drain(), 2)


async def copy_stream(reader, writer, skip_leading_newlines=False):
    while True:
        data = await reader.read(CHUNK)
        if not data:
            # TCP half-close: la otra direccion sigue entregando datos pendientes.
            if writer.can_write_eof():
                writer.write_eof()
                await writer.drain()
            return
        if skip_leading_newlines:
            # Una linea vacia opcional puede llegar en otro paquete tras el
            # formato incompleto del video. Nunca debe entrar al SSH local.
            data = data.lstrip(b"\r\n")
            if not data:
                continue
            skip_leading_newlines = False
        writer.write(data)
        await writer.drain()


class Relay:
    def __init__(self, config):
        self.config = config
        self.active = 0
        self.tasks = set()

    async def handle(self, reader, writer):
        task = asyncio.current_task()
        self.tasks.add(task)
        upstream = None
        pumps = []
        counted = False
        negotiated = False
        try:
            if self.active >= self.config["max_connections"]:
                await send_error(writer, b"503 Service Unavailable")
                return
            self.active += 1
            counted = True
            tune_socket(writer)
            try:
                tail = await read_preamble(reader)
            except BadRequest as exc:
                LOG.debug("Entrada rechazada: %s", exc)
                await send_error(writer, b"400 Bad Request")
                return
            try:
                upstream_reader, upstream = await asyncio.wait_for(
                    asyncio.open_connection("127.0.0.1", self.config["ssh_port"], limit=CHUNK), 5
                )
                tune_socket(upstream)
                banner = await asyncio.wait_for(upstream_reader.readline(), 5)
                if len(banner) > 1024 or not banner.startswith((b"SSH-2.0-", b"SSH-1.99-")):
                    raise ConnectionError("el servicio local no presenta un banner SSH")
            except (OSError, ValueError, asyncio.TimeoutError, ConnectionError):
                LOG.debug("SSH local no disponible")
                await send_error(writer, b"502 Bad Gateway")
                return
            # El 200 solo se envia despues de recibir un banner SSH real.
            writer.write(HTTP_OK + banner)
            await writer.drain()
            negotiated = True
            tail = tail.lstrip(b"\r\n")
            if tail:
                upstream.write(tail)
                await upstream.drain()
            pumps = [
                asyncio.create_task(copy_stream(reader, upstream, skip_leading_newlines=not tail)),
                asyncio.create_task(copy_stream(upstream_reader, writer)),
            ]
            # Conserva el half-close sin imponer una caducidad a una sesion SSH
            # valida. Un error de transporte cancela ambos sentidos en finally.
            await asyncio.gather(*pumps)
        except (OSError, asyncio.TimeoutError, ConnectionError):
            LOG.debug("Conexion finalizada; negociada=%s", negotiated)
        except Exception:
            # No registra payloads, credenciales ni bytes del tunel.
            LOG.error("Error interno de una conexion; revisar el servicio local")
        finally:
            for pump in pumps:
                if not pump.done():
                    pump.cancel()
            if pumps:
                await asyncio.gather(*pumps, return_exceptions=True)
            await asyncio.gather(close_writer(upstream), close_writer(writer))
            if counted:
                self.active -= 1
            self.tasks.discard(task)

    async def shutdown(self):
        tasks = list(self.tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)


def read_config(path):
    with open(path, "r", encoding="utf-8") as handle:
        config = json.load(handle)
    address = ipaddress.ip_address(config.get("listen_host", "0.0.0.0"))
    if address.version != 4:
        raise ValueError("Esta version utiliza una direccion IPv4 de escucha")
    result = {"listen_host": str(address)}
    for field, default, maximum in (("listen_port", 80, 65535), ("ssh_port", 22, 65535),
                                     ("max_connections", 512, 4096)):
        value = config.get(field, default)
        if type(value) is not int or not 1 <= value <= maximum:
            raise ValueError("Valor no valido: " + field)
        result[field] = value
    if result["listen_port"] == result["ssh_port"]:
        raise ValueError("El puerto del adaptador debe ser distinto del puerto SSH")
    return result


def probe(host, port):
    if host == "0.0.0.0":
        host = "127.0.0.1"
    with socket.create_connection((host, port), timeout=6) as sock:
        sock.settimeout(6)
        sock.sendall(PAYLOAD_VIDEO)
        with sock.makefile("rb") as stream:
            line = stream.readline(1024)
            if line.rstrip(b"\r\n") != HTTP_OK.split(b"\r\n", 1)[0]:
                raise RuntimeError("El adaptador no devolvio 200 Connection established")
            size = len(line)
            while True:
                header = stream.readline(1024)
                size += len(header)
                if not header or size > HEADER_LIMIT:
                    raise RuntimeError("Respuesta HTTP incompleta")
                if header in (b"\r\n", b"\n"):
                    break
            banner = stream.readline(1024)
            if not banner.startswith((b"SSH-2.0-", b"SSH-1.99-")):
                raise RuntimeError("No se recibio un banner SSH real")
    print("OK: 200 Connection established y banner SSH real.")
    print("La autenticacion del usuario y el trafico se comprueban desde la app.")


async def serve(config):
    relay = Relay(config)
    server = await asyncio.start_server(
        relay.handle, config["listen_host"], config["listen_port"],
        family=socket.AF_INET, limit=CHUNK, backlog=128,
    )
    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        asyncio.get_running_loop().add_signal_handler(sig, stop.set)
    LOG.info("SSH PAYLOAD BRIDGE iniciado; autenticacion a cargo del SSH local")
    try:
        await stop.wait()
    finally:
        server.close()
        await server.wait_closed()
        await relay.shutdown()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO, format="%(message)s")
    try:
        config = read_config(args.config)
        if args.probe:
            probe(config["listen_host"], config["listen_port"])
        else:
            asyncio.run(serve(config))
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
PAYLOAD_SSH_PY
chmod 644 -- "$SERVER"
"$PYTHON" - "$SERVER" <<'COMPILE_PY'
import sys
with open(sys.argv[1], encoding='utf-8') as handle:
    compile(handle.read(), sys.argv[1], 'exec')
COMPILE_PY

cat > "$UNIT" <<UNIT_EOF
[Unit]
Description=Golden SSH Payload Bridge puerto ${PORT} (HTTP a SSH local)
After=network.target
StartLimitIntervalSec=30
StartLimitBurst=5

[Service]
Type=simple
ExecStart=$PYTHON -B $SERVER --config $CONFIG
WorkingDirectory=$APP_DIR
DynamicUser=yes
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectSystem=strict
ProtectHome=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
RestrictSUIDSGID=yes
LockPersonality=yes
UMask=0077
Restart=on-failure
RestartSec=2
TimeoutStopSec=10
LimitNOFILE=8192
TasksMax=64
MemoryMax=384M
StandardOutput=journal
StandardError=journal
SyslogIdentifier=golden-ssh-payload-${PORT}

[Install]
WantedBy=multi-user.target
UNIT_EOF
chmod 644 -- "$UNIT"
systemctl daemon-reload
systemctl enable --now "$SERVICE"

# Espera acotada de arranque y prueba real del payload original en localhost.
READY=0
for attempt in 1 2 3 4 5; do
    if "$PYTHON" "$SERVER" --config "$CONFIG" --probe; then
        READY=1
        break
    fi
    sleep 1
done
if (( ! READY )); then
    journalctl -u "$SERVICE" -n 15 --no-pager >&2 || true
    fail "El adaptador no supero su prueba local. Se retirara la instalacion nueva."
fi
INSTALLED=1
printf '\nINSTALADO: escucha en %s:%s y enlaza al SSH local %s.\n' "$BIND_IP" "$PORT" "$SSH_PORT"
printf 'HTTP Custom: TU_IP:%s@TU_USUARIO:TU_CLAVE\n' "$PORT"
printf 'Activa Use Payload, desactiva SSL y conserva tu payload original.\n'
printf 'Usa una cuenta SSH propia que ya funcione en esta VPS.\n'
printf 'Permite TCP %s en el firewall del proveedor y de la VPS, si corresponde.\n' "$PORT"
printf 'Comprueba autenticacion, navegacion, DNS y limites de tu panel en la app.\n'
printf 'Nota: sshd vera el origen 127.0.0.1; revisa reglas basadas en IP.\n'
printf 'No se cambio SSH, PAM, usuarios, paneles, pagos ni firewall.\n'
