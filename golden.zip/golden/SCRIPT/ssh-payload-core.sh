#!/usr/bin/env bash
# SSH PAYLOAD BRIDGE — motor TCP flexible multipuerto, 1.1.1 PRE_TEST.
# Uso: sudo bash ssh-payload-core.sh
# Opcional: --puerto 80 --ssh 22 --ip 0.0.0.0
# Gestion: --probar | --estado | --actualizar [--respuesta 200|101] | --desinstalar | --ayuda
# Debian/Ubuntu con systemd o SysV/init.d y Python >= 3.5. No instala ni reconfigura OpenSSH.
#
# Video revisado (23 octubre 2026):
# 157.137.204.53:80 -> 200 Connection established -> banner OpenSSH.
# 64.177.93.4:80 -> 400 Bad Request -> reemplazo local por 200 -> cierre.
# El video no identifica el software instalado en esas VPS. Este adaptador
# implementa el comportamiento visible; no es una copia del software ajeno.
#
# En HTTP Custom: TU_IP:PUERTO@TU_USUARIO:TU_CLAVE; Use Payload ON, SSL OFF.
# Mantener el payload original. Los usuarios deben existir en el SSH local.
# No usa el usuario demo ni la contrasena de la VPS ajena.
# Los limites/checkuser basados en la IP del cliente requieren revision:
# sshd vera la IP 127.0.0.1 del adaptador, no la IP externa del cliente.
#
# El puerto debe estar libre y permitido en el firewall del proveedor/VPS.
# Si ya esta ocupado, aborta sin detener servicios ni modificar el firewall.
# Para comprobar primero por Wi-Fi en otro puerto:
# sudo bash ssh-payload-core.sh --puerto 8080 --ssh 22
# En ese caso usar TU_IP:8080 en la app. El puerto alternativo no garantiza
# que una red movil permita ese mismo acceso.
#
# No cambia sshd_config, cuentas, PAM, paneles, DNS, algoritmos SSH, pagos,
# firewall o servicios existentes. Solo comunica con 127.0.0.1:PUERTO_SSH.
# No es un proxy abierto a destinos arbitrarios ni se conecta a twitter.com.
# Responde 200 (o 101 raw opcional) solo tras un banner SSH real del backend.
# No limita metodo/ruta/cabeceras. Desde la identificacion SSH no altera bytes.
# La prueba incluida verifica HTTP+banner; probar en la app autenticacion,
# DNS, navegacion, limites por usuario y conectar/desconectar varias veces.
# No garantiza conectividad en una red ajena, ni la replica de su configuracion.
# Referencias: https://docs.python.org/3/library/asyncio-stream.html
# https://www.rfc-editor.org/rfc/rfc4253
# https://www.freedesktop.org/software/systemd/man/systemd.exec.html

set -Eeuo pipefail
umask 022
# Rutas calculadas tras leer --puerto. Cada puerto es una instancia aislada.
APP_DIR=""
SERVER=""
CONFIG=""
CONFIG_DIR=/etc/golden-ssh-payload
UNIT=""
INIT=""
SERVICE=""
PORT=80
SSH_PORT=22
BIND_IP=0.0.0.0
ACTION=install
RESPONSE_CODE=""
CREATED=0
INSTALLED=0

write_server() {
    cat > "$1" <<'PAYLOAD_SSH_PY'
#!/usr/bin/env python3
"""SSH Payload Bridge: preambulos TCP flexibles hacia el SSH local."""
import argparse
import asyncio
import contextlib
import ipaddress
import json
import logging
import re
import signal
import socket
import sys
import time

VERSION = "1.1.1 PAYLOAD_FLEX_COMPAT PRE_TEST"
PREAMBLE_LIMIT = 262144
HEADER_TIMEOUT = 15.0
PREAMBLE_IDLE = 0.30
IDENT_TIMEOUT = 30.0
CHUNK = 65536
HTTP_OK = b"HTTP/1.1 200 Connection established\r\n\r\n"
HTTP_UPGRADE = (b"HTTP/1.1 101 Switching Protocols\r\n"
                b"Connection: Upgrade\r\nUpgrade: websocket\r\n\r\n")
DELIMITER = re.compile(br"\r\n\r\n|\n\r?\n|\r\r")
SSH_IDENT = re.compile(
    br"(?:\A|(?<=[\r\n]))SSH-(?:2\.0|1\.99)-[!-~]+(?: [ -~]*)?\r?\n"
)
LOG = logging.getLogger("golden-ssh-payload")
PAYLOAD_VIDEO = (
    b"POST / HTTP/1.1\n"
    b"Host: twitter.com\n"
    b"User-Agent: Mozila/5.0(Macintosh;Intel Mac OS X 11_3)AppleWebkit/537.6\n"
    b"Content-Lenght: 4507\n"
    b"Content-Type:application/\r\n"
)


class BadRequest(Exception):
    pass


def ssh_ident_offset(data):
    for match in SSH_IDENT.finditer(data):
        if len(match.group()) <= 255:
            return match.start()
    return None


async def read_preamble(reader):
    """No interpreta metodos, rutas, Host ni longitudes HTTP como ordenes.

    El final de una cabecera o una pausa permite responder al inyector. La
    frontera definitiva del tunel es la identificacion SSH del cliente, no
    la primera linea vacia: pueden quedar cuerpos, splits o mas peticiones.
    """
    data = bytearray()
    deadline = time.monotonic() + HEADER_TIMEOUT
    while True:
        leading = bytes(data).lstrip(b"\r\n")
        direct = leading.startswith(b"SSH-")
        offset = ssh_ident_offset(data)
        if offset is not None:
            return ("ssh" if direct else "payload"), bytes(data)
        if direct:
            if b"\n" in leading or len(leading) > 255:
                raise BadRequest("identificacion SSH no valida")
        elif DELIMITER.search(data):
            return "payload", bytes(data)
        # TLS cifrado necesita su terminador TLS; no se convierte en HTTP.
        if len(data) >= 3 and data[0] == 0x16 and data[1] == 0x03:
            raise BadRequest("TLS requiere un terminador TLS")
        if len(data) >= PREAMBLE_LIMIT:
            raise BadRequest("preambulo demasiado largo")
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise BadRequest("tiempo de preambulo agotado")
        wait = min(remaining, PREAMBLE_IDLE) if data and not direct else remaining
        try:
            part = await asyncio.wait_for(
                reader.read(min(4096, PREAMBLE_LIMIT - len(data))), wait
            )
        except asyncio.TimeoutError:
            if data and not direct:
                return "payload", bytes(data)
            raise BadRequest("tiempo de preambulo agotado")
        if not part:
            raise BadRequest("cliente cerrado antes de negociar")
        data.extend(part)


def tune_socket(writer):
    sock = writer.get_extra_info("socket")
    if sock is None:
        return
    with contextlib.suppress(OSError):
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    for name, value in (("TCP_KEEPIDLE", 120), ("TCP_KEEPINTVL", 30), ("TCP_KEEPCNT", 5)):
        option = getattr(socket, name, None)
        if option is not None:
            with contextlib.suppress(OSError):
                sock.setsockopt(socket.IPPROTO_TCP, option, value)


async def close_writer(writer):
    if writer is not None:
        writer.close()
        with contextlib.suppress(Exception):
            if hasattr(writer, "wait_closed"):
                await asyncio.wait_for(writer.wait_closed(), 2)


async def send_error(writer, status):
    with contextlib.suppress(Exception):
        writer.write(b"HTTP/1.1 " + status + b"\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
        await asyncio.wait_for(writer.drain(), 2)


async def copy_stream(reader, writer):
    while True:
        data = await reader.read(CHUNK)
        if not data:
            if writer.can_write_eof():
                writer.write_eof()
                await writer.drain()
            return
        writer.write(data)
        await writer.drain()


async def copy_client(reader, writer, initial):
    """Consume solo el preambulo; desde SSH- conserva TODOS los bytes.

    Esto evita entregar al sshd una segunda peticion, un cuerpo falso o un
    split tardio. Nunca vuelve a buscar/filtrar dentro del trafico SSH.
    """
    data = bytearray(initial)
    boundary = len(initial)
    deadline = time.monotonic() + IDENT_TIMEOUT
    while True:
        offset = ssh_ident_offset(data)
        if boundary:
            # Un payload sin salto final puede terminar al recibir la
            # respuesta. El primer byte posterior tambien inicia una linea.
            later = ssh_ident_offset(data[boundary:])
            if later is not None and (offset is None or boundary + later < offset):
                offset = boundary + later
        if offset is not None:
            if offset > PREAMBLE_LIMIT:
                raise BadRequest("preambulo demasiado largo")
            writer.write(data[offset:])
            await writer.drain()
            await copy_stream(reader, writer)
            return
        if len(data) >= PREAMBLE_LIMIT:
            raise BadRequest("preambulo demasiado largo")
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise BadRequest("no se recibio identificacion SSH")
        part = await asyncio.wait_for(
            reader.read(min(CHUNK, PREAMBLE_LIMIT - len(data))), remaining
        )
        if not part:
            raise BadRequest("cliente cerrado antes de iniciar SSH")
        data.extend(part)


class Relay:
    def __init__(self, config):
        self.config = config
        self.active = 0
        self.tasks = set()

    async def handle(self, reader, writer):
        task = asyncio.Task.current_task() if not hasattr(asyncio, "current_task") else asyncio.current_task()
        self.tasks.add(task)
        upstream = None
        pumps = []
        counted = False
        negotiated = False
        try:
            if self.active >= self.config["max_connections"]:
                await send_error(writer, b"503 Service Unavailable")
                return
            self.active += 1
            counted = True
            tune_socket(writer)
            try:
                mode, initial = await read_preamble(reader)
            except BadRequest:
                await send_error(writer, b"400 Bad Request")
                return
            try:
                upstream_reader, upstream = await asyncio.wait_for(
                    asyncio.open_connection("127.0.0.1", self.config["ssh_port"], limit=CHUNK), 5
                )
                tune_socket(upstream)
                banner = await asyncio.wait_for(upstream_reader.readline(), 5)
                if len(banner) > 1024 or not banner.startswith((b"SSH-2.0-", b"SSH-1.99-")):
                    raise ConnectionError("el servicio local no presenta un banner SSH")
            except (OSError, ValueError, asyncio.TimeoutError, ConnectionError):
                LOG.debug("SSH local no disponible")
                await send_error(writer, b"502 Bad Gateway")
                return
            if mode == "ssh":
                response = b""
            else:
                response = HTTP_UPGRADE if self.config.get("response_code", 200) == 101 else HTTP_OK
            # El exito solo se anuncia tras recibir un banner SSH real.
            writer.write(response + banner)
            await writer.drain()
            negotiated = True
            pumps = [
                asyncio.ensure_future(copy_client(reader, upstream, initial)),
                asyncio.ensure_future(copy_stream(upstream_reader, writer)),
            ]
            await asyncio.gather(*pumps)
        except (BadRequest, OSError, asyncio.TimeoutError, ConnectionError):
            LOG.debug("Conexion finalizada; negociada=%s", negotiated)
        except asyncio.CancelledError:
            raise
        except Exception:
            # No registra payloads, credenciales ni bytes del tunel.
            LOG.error("Error interno de una conexion; revisar el servicio local")
        finally:
            for pump in pumps:
                if not pump.done():
                    pump.cancel()
            if pumps:
                await asyncio.gather(*pumps, return_exceptions=True)
            await asyncio.gather(close_writer(upstream), close_writer(writer))
            if counted:
                self.active -= 1
            self.tasks.discard(task)

    async def shutdown(self):
        tasks = list(self.tasks)
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)


def read_config(path):
    with open(path, "r", encoding="utf-8") as handle:
        config = json.load(handle)
    address = ipaddress.ip_address(config.get("listen_host", "0.0.0.0"))
    if address.version != 4:
        raise ValueError("Esta version utiliza una direccion IPv4 de escucha")
    result = {"listen_host": str(address)}
    for field, default, maximum in (("listen_port", 80, 65535), ("ssh_port", 22, 65535),
                                     ("max_connections", 512, 4096)):
        value = config.get(field, default)
        if type(value) is not int or not 1 <= value <= maximum:
            raise ValueError("Valor no valido: " + field)
        result[field] = value
    code = config.get("response_code", 200)
    if type(code) is not int or code not in (200, 101):
        raise ValueError("response_code debe ser 200 o 101")
    result["response_code"] = code
    if result["listen_port"] == result["ssh_port"]:
        raise ValueError("El puerto del adaptador debe ser distinto del puerto SSH")
    return result


def probe(host, port, response_code=200):
    if host == "0.0.0.0":
        host = "127.0.0.1"
    cases = (
        ("POST incompleto original", (PAYLOAD_VIDEO,), False),
        ("metodo/ruta/cabeceras libres", (b"PATCH /ruta/libre?x=1 HTTP/1.0\r\nHost: propio\r\nX-Raro sin dos puntos\r\n\r\n",), False),
        ("payload dividido", (b"CONNECT propio:22 HTTP/1.1\r\n", b"Host: propio\r\n\r\n"), False),
        ("SSH directo", (b"SSH-2.0-GoldenPayloadProbe\r\n",), True),
    )
    for name, pieces, direct in cases:
        with socket.create_connection((host, port), timeout=6) as sock:
            sock.settimeout(6)
            for piece in pieces:
                sock.sendall(piece)
            with sock.makefile("rb") as stream:
                if not direct:
                    line = stream.readline(1024)
                    expected = HTTP_UPGRADE if response_code == 101 else HTTP_OK
                    if line.rstrip(b"\r\n") != expected.split(b"\r\n", 1)[0]:
                        raise RuntimeError("Respuesta incorrecta: " + name)
                    size = len(line)
                    while True:
                        header = stream.readline(1024)
                        size += len(header)
                        if not header or size > PREAMBLE_LIMIT:
                            raise RuntimeError("Respuesta HTTP incompleta")
                        if header in (b"\r\n", b"\n"):
                            break
                banner = stream.readline(1024)
                if not banner.startswith((b"SSH-2.0-", b"SSH-1.99-")):
                    raise RuntimeError("No se recibio un banner SSH real: " + name)
                if not direct:
                    sock.sendall(b"SSH-2.0-GoldenPayloadProbe\r\n")
        print("OK: " + name + " -> banner SSH real.")
    print("Autenticacion, navegacion y red movil: comprobar tambien desde la app.")


async def serve(config):
    relay = Relay(config)
    server = await asyncio.start_server(
        relay.handle, config["listen_host"], config["listen_port"],
        family=socket.AF_INET, limit=CHUNK, backlog=128,
    )
    stop = asyncio.Event()
    for sig in (signal.SIGINT, signal.SIGTERM):
        asyncio.get_event_loop().add_signal_handler(sig, stop.set)
    LOG.info("SSH PAYLOAD BRIDGE flexible iniciado; autenticacion a cargo del SSH local")
    try:
        await stop.wait()
    finally:
        server.close()
        await server.wait_closed()
        await relay.shutdown()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--version", action="version", version=VERSION)
    parser.add_argument("--config", required=True)
    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--check-config", action="store_true")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.debug else logging.INFO, format="%(message)s")
    try:
        config = read_config(args.config)
        if args.check_config:
            print("Configuracion SSH PAYLOAD valida.")
        elif args.probe:
            probe(config["listen_host"], config["listen_port"], config["response_code"])
        else:
            # asyncio.run/create_task/wait_closed no existen en Python 3.5/3.6.
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(serve(config))
            finally:
                if hasattr(loop, "shutdown_asyncgens"):
                    loop.run_until_complete(loop.shutdown_asyncgens())
                asyncio.set_event_loop(None)
                loop.close()
    except (OSError, ValueError, RuntimeError, json.JSONDecodeError) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
PAYLOAD_SSH_PY
}

fail() { printf '\nERROR: %s\n' "$*" >&2; exit 1; }
need_value() { [[ $# -ge 2 && -n ${2:-} ]] || fail "Falta el valor de $1"; }
payload_has_systemd(){ command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]; }
payload_ctl(){
    if payload_has_systemd; then command systemctl "$@"; return $?; fi
    local action="$1"; shift
    case "$action" in
        daemon-reload) return 0 ;;
        show) [[ -e "$UNIT" || -e "$INIT" ]] && echo loaded || echo not-found ;;
        is-active|status) [[ -x "$INIT" ]] && "$INIT" status ;;
        enable)
            [[ -x "$INIT" ]] || return 1
            update-rc.d "${SERVICE%.service}" defaults >/dev/null || return 1
            [[ " $* " == *' --now '* ]] && "$INIT" start || [[ " $* " != *' --now '* ]]
            ;;
        disable)
            if [[ " $* " == *' --now '* && -x "$INIT" ]]; then "$INIT" stop || return 1; fi
            update-rc.d -f "${SERVICE%.service}" remove >/dev/null
            ;;
        restart|start|stop) [[ -x "$INIT" ]] && "$INIT" "$action" ;;
        *) return 1 ;;
    esac
}
write_init(){
    # PID y argumentos propios: nunca mata otro Python ni usa killall.
    cat > "$INIT" <<INIT_EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides:          ${SERVICE%.service}
# Required-Start:    \$network \$remote_fs
# Required-Stop:     \$network \$remote_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Golden SSH Payload Bridge TCP $PORT
### END INIT INFO
# Golden SSH Payload Bridge - init propio, no modificar otros servicios.
DAEMON='$PYTHON'
SERVER='$SERVER'
CONFIG='$CONFIG'
PIDFILE='/run/golden-ssh-payload-${PORT}.pid'
owned(){
    [ -s "\$PIDFILE" ] || return 1
    pid=\$(cat "\$PIDFILE")
    case "\$pid" in ''|*[!0-9]*) return 1 ;; esac
    kill -0 "\$pid" 2>/dev/null || return 1
    [ -r "/proc/\$pid/cmdline" ] || return 1
    tr '\\000' '\\n' < "/proc/\$pid/cmdline" | grep -Fxq -- "\$SERVER" || return 1
    tr '\\000' '\\n' < "/proc/\$pid/cmdline" | grep -Fxq -- "\$CONFIG"
}
case "\$1" in
  start)
    owned && exit 0
    rm -f -- "\$PIDFILE"
    start-stop-daemon --start --background --make-pidfile --pidfile "\$PIDFILE" --startas "\$DAEMON" -- -B "\$SERVER" --config "\$CONFIG" || exit 1
    sleep 1
    owned
    ;;
  stop)
    if owned; then
        start-stop-daemon --stop --retry TERM/5/KILL/2 --pidfile "\$PIDFILE" --exec "\$DAEMON" || exit 1
    fi
    rm -f -- "\$PIDFILE"
    ;;
  restart) "\$0" stop && "\$0" start ;;
  status) owned || exit 3 ;;
  *) echo 'Uso: start|stop|restart|status'; exit 2 ;;
esac
INIT_EOF
    chmod 755 "$INIT"
}
usage() {
    cat <<'HELP'
SSH PAYLOAD BRIDGE 1.1.1 PAYLOAD_FLEX_COMPAT PRE_TEST
Instala un adaptador de payload TCP flexible al SSH de ESTA VPS.
Acepta metodos, rutas y cabeceras libres, cuerpos y payloads divididos.

  sudo bash ssh-payload-core.sh --puerto 80 --ssh 22
  sudo bash ssh-payload-core.sh --probar
  sudo bash ssh-payload-core.sh --estado
  sudo bash ssh-payload-core.sh --puerto 8080 --actualizar
  sudo bash ssh-payload-core.sh --desinstalar

Opciones:
  --puerto N    Cualquier puerto TCP libre, 1..65535 (80 por defecto).
  --ssh N       Puerto del SSH local existente (22 por defecto).
  --actualizar  Actualiza solo el motor propio; conserva puertos y estado.
  --abrir       Habilita e inicia el puerto propio (systemd o SysV).
  --cerrar      Detiene y deshabilita el puerto propio.
  --reiniciar   Reinicia solo si el puerto ya estaba activo.
  --respuesta N Respuesta del inyector: 200 (predeterminada) o 101 (Upgrade raw).
                No implementa tramas WebSocket ni terminacion TLS.
  --ip IPv4    IP de escucha (0.0.0.0 por defecto, todas las IPv4).

Usa tus propios usuarios SSH. El instalador no crea cuentas ni claves.
Se detiene si el puerto esta ocupado. No cambia paneles ni firewall.
El SSH local vera las conexiones como 127.0.0.1; comprobar cualquier
limite/checkuser que dependa de la IP externa antes de usar en produccion.
HELP
}

while (($#)); do
    case "$1" in
        --puerto) need_value "$@"; PORT=$2; shift 2 ;;
        --ssh) need_value "$@"; SSH_PORT=$2; shift 2 ;;
        --respuesta) need_value "$@"; RESPONSE_CODE=$2; shift 2 ;;
        --actualizar) ACTION=update; shift ;;
        --activo) ACTION=active; shift ;;
        --abrir) ACTION=open; shift ;;
        --cerrar) ACTION=close; shift ;;
        --reiniciar) ACTION=restart; shift ;;
        --ip) need_value "$@"; BIND_IP=$2; shift 2 ;;
        --probar) ACTION=probe; shift ;;
        --estado) ACTION=status; shift ;;
        --desinstalar) ACTION=uninstall; shift ;;
        --ayuda|--help|-h) usage; exit 0 ;;
        *) fail "Opcion desconocida: $1. Consulta --ayuda." ;;
    esac
done

# No interpolar el puerto en rutas ni nombres de unidades hasta validarlo.
[[ "$PORT" =~ ^[0-9]{1,5}$ ]] || fail "Puerto invalido (1..65535)."
(( 10#$PORT >= 1 && 10#$PORT <= 65535 )) || fail "Puerto fuera de rango."
PORT=$((10#$PORT))
[[ -z "$RESPONSE_CODE" || "$RESPONSE_CODE" == 200 || "$RESPONSE_CODE" == 101 ]] || fail "La respuesta debe ser 200 o 101."
APP_DIR="/opt/golden-ssh-payload/port-${PORT}"
SERVER="${APP_DIR}/payload_ssh.py"
CONFIG="${CONFIG_DIR}/port-${PORT}.json"
UNIT="/etc/systemd/system/golden-ssh-payload-${PORT}.service"
INIT="/etc/init.d/golden-ssh-payload-${PORT}"
SERVICE="golden-ssh-payload-${PORT}.service"

[[ ${EUID} -eq 0 ]] || fail "Ejecuta con sudo bash este_archivo.sh"
if ! payload_has_systemd; then
    command -v start-stop-daemon >/dev/null && command -v update-rc.d >/dev/null && [[ -d /etc/init.d ]] || fail "Se necesita systemd o SysV/init.d con start-stop-daemon y update-rc.d."
    if [[ -e $INIT || -L $INIT ]]; then
        [[ -f $INIT && ! -L $INIT ]] && grep -Fq '# Golden SSH Payload Bridge - init propio' "$INIT" || fail "El init existente no pertenece a este modulo."
    fi
fi
if [[ $ACTION == active ]]; then payload_ctl is-active --quiet "$SERVICE"; exit $?; fi
if [[ $ACTION == close ]]; then payload_ctl disable --now "$SERVICE"; exit $?; fi

if [[ $ACTION == status ]]; then
    payload_ctl status "$SERVICE"
    exit $?
fi

if [[ $ACTION == uninstall ]]; then
    [[ -f $APP_DIR/.installed-by-golden-ssh-payload && -f $CONFIG && -f $UNIT ]] || fail "No se encontro una instalacion propia y completa; no se borrara nada."
    payload_ctl disable --now "$SERVICE"
    rm -f -- "$UNIT" "$INIT" "$CONFIG" "$SERVER" "$APP_DIR/.installed-by-golden-ssh-payload"
    rmdir -- "$APP_DIR" 2>/dev/null || true
    rmdir -- /opt/golden-ssh-payload "$CONFIG_DIR" 2>/dev/null || true
    payload_ctl daemon-reload
    printf 'SSH PAYLOAD BRIDGE desinstalado. SSH y demas servicios conservados.\n'
    exit 0
fi

PYTHON=$(command -v python3) || fail "Falta Python 3. Instala python3 con el gestor de tu distribucion y vuelve a ejecutar."
"$PYTHON" -c 'import sys; sys.exit(0 if sys.version_info >= (3,5) else 1)' || fail "Se necesita Python 3.5 o superior (Ubuntu 16.04+/Debian 9+ de serie)."
[[ $PYTHON =~ ^/[A-Za-z0-9_./+-]+$ ]] || fail "La ruta de Python necesita una instalacion estandar sin espacios."
PYTHON=$(readlink -f -- "$PYTHON")

if [[ $ACTION == probe ]]; then
    [[ -f $SERVER && -f $CONFIG ]] || fail "Primero instala el adaptador."
    exec "$PYTHON" "$SERVER" --config "$CONFIG" --probe
fi

if [[ $ACTION == open || $ACTION == restart ]]; then
    [[ -f $SERVER && -f $CONFIG && -f $UNIT && -f $APP_DIR/.installed-by-golden-ssh-payload ]] || fail "Primero instala este puerto."
    if [[ $ACTION == restart ]]; then
        payload_ctl is-active --quiet "$SERVICE" || fail "El puerto esta cerrado. Usa ABRIR PUERTO."
        payload_ctl restart "$SERVICE" || fail "No se pudo reiniciar este puerto."
    else
        payload_ctl enable --now "$SERVICE" || fail "No se pudo abrir este puerto."
    fi
    for attempt in 1 2 3 4 5; do
        if "$PYTHON" "$SERVER" --config "$CONFIG" --probe; then exit 0; fi
        sleep 1
    done
    [[ $ACTION != open ]] || payload_ctl disable --now "$SERVICE"
    fail "El puerto no supero su prueba local. Revisa si esta ocupado."
fi

if [[ $ACTION == update ]]; then
    [[ -f $APP_DIR/.installed-by-golden-ssh-payload && -f $SERVER && -f $CONFIG && -f $UNIT ]] || fail "No hay una instalacion propia completa en TCP $PORT."
    [[ ! -L $APP_DIR && ! -L $SERVER && ! -L $CONFIG && ! -L $UNIT ]] || fail "La instalacion contiene enlaces simbolicos; no se reemplazara."
    STAGED=$(mktemp "$APP_DIR/.payload-flex.XXXXXX")
    trap 'rm -f -- "$STAGED"' EXIT
    write_server "$STAGED"
    chmod 644 -- "$STAGED"
    "$PYTHON" - "$SERVER" "$CONFIG" "$STAGED" "$SERVICE" "$RESPONSE_CODE" "$PYTHON" "$INIT" "$(payload_has_systemd && echo systemd || echo sysv)" <<'UPDATE_PY'
import json, os, pathlib, subprocess, sys, tempfile, time
server, config, staged = map(pathlib.Path, sys.argv[1:4])
service, response, python, init, manager = sys.argv[4:]
def control(action):
    command = ['systemctl', action, service] if manager == 'systemd' else [init, 'status' if action == 'is-active' else action]
    return subprocess.run(command)
old_server, old_config = server.read_bytes(), config.read_bytes()
server_mode, config_mode = server.stat().st_mode & 0o777, config.stat().st_mode & 0o777
compile(staged.read_text(encoding='utf-8'), str(server), 'exec')
new_config = old_config
if response:
    value = json.loads(old_config.decode('utf-8'))
    value['response_code'] = int(response)
    new_config = (json.dumps(value, indent=2) + '\n').encode('utf-8')

def atomic_write(path, content, mode):
    fd, name = tempfile.mkstemp(prefix='.payload-update-', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(name, mode)
        os.replace(name, str(path))
    finally:
        if os.path.exists(name):
            os.unlink(name)

fd, check_name = tempfile.mkstemp(prefix='.payload-config-', dir=str(config.parent))
try:
    with os.fdopen(fd, 'wb') as handle:
        handle.write(new_config)
    subprocess.run([python, str(staged), '--config', check_name, '--check-config'], check=True)
finally:
    os.unlink(check_name)
active = control('is-active').returncode == 0
changed = False
try:
    os.replace(str(staged), str(server))
    changed = True
    if new_config != old_config:
        atomic_write(config, new_config, config_mode)
    if active:
        control('restart').check_returncode()
        for attempt in range(5):
            result = subprocess.run([python, str(server), '--config', str(config), '--probe'])
            if result.returncode == 0:
                break
            time.sleep(1)
        else:
            raise RuntimeError('El motor nuevo no supero la prueba local')
except Exception as exc:
    if changed:
        atomic_write(server, old_server, server_mode)
        if new_config != old_config:
            atomic_write(config, old_config, config_mode)
        if active:
            restored = control('restart').returncode == 0
            if restored:
                for attempt in range(5):
                    if subprocess.run([python, str(server), '--config', str(config), '--probe']).returncode == 0:
                        break
                    time.sleep(1)
                else:
                    restored = False
            print('Motor anterior restaurado; servicio ' + ('verificado.' if restored else 'requiere revision.'), file=sys.stderr)
    print('ERROR al actualizar: ' + str(exc), file=sys.stderr)
    sys.exit(1)
print('Motor PAYLOAD_FLEX actualizado; puerto, SSH local y habilitacion conservados.')
print('Estado: ' + ('activo, prueba local correcta.' if active else 'cerrado, se mantiene cerrado.'))
UPDATE_PY
    exit 0
fi

printf '\nSSH PAYLOAD BRIDGE 1.1.1 PAYLOAD_FLEX_COMPAT PRE_TEST\n'
printf 'Comprobando SSH local y puerto publico antes de instalar...\n'

# Solo una instalacion nueva: no sustituye archivos o servicios existentes.
[[ ! -e $APP_DIR && ! -L $APP_DIR && ! -e $CONFIG && ! -L $CONFIG && ! -e $UNIT && ! -L $UNIT && ! -e $INIT && ! -L $INIT ]] || fail "Ya existen archivos del adaptador. Usa --estado o --probar. Para cambiar puertos, desinstala primero con --desinstalar."
LOAD_STATE=$(payload_ctl show "$SERVICE" --property=LoadState --value)
[[ $LOAD_STATE == not-found ]] || fail "Ya existe una unidad con ese nombre; no se sustituira."

"$PYTHON" - "$PORT" "$SSH_PORT" "$BIND_IP" <<'PREFLIGHT'
import ipaddress, socket, sys
try:
    listen, ssh_port = int(sys.argv[1]), int(sys.argv[2])
    if not (1 <= listen <= 65535 and 1 <= ssh_port <= 65535) or listen == ssh_port:
        raise ValueError('Los puertos deben estar entre 1 y 65535 y ser diferentes.')
    address = ipaddress.ip_address(sys.argv[3])
    if address.version != 4:
        raise ValueError('Esta version escucha en IPv4.')
    with socket.create_connection(('127.0.0.1', ssh_port), timeout=5) as ssh:
        ssh.settimeout(5)
        banner = bytearray()
        while not banner.endswith(b'\n') and len(banner) < 1024:
            part = ssh.recv(1)
            if not part:
                break
            banner.extend(part)
        if not banner.startswith((b'SSH-2.0-', b'SSH-1.99-')):
            raise ValueError('El puerto local indicado no presenta un banner SSH real.')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        # Sin SO_REUSEPORT: nunca comparte un puerto con otro servicio.
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((str(address), listen))
        listener.listen(1)
except (OSError, ValueError) as exc:
    print('ERROR de comprobacion: ' + str(exc), file=sys.stderr)
    print('Si el puerto esta ocupado, revisa: sudo ss -ltnp', file=sys.stderr)
    print('No se detuvo ningun servicio. Puedes probar --puerto 8080.', file=sys.stderr)
    sys.exit(1)
print('SSH local disponible y puerto de escucha libre.')
PREFLIGHT

rollback() {
    local result=$?
    trap - EXIT
    if (( CREATED && ! INSTALLED )); then
        printf '\nLa instalacion no termino; retirando solo el adaptador nuevo.\n' >&2
        payload_ctl disable --now "$SERVICE" >/dev/null 2>&1 || true
        rm -f -- "$UNIT" "$INIT" "$CONFIG" "$SERVER" "$APP_DIR/.installed-by-golden-ssh-payload"
        rmdir -- "$APP_DIR" 2>/dev/null || true
        rmdir -- /opt/golden-ssh-payload "$CONFIG_DIR" 2>/dev/null || true
        payload_ctl daemon-reload || true
    fi
    exit "$result"
}
trap rollback EXIT
mkdir -p -m 755 -- /opt/golden-ssh-payload "$CONFIG_DIR"
mkdir -m 755 -- "$APP_DIR"
CREATED=1
printf 'Golden SSH Payload Bridge 1.1.1 PAYLOAD_FLEX_COMPAT\n' > "$APP_DIR/.installed-by-golden-ssh-payload"

"$PYTHON" - "$CONFIG" "$PORT" "$SSH_PORT" "$BIND_IP" "${RESPONSE_CODE:-200}" <<'CONFIG_PY'
import json, os, sys
with open(sys.argv[1], 'x', encoding='utf-8') as handle:
    json.dump({'listen_host': sys.argv[4], 'listen_port': int(sys.argv[2]),
               'ssh_port': int(sys.argv[3]), 'max_connections': 512,
               'response_code': int(sys.argv[5])}, handle, indent=2)
    handle.write('\n')
os.chmod(sys.argv[1], 0o644)
CONFIG_PY

write_server "$SERVER"
chmod 644 -- "$SERVER"
"$PYTHON" - "$SERVER" <<'COMPILE_PY'
import sys
with open(sys.argv[1], encoding='utf-8') as handle:
    compile(handle.read(), sys.argv[1], 'exec')
COMPILE_PY

SYSTEMD_VERSION=$(command systemctl --version 2>/dev/null | awk 'NR==1 && $2 ~ /^[0-9]+$/ {print $2; exit}' || true)
SYSTEMD_VERSION=${SYSTEMD_VERSION:-229}
START_LIMIT_KEY=StartLimitInterval
MEMORY_KEY=MemoryLimit
(( SYSTEMD_VERSION < 232 )) || START_LIMIT_KEY=StartLimitIntervalSec
(( SYSTEMD_VERSION < 232 )) || MEMORY_KEY=MemoryMax
if (( SYSTEMD_VERSION >= 232 )); then
    SERVICE_USER='DynamicUser=yes'
    SYSTEM_PROTECTION=strict
else
    SERVICE_USER=$'User=nobody\nGroup=nogroup'
    SYSTEM_PROTECTION=full
fi
cat > "$UNIT" <<UNIT_EOF
[Unit]
Description=Golden SSH Payload Bridge puerto ${PORT} (HTTP a SSH local)
After=network.target
$START_LIMIT_KEY=30
StartLimitBurst=5

[Service]
Type=simple
ExecStart=$PYTHON -B $SERVER --config $CONFIG
WorkingDirectory=$APP_DIR
$SERVICE_USER
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectSystem=$SYSTEM_PROTECTION
ProtectHome=yes
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX
UMask=0077
Restart=on-failure
RestartSec=2
TimeoutStopSec=10
LimitNOFILE=8192
TasksMax=64
$MEMORY_KEY=384M
StandardOutput=journal
StandardError=journal
SyslogIdentifier=golden-ssh-payload-${PORT}

[Install]
WantedBy=multi-user.target
UNIT_EOF
# Directivas recientes solo cuando el gestor las admite.
if (( SYSTEMD_VERSION >= 232 )); then
    cat >> "$UNIT" <<'HARDENING_EOF'

[Service]
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
HARDENING_EOF
fi
if (( SYSTEMD_VERSION >= 235 )); then printf 'LockPersonality=yes\n' >> "$UNIT"; fi
if (( SYSTEMD_VERSION >= 245 )); then printf 'RestrictSUIDSGID=yes\n' >> "$UNIT"; fi
chmod 644 -- "$UNIT"
if ! payload_has_systemd; then write_init; fi
payload_ctl daemon-reload
payload_ctl enable --now "$SERVICE"

# Espera acotada y prueba del original, metodo libre, split y SSH directo.
READY=0
for attempt in 1 2 3 4 5; do
    if "$PYTHON" "$SERVER" --config "$CONFIG" --probe; then
        READY=1
        break
    fi
    sleep 1
done
if (( ! READY )); then
    journalctl -u "$SERVICE" -n 15 --no-pager >&2 || true
    fail "El adaptador no supero su prueba local. Se retirara la instalacion nueva."
fi
INSTALLED=1
printf '\nINSTALADO: escucha en %s:%s y enlaza al SSH local %s.\n' "$BIND_IP" "$PORT" "$SSH_PORT"
printf 'HTTP Custom: TU_IP:%s@TU_USUARIO:TU_CLAVE\n' "$PORT"
printf 'Activa Use Payload y conserva tu payload; este puerto es TCP sin TLS.\n'
printf 'Respuesta del inyector: %s (101 es Upgrade raw, sin tramas WebSocket).\n' "${RESPONSE_CODE:-200}"
printf 'Usa una cuenta SSH propia que ya funcione en esta VPS.\n'
printf 'Permite TCP %s en el firewall del proveedor y de la VPS, si corresponde.\n' "$PORT"
printf 'Comprueba autenticacion, navegacion, DNS y limites de tu panel en la app.\n'
printf 'Nota: sshd vera el origen 127.0.0.1; revisa reglas basadas en IP.\n'
printf 'No se cambio SSH, PAM, usuarios, paneles, pagos ni firewall.\n'
