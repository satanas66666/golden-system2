#!/bin/bash

# Golden REV22: capa comun anti-bloqueo / compatibilidad Ubuntu-Debian.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games/

#25/01/2021 by @Kalix1
clear
clear
#!/bin/bash
# Panel WebSocket Cloudflare PRO - con dashboard automático y barra personalizada

SCPinst="/etc/ger-inst"
mkdir -p "$SCPinst" &>/dev/null

# Colores
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;31m" [3]="\033[1;33m" [4]="\033[1;32m" )

# Barra personalizada
barra="\033[0m\e[33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[1;37m"
msg_bar() { echo -e "$barra"; }
msg_title() { echo -e "${cor[3]}          WEB SOCKET CLOUDFLARE PANEL"; }

# Crear script Python del Proxy ultra estable compatible con panel
create_ws_script() {
cat << 'EOF' > ${SCPinst}/PDirect.py
#!/usr/bin/env python3
import asyncio
import socket
import sys

LISTEN_ADDR = '0.0.0.0'
LISTEN_PORT = int(sys.argv[1])
TARGET = '127.0.0.1'
TARGET_PORT = 22
STATUS = sys.argv[2] if len(sys.argv) > 2 else "@Proxy"
BUFLEN = 8192

async def handle_client(client_reader, client_writer):
    try:
        # ---- RESPUESTA FALSA (panel) ----
        client_writer.write(f"HTTP/1.1 101 {STATUS}\r\n\r\n".encode())
        await client_writer.drain()
        try:
            await client_reader.read(BUFLEN)
        except:
            pass
        client_writer.write(f"HTTP/1.1 200 {STATUS}\r\n\r\n".encode())
        await client_writer.drain()

        # ---- CONEXIÓN BACKEND ----
        try:
            remote_reader, remote_writer = await asyncio.open_connection(TARGET, TARGET_PORT)
        except Exception as e:
            print("Error conectando al backend:", e)
            client_writer.close()
            await client_writer.wait_closed()
            return

        # ---- PIPE BIDIRECCIONAL EFICIENTE ----
        await asyncio.gather(
            pipe(client_reader, remote_writer),
            pipe(remote_reader, client_writer)
        )

    except Exception as e:
        print("Error en conexión:", e)
    finally:
        client_writer.close()
        await client_writer.wait_closed()

async def pipe(reader, writer):
    try:
        while True:
            data = await reader.read(BUFLEN)
            if not data:
                break
            writer.write(data)
            await writer.drain()
    except Exception:
        pass
    finally:
        try:
            writer.close()
            await writer.wait_closed()
        except:
            pass

async def main():
    server = await asyncio.start_server(handle_client, LISTEN_ADDR, LISTEN_PORT)
    print(f"Proxy estilo Rust iniciado en {LISTEN_ADDR}:{LISTEN_PORT}")
    async with server:
        await server.serve_forever()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("Proxy cerrado")
EOF

chmod +x ${SCPinst}/PDirect.py
}

create_systemd_service() {
    PORT=$1
    BANNER="$2"
    SERVICE_FILE="/etc/systemd/system/wscloud-$PORT.service"

    systemctl stop wscloud-$PORT 2>/dev/null
    systemctl disable wscloud-$PORT 2>/dev/null

    cat << EOF | tee $SERVICE_FILE >/dev/null
[Unit]
Description=Proxy WebSocket/TCP Cloudflare puerto $PORT
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
ExecStart=/usr/bin/python3 ${SCPinst}/PDirect.py $PORT "$BANNER"
Restart=always
RestartSec=3
User=root
LimitNOFILE=65535
TimeoutStartSec=30
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=wscloud-$PORT

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable wscloud-$PORT
    systemctl start wscloud-$PORT

    # Optimización VPS silenciosa
    ulimit -n 65535
    cat >> /etc/security/limits.conf <<EOL
* soft nofile 65535
* hard nofile 65535
root soft nofile 65535
root hard nofile 65535
EOL

    sysctl -w net.core.somaxconn=65535 >/dev/null
    sysctl -w net.core.netdev_max_backlog=65535 >/dev/null
    sysctl -w net.ipv4.tcp_max_syn_backlog=65535 >/dev/null
    sysctl -w net.ipv4.ip_local_port_range="1024 65535" >/dev/null
    sysctl -w net.ipv4.tcp_tw_reuse=1 >/dev/null
    sysctl -w net.ipv4.tcp_fin_timeout=15 >/dev/null
}

stop_systemd_service() {
echo -ne "Digite puerto a detener: " && read PORT
sudo systemctl stop wscloud-$PORT
sudo systemctl disable wscloud-$PORT
echo -e "${cor[2]}Proxy WebSocket puerto $PORT detenido"
}

proxy_status() {
PORT=$1
if systemctl is-active --quiet wscloud-$PORT; then
echo -e "${cor[4]}[ON]"
else
echo -e "${cor[2]}[OFF]"
fi
}

# Mostrar todos los proxies arriba
show_active_proxies() {
echo -e "\n${cor[3]}===== PUERTOS WebSocket ACTIVOS ====="
for svc in $(systemctl list-units --type=service | grep wscloud- | awk '{print $1}'); do
PORT_NUM=$(echo $svc | grep -oP '(?<=wscloud-)[0-9]+')
echo -n "Puerto $PORT_NUM : "
proxy_status $PORT_NUM
done
msg_bar
}

# Menú principal
while true; do
clear
msg_bar
msg_title
msg_bar
show_active_proxies   # Dashboard arriba
echo -e "${cor[3]}1) Iniciar Proxy WebSocket"
echo -e "2) Detener Proxy WebSocket"
echo -e "3) Agregar nuevo puerto WebSocket"
echo -e "0) Volver al panel principal"
msg_bar
echo -ne "${cor[0]}Seleccione opción: " && read opcion

case $opcion in
1)
create_ws_script
echo -ne "Puerto WebSocket (default 8080): " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
2)
stop_systemd_service
;;
3)
create_ws_script
echo -ne "Nuevo puerto WebSocket: " && read PORT
[[ -z "$PORT" ]] && PORT=8080
echo -ne "Banner: " && read BANNER
[[ -z "$BANNER" ]] && BANNER="Conectando..."
create_systemd_service $PORT "$BANNER"
;;
0) break;;
*) echo -e "${cor[2]}Opción no válida"; sleep 1;;
esac
done
msg_bar