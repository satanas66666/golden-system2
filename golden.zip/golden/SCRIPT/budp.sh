#!/bin/bash
# BADVPN UDPGW EXTREMO SIMPLE - Ubuntu/Debian modernos
# New Golden / Golden MX - Juegos online

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive

# ===== CONFIG =====
golden_wait_apt() {
    local waited=0
    while pgrep -x apt >/dev/null 2>&1 ||
          pgrep -x apt-get >/dev/null 2>&1 ||
          pgrep -x dpkg >/dev/null 2>&1 ||
          pgrep -x unattended-upgr >/dev/null 2>&1; do
        sleep 2
        waited=$((waited + 2))
        (( waited < 300 )) || {
            echo "APT/DPKG sigue ocupado después de 5 minutos." >&2
            return 1
        }
    done
    golden_wait_apt || return 1
}

BIN="/usr/local/bin/badvpn-udpgw"
PORTS_FILE="/etc/badvpn-ports.conf"
SERVICE_TEMPLATE="/etc/systemd/system/badvpn-udpgw@.service"
SYSCTL_FILE="/etc/sysctl.d/99-badvpn-extremo.conf"
LIMITS_FILE="/etc/security/limits.d/99-badvpn-extremo.conf"
LOG="/tmp/badvpn-extremo.log"
DEFAULT_PORTS="7200 7300 7400"

# ===== COLORES =====
R='\033[1;31m'; G='\033[1;32m'; Y='\033[1;33m'; B='\033[1;34m'; W='\033[1;37m'; N='\033[0m'
linea(){ echo -e "${B}════════════════════════════════════════${N}"; }
pausa(){ echo; read -rp "Presiona ENTER para continuar..." _; }

root_check(){
    if [[ $EUID -ne 0 ]]; then
        echo -e "${R}Ejecuta como root: sudo su${N}"
        exit 1
    fi
}

valid_port(){ [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 && "$1" -le 65535 ]]; }

crear_ports_default(){
    [[ -f "$PORTS_FILE" ]] && return 0
    : > "$PORTS_FILE"
    for p in $DEFAULT_PORTS; do echo "$p" >> "$PORTS_FILE"; done
}

limpiar_dpkg_suave(){
    # No toca Apache ni elimina paquetes. Solo desbloquea dpkg si quedó pendiente.
    golden_wait_apt || return 1
    apt-get -f install -y >/dev/null 2>&1 || true
}

instalar_dependencias(){
    limpiar_dpkg_suave
    apt-get update -y >>"$LOG" 2>&1 || return 1
    apt-get install -y wget curl ca-certificates iproute2 procps git cmake make gcc g++ build-essential >>"$LOG" 2>&1 || return 1
}

instalar_badvpn_bin(){
    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN" 2>/dev/null || true
        chmod +x "$BIN" 2>/dev/null || true
    fi

    [[ -x "$BIN" ]] && return 0

    apt-get install -y badvpn >>"$LOG" 2>&1 || true
    if command -v badvpn-udpgw >/dev/null 2>&1; then
        cp "$(command -v badvpn-udpgw)" "$BIN"
        chmod +x "$BIN"
        return 0
    fi

    rm -rf /tmp/badvpn-src
    git clone --depth=1 https://github.com/ambrop72/badvpn.git /tmp/badvpn-src >>"$LOG" 2>&1 || return 1
    mkdir -p /tmp/badvpn-src/build
    cd /tmp/badvpn-src/build || return 1
    cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1 >>"$LOG" 2>&1 || return 1
    make -j"$(nproc)" >>"$LOG" 2>&1 || return 1

    if [[ -x /tmp/badvpn-src/build/udpgw/badvpn-udpgw ]]; then
        cp /tmp/badvpn-src/build/udpgw/badvpn-udpgw "$BIN"
        chmod +x "$BIN"
        return 0
    fi
    return 1
}

optimizar_sistema(){
cat > "$SYSCTL_FILE" <<'EOS'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.core.rmem_default = 1048576
net.core.wmem_default = 1048576
net.core.optmem_max = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.udp_rmem_min = 16384
net.ipv4.udp_wmem_min = 16384
net.ipv4.udp_mem = 3145728 4194304 8388608
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_mtu_probing = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOS
    sysctl --system >/dev/null 2>&1 || true

cat > "$LIMITS_FILE" <<'EOS'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOS
}

crear_servicio_template(){
cat > "$SERVICE_TEMPLATE" <<EOF2
[Unit]
Description=BADVPN UDPGW puerto %i - juegos online extremo
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$BIN --listen-addr 0.0.0.0:%i --max-clients 20000 --max-connections-for-client 30
Restart=always
RestartSec=1
StartLimitIntervalSec=0
LimitNOFILE=1048576
LimitNPROC=1048576
TasksMax=infinity
Nice=-5
OOMScoreAdjust=-900
KillMode=process
TimeoutStartSec=10
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
EOF2
    systemctl daemon-reload >/dev/null 2>&1
}

abrir_firewall_puerto(){
    local p="$1"
    command -v ufw >/dev/null 2>&1 && ufw allow "$p"/tcp >/dev/null 2>&1 || true
    command -v iptables >/dev/null 2>&1 && iptables -C INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || iptables -I INPUT -p tcp --dport "$p" -j ACCEPT >/dev/null 2>&1 || true
}

start_port(){
    local p="$1"
    valid_port "$p" || return 1
    abrir_firewall_puerto "$p"
    systemctl enable "badvpn-udpgw@$p" >/dev/null 2>&1
    systemctl restart "badvpn-udpgw@$p" >/dev/null 2>&1
}

stop_port(){
    local p="$1"
    systemctl stop "badvpn-udpgw@$p" >/dev/null 2>&1 || true
    systemctl disable "badvpn-udpgw@$p" >/dev/null 2>&1 || true
}

instalar_activar(){
    clear; linea
    echo -e "${G}INSTALAR / ACTIVAR BADVPN EXTREMO SIMPLE${N}"
    linea
    echo "Puertos default: $DEFAULT_PORTS"
    linea
    : > "$LOG"

    echo -e "${Y}[1/5] Instalando dependencias...${N}"
    instalar_dependencias || { echo -e "${R}ERROR instalando dependencias. Revisa: $LOG${N}"; pausa; return 1; }

    echo -e "${Y}[2/5] Instalando badvpn-udpgw...${N}"
    instalar_badvpn_bin || { echo -e "${R}ERROR instalando badvpn-udpgw. Revisa: $LOG${N}"; pausa; return 1; }

    echo -e "${Y}[3/5] Optimizando sistema...${N}"
    optimizar_sistema

    echo -e "${Y}[4/5] Creando servicios por puerto...${N}"
    crear_ports_default
    crear_servicio_template

    echo -e "${Y}[5/5] Iniciando puertos...${N}"
    while read -r p; do
        [[ -z "$p" ]] && continue
        start_port "$p"
    done < "$PORTS_FILE"

    sleep 1
    linea
    echo -e "${G}BADVPN ACTIVADO${N}"
    estado_corto
    pausa
}

agregar_puerto(){
    clear; linea
    echo -e "${G}AGREGAR PUERTO BADVPN${N}"
    linea
    crear_ports_default
    echo "Puertos actuales:"
    cat "$PORTS_FILE"
    linea
    read -rp "Nuevo puerto: " p
    valid_port "$p" || { echo -e "${R}Puerto inválido${N}"; pausa; return 1; }
    grep -qx "$p" "$PORTS_FILE" && { echo -e "${Y}Ese puerto ya existe${N}"; pausa; return 0; }
    echo "$p" >> "$PORTS_FILE"
    crear_servicio_template
    start_port "$p"
    echo -e "${G}Puerto agregado: $p${N}"
    pausa
}

eliminar_puerto(){
    clear; linea
    echo -e "${R}ELIMINAR PUERTO BADVPN${N}"
    linea
    [[ ! -f "$PORTS_FILE" ]] && { echo "No hay puertos."; pausa; return 0; }
    cat "$PORTS_FILE"
    linea
    read -rp "Puerto a eliminar: " p
    valid_port "$p" || { echo -e "${R}Puerto inválido${N}"; pausa; return 1; }
    stop_port "$p"
    grep -vx "$p" "$PORTS_FILE" > /tmp/badvpn-ports.tmp || true
    mv /tmp/badvpn-ports.tmp "$PORTS_FILE"
    echo -e "${G}Puerto eliminado: $p${N}"
    pausa
}

reiniciar_todo(){
    clear; linea
    echo -e "${Y}REINICIANDO BADVPN${N}"
    linea
    [[ ! -f "$PORTS_FILE" ]] && crear_ports_default
    crear_servicio_template
    while read -r p; do
        [[ -z "$p" ]] && continue
        start_port "$p"
    done < "$PORTS_FILE"
    echo -e "${G}Reinicio completado${N}"
    estado_corto
    pausa
}

estado_corto(){
    [[ ! -f "$PORTS_FILE" ]] && crear_ports_default
    echo
    echo -e "${W}ESTADO:${N}"
    while read -r p; do
        [[ -z "$p" ]] && continue
        if systemctl is-active --quiet "badvpn-udpgw@$p"; then
            if ss -ltnp 2>/dev/null | grep -q ":$p "; then
                echo -e "  ${G}ON ${N} BADVPN puerto $p"
            else
                echo -e "  ${Y}RUN${N} servicio activo pero socket no visible $p"
            fi
        else
            echo -e "  ${R}OFF${N} BADVPN puerto $p"
        fi
    done < "$PORTS_FILE"
}

ver_estado(){
    clear; linea
    echo -e "${G}ESTADO BADVPN UDPGW${N}"
    linea
    estado_corto
    linea
    echo "Sockets activos:"
    ss -ltnp 2>/dev/null | grep badvpn || echo "No hay sockets BADVPN activos"
    linea
    pausa
}

desinstalar(){
    clear; linea
    echo -e "${R}DESINSTALAR BADVPN${N}"
    linea
    read -rp "¿Eliminar BADVPN completo? [s/n]: " r
    [[ "$r" != "s" && "$r" != "S" ]] && return 0

    if [[ -f "$PORTS_FILE" ]]; then
        while read -r p; do
            [[ -n "$p" ]] && stop_port "$p"
        done < "$PORTS_FILE"
    fi

    # Limpieza segura: no usa pkill -f para no cerrar el panel.
    systemctl list-units 'badvpn-udpgw@*' --all --no-legend 2>/dev/null | awk '{print $1}' | while read -r u; do
        [[ -n "$u" ]] && systemctl stop "$u" >/dev/null 2>&1 || true
        [[ -n "$u" ]] && systemctl disable "$u" >/dev/null 2>&1 || true
    done

    rm -f "$SERVICE_TEMPLATE" "$PORTS_FILE" "$SYSCTL_FILE" "$LIMITS_FILE"
    systemctl daemon-reload >/dev/null 2>&1
    systemctl reset-failed >/dev/null 2>&1
    sysctl --system >/dev/null 2>&1 || true
    echo -e "${G}BADVPN eliminado correctamente${N}"
    pausa
}

menu(){
    root_check
    while true; do
        clear
        linea
        echo -e "${G}      BADVPN UDPGW EXTREMO SIMPLE${N}"
        echo -e "${Y}        Optimizado para juegos online${N}"
        linea
        estado_corto
        linea
        echo -e "${G}[1]${N} Instalar / Activar"
        echo -e "${G}[2]${N} Agregar puerto"
        echo -e "${G}[3]${N} Eliminar puerto"
        echo -e "${G}[4]${N} Reiniciar BADVPN"
        echo -e "${G}[5]${N} Ver estado"
        echo -e "${R}[6]${N} Desinstalar"
        echo -e "${R}[0]${N} Salir"
        linea
        read -rp "Opción: " op
        case "$op" in
            1) instalar_activar ;;
            2) agregar_puerto ;;
            3) eliminar_puerto ;;
            4) reiniciar_todo ;;
            5) ver_estado ;;
            6) desinstalar ;;
            0) exit 0 ;;
            *) echo "Opción inválida"; sleep 1 ;;
        esac
    done
}

menu
