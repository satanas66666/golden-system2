#!/bin/bash

# Golden REV26.2: ProxyGo estable + cerrar puerto + desinstalación segura.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export PATH=/usr/local/go/bin:/root/go/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games
export DEBIAN_FRONTEND=noninteractive

PROXYGO_MARKER="/etc/proxygo/.golden-installed"
PROXYGO_HASH="/etc/proxygo/.binary.sha256"

SCPdir="/etc/newadm"
SCPfrm="/etc/ger-frm"
SCPinst="/etc/ger-inst"
SCPidioma="${SCPdir}/idioma"

[[ ! -d "$SCPdir" ]] && exit 1
[[ ! -d "$SCPfrm" ]] && exit 1
[[ ! -d "$SCPinst" ]] && exit 1
[[ ! -e "$SCPidioma" ]] && touch "$SCPidioma"

type colores >/dev/null 2>&1 || colores(){ :; }
type fun_trans >/dev/null 2>&1 || fun_trans(){ echo "$1"; }
colores

declare -A cor=(
[0]="\033[1;37m"
[1]="\033[1;34m"
[2]="\033[1;31m"
[3]="\033[1;33m"
[4]="\033[1;32m"
)

linea(){ echo -e "\033[0;33m=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=×=\033[0m"; }
linea2(){ printf '%s\n' '────────────────────────────────────────'; }
clean_screen(){ clear; }

fun_bar () {
    local comando="${1:-true}"
    if declare -F golden_progress_command >/dev/null 2>&1; then
        golden_progress_command "Procesando ProxyGo" "$comando" "/tmp/proxygo_install.log"
        return $?
    fi
    eval "$comando" >"/tmp/proxygo_install.log" 2>&1
}


valid_port() {
    [[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

mportas () {
    if command -v ss >/dev/null 2>&1; then
        ss -ltnp 2>/dev/null | awk '
        NR>1 {
            n=split($4,a,":");
            port=a[n];
            proc=$0;
            name="desconocido";
            if (proc ~ /proxygo/) name="proxygo";
            else if (proc ~ /rustyproxy/) name="rustyproxy";
            else if (proc ~ /haproxy/) name="haproxyssl";
            else if (proc ~ /stunnel/) name="stunnel4";
            else if (proc ~ /sshd/) name="sshd";
            else if (proc ~ /dropbear/) name="dropbear";
            else if (proc ~ /apache2/) name="apache2";
            else if (proc ~ /badvpn/) name="badvpn-ud";
            else if (proc ~ /xray/) name="xray";
            else if (proc ~ /v2ray/) name="v2ray";
            print name" "port;
        }' | sort -u
    else
        netstat -ltnp 2>/dev/null | awk '
        NR>2 {
            n=split($4,a,":");
            port=a[n];
            print "desconocido "port;
        }' | sort -u
    fi
}

port_in_use() {
    mportas | awk '{print $2}' | grep -wq "$1"
}

proxygo_instalado() {
    [[ -x /usr/local/bin/proxygo ]] || return 1
    [[ -s "$PROXYGO_MARKER" ]] || return 1
    if [[ -s "$PROXYGO_HASH" ]] && command -v sha256sum >/dev/null 2>&1; then
        (cd / && sha256sum -c "$PROXYGO_HASH" >/dev/null 2>&1) || return 1
    fi
    if command -v timeout >/dev/null 2>&1; then
        timeout 3 /usr/local/bin/proxygo -h >/dev/null 2>&1 || return 1
    else
        /usr/local/bin/proxygo -h >/dev/null 2>&1 || return 1
    fi
    return 0
}


proxygo_servicios_activos() {
    ss -ltnp 2>/dev/null | grep -qi proxygo
}

# Lista canónica de servicios ProxyGo. Debe ser global porque la usan
# Reiniciar, Cerrar Puerto y Desinstalar.
proxygo_service_names() {
    local f name
    {
        for f in /etc/systemd/system/proxygo_*.service /lib/systemd/system/proxygo_*.service /usr/lib/systemd/system/proxygo_*.service; do
            [[ -e "$f" ]] || continue
            name="$(basename "$f" .service)"
            printf '%s\n' "$name"
        done
        for f in /etc/init.d/proxygo_*; do
            [[ -e "$f" ]] || continue
            name="$(basename "$f")"
            printf '%s\n' "$name"
        done
    } | awk 'NF && !seen[$0]++' | sort
}

proxygo_ports_configurados() {
    {
        if [[ -r /etc/proxygo/newgolden.map ]]; then
            awk -F'|' '$2 ~ /^[0-9]+$/ {print $2}' /etc/proxygo/newgolden.map 2>/dev/null || true
        fi
        proxygo_service_names 2>/dev/null | sed -n 's/^proxygo_\([0-9][0-9]*\)$/\1/p'
        if command -v ss >/dev/null 2>&1; then
            ss -ltnp 2>/dev/null | awk '/proxygo/ {n=split($4,a,":"); if (a[n] ~ /^[0-9]+$/) print a[n]}'
        fi
    } | awk '/^[0-9]+$/ && !seen[$0]++' | sort -n
}

proxygo_port_online() {
    local port="$1"
    command -v ss >/dev/null 2>&1 || return 1
    ss -ltnp 2>/dev/null | awk -v p="$port" '
        /proxygo/ {
            n=split($4,a,":");
            if (a[n] == p) found=1
        }
        END { exit(found ? 0 : 1) }
    '
}

proxygo_kill_port_processes() {
    local port="$1" pid cmd
    command -v pgrep >/dev/null 2>&1 || return 0
    for pid in $(pgrep -x proxygo 2>/dev/null || true); do
        [[ -r "/proc/$pid/cmdline" ]] || continue
        cmd="$(tr '\0' ' ' <"/proc/$pid/cmdline" 2>/dev/null || true)"
        if [[ "$cmd" == *"-listen 0.0.0.0:${port}"* || "$cmd" == *"-listen :${port}"* || "$cmd" == *"-listen [::]:${port}"* ]]; then
            kill -TERM "$pid" 2>/dev/null || true
        fi
    done
    sleep 1
    for pid in $(pgrep -x proxygo 2>/dev/null || true); do
        [[ -r "/proc/$pid/cmdline" ]] || continue
        cmd="$(tr '\0' ' ' <"/proc/$pid/cmdline" 2>/dev/null || true)"
        if [[ "$cmd" == *"-listen 0.0.0.0:${port}"* || "$cmd" == *"-listen :${port}"* || "$cmd" == *"-listen [::]:${port}"* ]]; then
            kill -KILL "$pid" 2>/dev/null || true
        fi
    done
}

proxygo_kill_all_processes() {
    local pid
    command -v pgrep >/dev/null 2>&1 || return 0
    # IMPORTANTE: -x limita el patrón al binario "proxygo" y evita matar
    # este mismo proxygo.sh, que era el fallo de REV26.1.
    for pid in $(pgrep -x proxygo 2>/dev/null || true); do
        kill -TERM "$pid" 2>/dev/null || true
    done
    sleep 1
    for pid in $(pgrep -x proxygo 2>/dev/null || true); do
        kill -KILL "$pid" 2>/dev/null || true
    done
}

reiniciar_todos_proxygo() {
    local svc
    golden_daemon_reload
    while IFS= read -r svc; do
        [[ -n "$svc" ]] || continue
        golden_service restart "$svc" >/dev/null 2>&1 || true
    done < <(proxygo_service_names)
}

mostrar_proxygo_activos() {
    linea
    echo -e "        ${cor[3]}PROXYGO - NEW GOLDEN${cor[0]}"
    linea2

    if proxygo_instalado; then
        echo -e "   ${cor[4]}[INSTALADO]${cor[0]} ProxyGo verificado"
    elif [[ -e /usr/local/bin/proxygo || -d /etc/proxygo ]]; then
        echo -e "   ${cor[3]}[INCOMPLETO]${cor[0]} Hay restos de una instalación anterior; usa [1] para reparar"
    else
        echo -e "   ${cor[2]}[DESINSTALADO]${cor[0]} ProxyGo no esta instalado"
    fi

    if proxygo_servicios_activos; then
        ss -ltnp 2>/dev/null | grep -i proxygo | awk '{
            split($4,a,":");
            print "   [ONLINE] Puerto ProxyGo : " a[length(a)];
        }'
    else
        echo -e "   ${cor[2]}[OFFLINE]${cor[0]} No hay puertos ProxyGo activos"
    fi
}


migrar_proxygo_legacy() {
    # REV26: no copiar automáticamente un binario legado. Ese comportamiento
    # podía marcar ProxyGo como instalado aunque la instalación anterior fuese
    # incompleta. Los restos viejos se conservan y la opción [1] los reemplaza
    # por un binario canónico verificado.
    return 0
}


migrar_proxygo_legacy

instalar_go_proxygo() {
    command -v go >/dev/null 2>&1 && return 0
    if golden_pkg_available golang-go; then
        golden_apt_install golang-go || return 1
        command -v go >/dev/null 2>&1 && return 0
    fi
    local arch goarch ver=1.20.14 tmp=/tmp/golden-go.tgz
    arch="$(uname -m)"
    case "$arch" in
        x86_64|amd64) goarch=amd64 ;;
        aarch64|arm64) goarch=arm64 ;;
        armv7l|armv6l) goarch=armv6l ;;
        *) echo "Arquitectura no soportada por Go: $arch"; return 1 ;;
    esac
    golden_fetch "https://go.dev/dl/go${ver}.linux-${goarch}.tar.gz" "$tmp" || return 1
    rm -rf /usr/local/go
    tar -C /usr/local -xzf "$tmp" || { rm -f "$tmp"; return 1; }
    rm -f "$tmp"
    export PATH=/usr/local/go/bin:$PATH
    command -v go >/dev/null 2>&1
}

instalar_base_proxygo() {
    golden_apt_update || return 1
    golden_install_required curl wget lsof ca-certificates || return 1
    golden_install_iproute || return 1
    golden_install_available net-tools procps || true
    instalar_go_proxygo || return 1
}

optimizar_proxygo() {
    mkdir -p /etc/sysctl.d
    mkdir -p /etc/security/limits.d
    mkdir -p /etc/systemd/system.conf.d
    mkdir -p /etc/systemd/user.conf.d

cat >/etc/sysctl.d/99-newgolden-proxygo.conf <<'EOF'
fs.file-max = 2097152
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.tcp_fin_timeout = 10
net.ipv4.tcp_keepalive_time = 120
net.ipv4.tcp_keepalive_intvl = 20
net.ipv4.tcp_keepalive_probes = 5
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_slow_start_after_idle = 0
net.core.default_qdisc = fq
net.ipv4.tcp_congestion_control = bbr
EOF

    sysctl --system >/dev/null 2>&1

cat >/etc/security/limits.d/99-newgolden-proxygo.conf <<'EOF'
* soft nofile 1048576
* hard nofile 1048576
root soft nofile 1048576
root hard nofile 1048576
EOF

cat >/etc/systemd/system.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

cat >/etc/systemd/user.conf.d/99-newgolden.conf <<'EOF'
[Manager]
DefaultLimitNOFILE=1048576
DefaultTasksMax=infinity
EOF

    golden_daemon_reload
}

compilar_proxygo() {
    export PATH=/usr/local/go/bin:/root/go/bin:$PATH
    mkdir -p /opt/newgolden-proxygo
    mkdir -p /etc/proxygo

cat >/opt/newgolden-proxygo/main.go <<'EOF'
package main

import (
	"flag"
	"fmt"
	"io"
	"net"
	"time"
)

func handle(client net.Conn, target string, banner string) {
	defer client.Close()

	if tcp, ok := client.(*net.TCPConn); ok {
		_ = tcp.SetNoDelay(true)
		_ = tcp.SetKeepAlive(true)
		_ = tcp.SetKeepAlivePeriod(60 * time.Second)
	}

	if banner == "" {
		banner = "OK"
	}

	// Primera respuesta fija
	_, _ = client.Write([]byte("HTTP/1.1 101 Connection Established\r\n\r\n"))

	// Leer y tirar payload inicial para que NO llegue al SSH
	client.SetReadDeadline(time.Now().Add(3 * time.Second))
	buffer := make([]byte, 1024)
	_, _ = client.Read(buffer)
	client.SetReadDeadline(time.Time{})

	// Aquí aparece el banner
	_, _ = client.Write([]byte(fmt.Sprintf("HTTP/1.1 200 %s\r\n\r\n", banner)))

	server, err := net.DialTimeout("tcp", target, 10*time.Second)
	if err != nil {
		return
	}
	defer server.Close()

	if tcp, ok := server.(*net.TCPConn); ok {
		_ = tcp.SetNoDelay(true)
		_ = tcp.SetKeepAlive(true)
		_ = tcp.SetKeepAlivePeriod(60 * time.Second)
	}

	done := make(chan struct{}, 2)

	go func() {
		_, _ = io.Copy(server, client)
		done <- struct{}{}
	}()

	go func() {
		_, _ = io.Copy(client, server)
		done <- struct{}{}
	}()

	<-done
}

func main() {
	listen := flag.String("listen", "0.0.0.0:80", "listen address")
	target := flag.String("target", "127.0.0.1:22", "target address")
	banner := flag.String("banner", "OK", "banner en respuesta 200")
	flag.Parse()

	ln, err := net.Listen("tcp", *listen)
	if err != nil {
		panic(err)
	}

	fmt.Println("ProxyGo ONLINE", *listen, "->", *target, "BANNER:", *banner)

	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go handle(conn, *target, *banner)
	}
}
EOF

    cd /opt/newgolden-proxygo || return 1
    rm -f "$PROXYGO_MARKER" "$PROXYGO_HASH" 2>/dev/null || true
    golden_run_timeout 300 go build -ldflags="-s -w" -o /usr/local/bin/proxygo main.go || return 1
    chmod +x /usr/local/bin/proxygo
    if command -v timeout >/dev/null 2>&1; then
        timeout 3 /usr/local/bin/proxygo -h >/dev/null 2>&1 || return 1
    else
        /usr/local/bin/proxygo -h >/dev/null 2>&1 || return 1
    fi
    mkdir -p /etc/proxygo
    if command -v sha256sum >/dev/null 2>&1; then
        (cd / && sha256sum usr/local/bin/proxygo >"$PROXYGO_HASH") || return 1
    fi
    printf 'REV26.2 %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" >"$PROXYGO_MARKER"
}

crear_servicio_proxygo() {
    local nombre="$1" puerto_entrada="$2" puerto_local="$3" banner="$4"
    [[ -z "$banner" ]] && banner="OK"

    mkdir -p /etc/proxygo
    touch /etc/proxygo/newgolden.map
    grep -v "|${puerto_entrada}|" /etc/proxygo/newgolden.map > /tmp/proxygo.map 2>/dev/null || true
    mv -f /tmp/proxygo.map /etc/proxygo/newgolden.map 2>/dev/null || true
    echo "${nombre}|${puerto_entrada}|${puerto_local}|${banner}" >> /etc/proxygo/newgolden.map

    if golden_has_systemd; then
        cat >/etc/systemd/system/proxygo_${puerto_entrada}.service <<EOF
[Unit]
Description=ProxyGo NEW GOLDEN ${puerto_entrada} to ${puerto_local}
After=network.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/proxygo -listen 0.0.0.0:${puerto_entrada} -target 127.0.0.1:${puerto_local} -banner "${banner}"
Restart=always
RestartSec=2
LimitNOFILE=1048576
LimitNPROC=1048576
KillSignal=SIGTERM
TimeoutStartSec=15
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
EOF
        golden_daemon_reload
        golden_service_enable "proxygo_${puerto_entrada}.service" >/dev/null 2>&1 || true
    else
        cat >/etc/init.d/proxygo_${puerto_entrada} <<EOF
#!/bin/sh
### BEGIN INIT INFO
# Provides: proxygo_${puerto_entrada}
# Required-Start: \$network \$remote_fs
# Required-Stop: \$network \$remote_fs
# Default-Start: 2 3 4 5
# Default-Stop: 0 1 6
### END INIT INFO
PID=/var/run/proxygo_${puerto_entrada}.pid
case "\$1" in
 start)
   [ -f "\$PID" ] && kill -0 "\$(cat "\$PID")" 2>/dev/null && exit 0
   nohup /usr/local/bin/proxygo -listen 0.0.0.0:${puerto_entrada} -target 127.0.0.1:${puerto_local} -banner "${banner}" >/var/log/proxygo_${puerto_entrada}.log 2>&1 &
   echo \$! >"\$PID" ;;
 stop)
   [ -f "\$PID" ] && kill "\$(cat "\$PID")" 2>/dev/null || true
   rm -f "\$PID" ;;
 restart) "\$0" stop; sleep 1; "\$0" start ;;
 status) [ -f "\$PID" ] && kill -0 "\$(cat "\$PID")" 2>/dev/null ;;
 *) echo "Uso: \$0 {start|stop|restart|status}"; exit 2 ;;
esac
EOF
        chmod 0755 /etc/init.d/proxygo_${puerto_entrada}
        command -v update-rc.d >/dev/null 2>&1 && update-rc.d proxygo_${puerto_entrada} defaults >/dev/null 2>&1 || true
    fi
}

restart_proxygo_service() {
    local puerto_check svc
    puerto_check="$1"
    svc="proxygo_${puerto_check}"
    golden_daemon_reload
    golden_service restart "$svc" >/tmp/proxygo_test.log 2>&1 || true
    sleep 2
    if ss -ltnp 2>/dev/null | grep -q ":${puerto_check} "; then return 0; fi
    echo "ERROR REAL DE PROXYGO:"
    cat /tmp/proxygo_test.log 2>/dev/null || true
    golden_has_systemd && systemctl status "${svc}.service" --no-pager -l 2>/dev/null || true
    return 1
}

instalar_proxygo_core() {
    rm -f "$PROXYGO_MARKER" "$PROXYGO_HASH" 2>/dev/null || true
    instalar_base_proxygo || return 1
    optimizar_proxygo
    compilar_proxygo || return 1
    proxygo_instalado || return 1
}

pedir_datos_puerto() {
    local titulo="$1"

    clean_screen
    echo "$titulo"
    linea
    echo "Seleccione un puerto interno abierto"
    echo "Ejemplo: 22 OpenSSH, 80 Proxy, 53 Dropbear, 1194 OpenVPN"
    linea

    while true; do
        read -p "Local-Port: " portx
        valid_port "$portx" || { echo "Puerto invalido"; continue; }

        if port_in_use "$portx"; then
            break
        else
            echo "Ese puerto interno no esta abierto"
        fi
    done

    linea
    echo "Que puerto desea abrir como ProxyGo"
    linea

    while true; do
        read -p "Listen-ProxyGo: " GOPORT
        valid_port "$GOPORT" || { echo "Puerto invalido"; continue; }

        if port_in_use "$GOPORT"; then
            echo "Este puerto ya esta en uso"
        else
            break
        fi
    done

    linea
    echo "Banner que aparecera en HTTP/1.1 200"
    echo "Ejemplo: OK, NewGolden, Cloudflare, Connection Established"
    linea
    read -p "Banner [OK]: " BANNER
    BANNER="${BANNER:-OK}"
}

abrir_puerto_proxygo () {
pedir_datos_puerto "ABRIR PUERTO PROXYGO"

if ! proxygo_instalado; then
    linea
    echo "ProxyGo no esta instalado."
    echo "Primero usa la opcion [1] INSTALAR PROXYGO"
    linea
    read -p "Presiona ENTER para continuar..."
    return 1
fi

linea
echo "Abriendo puerto ProxyGo"
linea

crear_servicio_proxygo "proxygo_${GOPORT}" "$GOPORT" "$portx" "$BANNER"

if restart_proxygo_service "$GOPORT"; then
    linea
    echo "INSTALADO CON EXITO"
    echo "ProxyGo: ${GOPORT} -> LOCAL: ${portx}"
    echo "Banner 200: ${BANNER}"
    linea
else
    linea
    echo "ERROR: ProxyGo no pudo iniciar"
    echo "cat /tmp/proxygo_test.log"
    echo "systemctl status proxygo_${GOPORT}"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

agregar_puerto_proxygo () {
pedir_datos_puerto "AGREGAR MAS PUERTOS PROXYGO"

if ! proxygo_instalado; then
    linea
    echo "ProxyGo no esta instalado."
    echo "Primero usa la opcion [1] INSTALAR PROXYGO"
    linea
    read -p "Presiona ENTER para continuar..."
    return 1
fi

linea
echo "Agregando puerto ProxyGo"
linea

crear_servicio_proxygo "proxygo_${GOPORT}" "$GOPORT" "$portx" "$BANNER"

if restart_proxygo_service "$GOPORT"; then
    linea
    echo "AGREGADO CON EXITO"
    echo "ProxyGo: ${GOPORT} -> LOCAL: ${portx}"
    echo "Banner 200: ${BANNER}"
    linea
else
    linea
    echo "ERROR: ProxyGo no pudo iniciar"
    echo "cat /tmp/proxygo_test.log"
    echo "systemctl status proxygo_${GOPORT}"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

reiniciar_proxygo_all () {
clean_screen
echo "REINICIAR PROXYGO"
linea

if fun_bar "reiniciar_todos_proxygo"; then
    linea
    echo "PROXYGO REINICIADO"
    linea
else
    linea
    echo "ERROR: No se pudieron reiniciar todos los puertos ProxyGo"
    echo "Revisa: /tmp/proxygo_install.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

cerrar_puerto_proxygo () {
clean_screen
echo "CERRAR PUERTO PROXYGO"
linea

local ports port svc tmp
ports="$(proxygo_ports_configurados)"
if [[ -z "$ports" ]]; then
    echo "No hay puertos ProxyGo configurados."
    linea
    read -p "Presiona ENTER para continuar..."
    return 0
fi

echo "Puertos ProxyGo configurados:"
while IFS= read -r port; do
    [[ -n "$port" ]] || continue
    if proxygo_port_online "$port"; then
        printf '  - %s  [ONLINE]\n' "$port"
    else
        printf '  - %s  [OFFLINE]\n' "$port"
    fi
done <<< "$ports"
linea

while true; do
    read -p "Puerto ProxyGo a cerrar [0 cancelar]: " port
    [[ "$port" == "0" ]] && return 0
    valid_port "$port" || { echo "Puerto invalido"; continue; }
    if printf '%s\n' "$ports" | grep -wxq "$port"; then
        break
    fi
    echo "Ese puerto no pertenece a ProxyGo."
done

svc="proxygo_${port}"
golden_service stop "$svc" >/dev/null 2>&1 || true
golden_service_disable "$svc" >/dev/null 2>&1 || true
proxygo_kill_port_processes "$port"

rm -f "/etc/systemd/system/${svc}.service" "/lib/systemd/system/${svc}.service" "/usr/lib/systemd/system/${svc}.service"
rm -f "/etc/init.d/${svc}" "/var/run/${svc}.pid" "/var/log/${svc}.log"
rm -f "/etc/systemd/system/multi-user.target.wants/${svc}.service" 2>/dev/null || true

if [[ -f /etc/proxygo/newgolden.map ]]; then
    tmp="$(mktemp /tmp/proxygo-map.XXXXXX)" || tmp="/tmp/proxygo-map.$$"
    awk -F'|' -v p="$port" '$2 != p' /etc/proxygo/newgolden.map >"$tmp" 2>/dev/null || true
    cat "$tmp" > /etc/proxygo/newgolden.map
    rm -f "$tmp"
fi

golden_daemon_reload
sleep 1

linea
if proxygo_port_online "$port"; then
    echo "ERROR: ProxyGo todavía aparece escuchando en el puerto $port"
    echo "No se eliminó el núcleo ProxyGo; solo falló el cierre de este puerto."
else
    echo "PUERTO PROXYGO $port CERRADO CORRECTAMENTE"
    echo "El núcleo ProxyGo permanece instalado."
fi
linea
read -p "Presiona ENTER para continuar..."
return 0
}

detener_proxygo () {
clean_screen
echo "DESINSTALAR PROXYGO"
linea
echo "Esta opcion eliminara ProxyGo completo"
echo "Servicios, binario, proyecto y configuraciones"
linea

read -p "¿Deseas continuar? [s/n]: " confirmgo
[[ "$confirmgo" != "s" && "$confirmgo" != "S" ]] && return 0

linea
echo "DESINSTALANDO PROXYGO COMPLETAMENTE"
linea

desinstalar_proxygo_completo() {
    local svc

    while IFS= read -r svc; do
        [[ -n "$svc" ]] || continue
        golden_service stop "$svc" >/dev/null 2>&1 || true
        golden_service_disable "$svc" >/dev/null 2>&1 || true
    done < <(proxygo_service_names)

    # Nunca usar un pkill genérico: podía matar proxygo.sh. Solo procesos cuyo
    # nombre exacto es el binario ProxyGo.
    proxygo_kill_all_processes

    rm -f /etc/systemd/system/proxygo_*.service /lib/systemd/system/proxygo_*.service /usr/lib/systemd/system/proxygo_*.service
    rm -f /etc/systemd/system/multi-user.target.wants/proxygo_*.service 2>/dev/null || true
    rm -f /etc/init.d/proxygo_*
    rm -f /var/run/proxygo_*.pid /var/log/proxygo_*.log
    rm -rf /etc/proxygo /opt/newgolden-proxygo
    rm -f /usr/local/bin/proxygo /tmp/proxygo_test.log /tmp/proxygo_install.log
    rm -f /etc/sysctl.d/99-newgolden-proxygo.conf /etc/security/limits.d/99-newgolden-proxygo.conf

    golden_daemon_reload
    if golden_has_systemd && command -v systemctl >/dev/null 2>&1; then
        golden_run_timeout 15 systemctl reset-failed >/dev/null 2>&1 || true
    fi

    # Verificación real antes de anunciar éxito.
    [[ ! -e /usr/local/bin/proxygo ]] || return 1
    [[ ! -d /etc/proxygo ]] || return 1
    [[ ! -d /opt/newgolden-proxygo ]] || return 1
    compgen -G '/etc/systemd/system/proxygo_*.service' >/dev/null && return 1
    compgen -G '/etc/init.d/proxygo_*' >/dev/null && return 1
    if command -v pgrep >/dev/null 2>&1 && pgrep -x proxygo >/dev/null 2>&1; then
        return 1
    fi
    return 0
}

if fun_bar "desinstalar_proxygo_completo"; then
    linea
    echo "PROXYGO ELIMINADO COMPLETAMENTE"
    echo "Binario, servicios, puertos y configuración fueron verificados como eliminados."
    echo "Puedes volver a instalar ProxyGo limpio sin errores"
    linea
else
    linea
    echo "ERROR: La desinstalación de ProxyGo no terminó completamente."
    echo "No se mostrará un falso mensaje de éxito."
    echo "Revisa: /tmp/proxygo_install.log"
    linea
fi

read -p "Presiona ENTER para continuar..."
return 0
}

gestor_fun () {
while true; do
clean_screen
mostrar_proxygo_activos

linea
echo -e "        ${cor[3]}ADMINISTRADOR PROXYGO${cor[0]}"
echo -e "        ${cor[2]}NEW-GOLDEN ADM PRO${cor[0]}"
linea2
echo -e "   ${cor[2]}[1]${cor[0]}  INSTALAR PROXYGO"
echo -e "   ${cor[2]}[2]${cor[0]}  ABRIR PUERTO PROXYGO"
echo -e "   ${cor[2]}[3]${cor[0]}  AGREGAR MAS PUERTOS PROXYGO"
echo -e "   ${cor[2]}[4]${cor[0]}  CERRAR PUERTO PROXYGO"
echo -e "   ${cor[2]}[5]${cor[0]}  REINICIAR PROXYGO"
echo -e "   ${cor[2]}[6]${cor[0]}  ${cor[2]}DESINSTALAR PROXYGO${cor[0]}"
echo -e "   ${cor[2]}[0]${cor[0]}  ${cor[2]}VOLVER${cor[0]}"
linea

opx=""
while [[ ! "$opx" =~ ^[0-6]$ ]]; do
    echo -ne "   ${cor[3]}Selecciona una opcion:${cor[0]} "
    read opx
done

case "$opx" in
    0) return ;;
    1)
        clean_screen
        echo "INSTALAR PROXYGO"
        linea
        if fun_bar "instalar_proxygo_core" && proxygo_instalado; then
            linea
            echo "PROXYGO INSTALADO Y VERIFICADO"
        else
            linea
            echo "ERROR: ProxyGo no quedó instalado."
            echo "Revisa: /tmp/proxygo_install.log"
            rm -f "$PROXYGO_MARKER" "$PROXYGO_HASH" 2>/dev/null || true
        fi
        read -p "Presiona ENTER para continuar..."
    ;;
    2) abrir_puerto_proxygo ;;
    3) agregar_puerto_proxygo ;;
    4) cerrar_puerto_proxygo ;;
    5) reiniciar_proxygo_all ;;
    6) detener_proxygo ;;
esac
done
}

gestor_fun
