#!/usr/bin/env bash
# Golden System PRO REV25 - capa común de compatibilidad / NO-HANG + init legacy.
# Ubuntu y Debian basados en APT (Bash 4+). No modifica el sistema al cargarse.

[[ "${GOLDEN_COMPAT_LOADED:-0}" == "1" ]] && return 0 2>/dev/null || true
GOLDEN_COMPAT_LOADED=1

export PATH=/usr/local/go/bin:/root/go/bin:/root/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a
export NEEDRESTART_SUSPEND=1
export APT_LISTCHANGES_FRONTEND=none
export UCF_FORCE_CONFFOLD=1
export GIT_TERMINAL_PROMPT=0
export SYSTEMD_PAGER=cat
export SYSTEMD_COLORS=0

# Capturar binarios reales antes de crear wrappers con esos nombres.
GOLDEN_APT_GET_BIN="$(type -P apt-get 2>/dev/null || true)"
GOLDEN_APT_BIN="$(type -P apt 2>/dev/null || true)"
GOLDEN_CURL_BIN="$(type -P curl 2>/dev/null || true)"
GOLDEN_WGET_BIN="$(type -P wget 2>/dev/null || true)"
GOLDEN_GIT_BIN="$(type -P git 2>/dev/null || true)"
GOLDEN_TIMEOUT_BIN="$(type -P timeout 2>/dev/null || true)"
GOLDEN_SYSTEMCTL_BIN="$(type -P systemctl 2>/dev/null || true)"
GOLDEN_SERVICE_BIN="$(type -P service 2>/dev/null || true)"

GOLDEN_STATE_DIR="${GOLDEN_STATE_DIR:-/var/cache/golden}"
GOLDEN_APT_STAMP="$GOLDEN_STATE_DIR/apt-update.stamp"
GOLDEN_APT_CACHE_MINUTES="${GOLDEN_APT_CACHE_MINUTES:-30}"
GOLDEN_APT_LOCK_WAIT="${GOLDEN_APT_LOCK_WAIT:-600}"
GOLDEN_APT_STEP_TIMEOUT="${GOLDEN_APT_STEP_TIMEOUT:-900}"
GOLDEN_PROTOCOL_STEP_TIMEOUT="${GOLDEN_PROTOCOL_STEP_TIMEOUT:-900}"
GOLDEN_NET_CONNECT_TIMEOUT="${GOLDEN_NET_CONNECT_TIMEOUT:-10}"
GOLDEN_NET_TOTAL_TIMEOUT="${GOLDEN_NET_TOTAL_TIMEOUT:-180}"
mkdir -p "$GOLDEN_STATE_DIR" 2>/dev/null || true

golden_os_load() {
    GOLDEN_OS_ID=unknown GOLDEN_OS_VERSION=0 GOLDEN_OS_CODENAME="" GOLDEN_OS_PRETTY=""
    if [[ -r /etc/os-release ]]; then
        # shellcheck disable=SC1091
        . /etc/os-release
        GOLDEN_OS_ID="${ID:-unknown}"
        GOLDEN_OS_VERSION="${VERSION_ID:-0}"
        GOLDEN_OS_CODENAME="${VERSION_CODENAME:-${UBUNTU_CODENAME:-}}"
        GOLDEN_OS_PRETTY="${PRETTY_NAME:-$GOLDEN_OS_ID $GOLDEN_OS_VERSION}"
    elif [[ -r /etc/lsb-release ]]; then
        # shellcheck disable=SC1091
        . /etc/lsb-release
        GOLDEN_OS_ID=ubuntu
        GOLDEN_OS_VERSION="${DISTRIB_RELEASE:-0}"
        GOLDEN_OS_CODENAME="${DISTRIB_CODENAME:-}"
        GOLDEN_OS_PRETTY="${DISTRIB_DESCRIPTION:-Ubuntu $GOLDEN_OS_VERSION}"
    elif [[ -r /etc/debian_version ]]; then
        GOLDEN_OS_ID=debian
        GOLDEN_OS_VERSION="$(cut -d/ -f1 /etc/debian_version | sed 's/[^0-9.].*$//')"
        GOLDEN_OS_PRETTY="Debian $GOLDEN_OS_VERSION"
    fi
    GOLDEN_OS_ID="${GOLDEN_OS_ID,,}"
    GOLDEN_ARCH="$(dpkg --print-architecture 2>/dev/null || uname -m)"
}

golden_os_supported() {
    case "$GOLDEN_OS_ID" in ubuntu|debian) return 0 ;; *) return 1 ;; esac
}

golden_has_systemd() {
    [[ -n "$GOLDEN_SYSTEMCTL_BIN" && -x "$GOLDEN_SYSTEMCTL_BIN" && -d /run/systemd/system ]]
}

golden_run_timeout() {
    local seconds="$1"; shift
    if [[ -n "$GOLDEN_TIMEOUT_BIN" && -x "$GOLDEN_TIMEOUT_BIN" ]]; then
        "$GOLDEN_TIMEOUT_BIN" --foreground -k 10 "$seconds" "$@"
        return $?
    fi

    # Fallback para distribuciones antiguas donde coreutils no aporta timeout.
    local pid watchdog rc=0 timed=""
    timed="$(mktemp /tmp/golden-timeout.XXXXXX 2>/dev/null || printf '/tmp/golden-timeout.%s' "$$")"
    rm -f "$timed" 2>/dev/null || true
    "$@" &
    pid=$!
    (
        sleep "$seconds"
        if kill -0 "$pid" 2>/dev/null; then
            : >"$timed"
            golden_kill_tree "$pid"
        fi
    ) &
    watchdog=$!
    wait "$pid" || rc=$?
    kill "$watchdog" 2>/dev/null || true
    wait "$watchdog" 2>/dev/null || true
    if [[ -e "$timed" ]]; then rc=124; fi
    rm -f "$timed" 2>/dev/null || true
    return "$rc"
}

golden_has_legacy_init() {
    [[ -d /etc/init.d ]] || return 1
    [[ -n "$GOLDEN_SERVICE_BIN" && -x "$GOLDEN_SERVICE_BIN" ]] || command -v update-rc.d >/dev/null 2>&1 || return 1
    return 0
}

golden_service_manager_available() {
    golden_has_systemd || golden_has_legacy_init
}

golden_unit_path() {
    local name="${1%.service}" base instance=""
    base="$name"
    if [[ "$base" == *@* && "$base" != *@ ]]; then
        instance="${base#*@}"
        base="${base%@*}@"
    fi
    local f
    for f in \
        "/etc/systemd/system/${name}.service" \
        "/usr/lib/systemd/system/${name}.service" \
        "/lib/systemd/system/${name}.service" \
        "/etc/systemd/system/${base}.service" \
        "/usr/lib/systemd/system/${base}.service" \
        "/lib/systemd/system/${base}.service"; do
        [[ -f "$f" ]] && { printf '%s\n' "$f"; return 0; }
    done
    return 1
}

golden_shell_quote() {
    local x="$1"
    x=${x//\'/\'\\\'\'}
    printf "'%s'" "$x"
}

golden_legacy_ensure_from_unit() {
    local raw="${1%.service}" unit exec wd="/" init pidlog safe instance=""
    [[ -x "/etc/init.d/$raw" ]] && return 0
    unit="$(golden_unit_path "$raw" 2>/dev/null || true)"
    [[ -n "$unit" ]] || return 1
    exec="$(awk -F= '/^[[:space:]]*ExecStart=/{sub(/^[^=]*=/,""); print; exit}' "$unit")"
    wd="$(awk -F= '/^[[:space:]]*WorkingDirectory=/{sub(/^[^=]*=/,""); print; exit}' "$unit")"
    [[ -n "$wd" ]] || wd="/"
    if [[ "$raw" == *@* ]]; then instance="${raw#*@}"; exec="${exec//%i/$instance}"; wd="${wd//%i/$instance}"; fi
    [[ -n "$exec" ]] || return 1
    mkdir -p /etc/init.d /var/run /var/log
    safe="$(printf '%s' "$raw" | tr -c 'A-Za-z0-9_.@-' '_')"
    init="/etc/init.d/$raw"
    pidlog="/var/run/${safe}.pid"
    cat >"$init" <<EOF_GOLDEN_INIT
#!/bin/sh
### BEGIN INIT INFO
# Provides:          $raw
# Required-Start:    \$network \$remote_fs
# Required-Stop:     \$network \$remote_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Golden compatibility service $raw
### END INIT INFO
PIDFILE=$(golden_shell_quote "$pidlog")
LOGFILE=$(golden_shell_quote "/var/log/${safe}.log")
WORKDIR=$(golden_shell_quote "$wd")
EXEC=$(golden_shell_quote "$exec")
case "\$1" in
  start)
    if [ -s "\$PIDFILE" ]; then P=\$(cat "\$PIDFILE" 2>/dev/null); kill -0 "\$P" 2>/dev/null && exit 0; fi
    rm -f "\$PIDFILE"
    [ -d "\$WORKDIR" ] && cd "\$WORKDIR"
    nohup /bin/sh -c "\$EXEC" >>"\$LOGFILE" 2>&1 &
    echo \$! >"\$PIDFILE"
    sleep 1
    P=\$(cat "\$PIDFILE" 2>/dev/null); kill -0 "\$P" 2>/dev/null
    ;;
  stop)
    if [ -s "\$PIDFILE" ]; then
      P=\$(cat "\$PIDFILE" 2>/dev/null)
      kill "\$P" 2>/dev/null || true
      I=0; while kill -0 "\$P" 2>/dev/null && [ \$I -lt 5 ]; do sleep 1; I=\$((I+1)); done
      kill -9 "\$P" 2>/dev/null || true
    fi
    rm -f "\$PIDFILE"
    ;;
  restart) "\$0" stop; "\$0" start ;;
  reload) "\$0" restart ;;
  status)
    [ -s "\$PIDFILE" ] || exit 3
    P=\$(cat "\$PIDFILE" 2>/dev/null); kill -0 "\$P" 2>/dev/null
    ;;
  *) echo "Uso: \$0 {start|stop|restart|reload|status}"; exit 2 ;;
esac
EOF_GOLDEN_INIT
    chmod 0755 "$init"
    return 0
}

golden_service() {
    local action="$1" name="${2%.service}"
    if golden_has_systemd; then
        golden_run_timeout 45 "$GOLDEN_SYSTEMCTL_BIN" "$action" "$name"
        return $?
    fi
    [[ -x "/etc/init.d/$name" ]] || golden_legacy_ensure_from_unit "$name" >/dev/null 2>&1 || true
    if [[ -n "$GOLDEN_SERVICE_BIN" && -x "$GOLDEN_SERVICE_BIN" && -x "/etc/init.d/$name" ]]; then
        golden_run_timeout 45 "$GOLDEN_SERVICE_BIN" "$name" "$action"
    elif [[ -x "/etc/init.d/$name" ]]; then
        golden_run_timeout 45 "/etc/init.d/$name" "$action"
    else
        case "$action" in stop|disable) return 0 ;; *) return 1 ;; esac
    fi
}

golden_service_enable() {
    local name="${1%.service}"
    if golden_has_systemd; then
        golden_run_timeout 45 "$GOLDEN_SYSTEMCTL_BIN" enable "$name"
    else
        [[ -x "/etc/init.d/$name" ]] || golden_legacy_ensure_from_unit "$name" >/dev/null 2>&1 || true
        if command -v update-rc.d >/dev/null 2>&1 && [[ -x "/etc/init.d/$name" ]]; then
            update-rc.d "$name" defaults >/dev/null 2>&1 || true
        fi
        [[ -x "/etc/init.d/$name" ]]
    fi
}

golden_service_disable() {
    local name="${1%.service}"
    if golden_has_systemd; then
        golden_run_timeout 45 "$GOLDEN_SYSTEMCTL_BIN" disable "$name"
    elif command -v update-rc.d >/dev/null 2>&1 && [[ -x "/etc/init.d/$name" ]]; then
        update-rc.d -f "$name" remove >/dev/null 2>&1 || true
        return 0
    else
        return 0
    fi
}

golden_service_active() {
    local name="${1%.service}"
    if golden_has_systemd; then
        "$GOLDEN_SYSTEMCTL_BIN" is-active --quiet "$name"
    else
        [[ -x "/etc/init.d/$name" ]] || golden_legacy_ensure_from_unit "$name" >/dev/null 2>&1 || true
        if [[ -n "$GOLDEN_SERVICE_BIN" && -x "$GOLDEN_SERVICE_BIN" && -x "/etc/init.d/$name" ]]; then
            "$GOLDEN_SERVICE_BIN" "$name" status >/dev/null 2>&1
        elif [[ -x "/etc/init.d/$name" ]]; then
            "/etc/init.d/$name" status >/dev/null 2>&1
        else
            pgrep -x "${name%.service}" >/dev/null 2>&1
        fi
    fi
}

golden_daemon_reload() {
    golden_has_systemd && golden_run_timeout 30 "$GOLDEN_SYSTEMCTL_BIN" daemon-reload >/dev/null 2>&1 || true
}

# Conserva el nombre histórico para no romper módulos, pero acepta init.d.
golden_require_systemd() {
    golden_service_manager_available && return 0
    printf 'Este módulo requiere systemd o un init compatible (SysV/init.d).\n' >&2
    return 1
}

golden_systemctl_legacy() {
    local action="${1:-}"; shift || true
    local name="" a pattern=""
    case "$action" in
        daemon-reload|reset-failed) return 0 ;;
        mask|unmask) return 0 ;;
        list-unit-files)
            for a in "$@"; do [[ "$a" == -* ]] || { pattern="$a"; break; }; done
            [[ -n "$pattern" ]] || pattern='*'
            pattern="${pattern%.service}"
            local f n found=1
            for f in /etc/init.d/$pattern /etc/systemd/system/${pattern}.service /lib/systemd/system/${pattern}.service /usr/lib/systemd/system/${pattern}.service; do
                [[ -e "$f" ]] || continue
                n="${f##*/}"; n="${n%.service}"
                printf '%s.service enabled\n' "$n"
                found=0
            done
            return "$found"
            ;;
        list-units)
            for a in "$@"; do [[ "$a" == -* ]] || { pattern="$a"; break; }; done
            [[ -n "$pattern" ]] || pattern='*'
            pattern="${pattern%.service}"
            local f n
            for f in /etc/init.d/$pattern /etc/systemd/system/${pattern}.service; do
                [[ -e "$f" ]] || continue
                n="${f##*/}"; n="${n%.service}"
                if golden_service_active "$n"; then printf '%s.service loaded active running Golden legacy service\n' "$n"; fi
            done
            return 0
            ;;
        is-active|is-enabled|status|start|stop|restart|reload|enable|disable)
            for a in "$@"; do [[ "$a" == -* ]] || { name="$a"; break; }; done
            [[ -n "$name" ]] || return 1
            name="${name%.service}"
            case "$action" in
                is-active|status) golden_service_active "$name" ;;
                is-enabled) [[ -x "/etc/init.d/$name" ]] || golden_legacy_ensure_from_unit "$name" >/dev/null 2>&1 ;;
                enable) golden_service_enable "$name" ;;
                disable) golden_service_disable "$name" ;;
                *) golden_service "$action" "$name" ;;
            esac
            ;;
        *) return 1 ;;
    esac
}

golden_apt_lock_pids() {
    local -a locks=(/var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock /var/cache/apt/archives/lock)
    if command -v fuser >/dev/null 2>&1; then
        fuser "${locks[@]}" 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9]+$' | sort -un || true
    elif command -v lsof >/dev/null 2>&1; then
        lsof -t -- "${locks[@]}" 2>/dev/null | sort -un || true
    fi
}

golden_apt_wait() {
    local waited=0 max="${1:-$GOLDEN_APT_LOCK_WAIT}" pids="" last=""
    while :; do
        pids="$(golden_apt_lock_pids | tr '\n' ' ' | sed 's/[[:space:]]*$//')"
        [[ -z "$pids" ]] && { (( waited > 0 )) && printf '\n' >&2; return 0; }
        if [[ "$pids" != "$last" || $waited -eq 0 ]]; then
            printf '\n[APT] Lock real ocupado. PID(s): %s\n' "$pids" >&2
            ps -o pid=,stat=,etime=,comm= -p ${pids// /,} 2>/dev/null >&2 || true
            last="$pids"
        fi
        printf '\r[APT] esperando %ss / %ss ...' "$waited" "$max" >&2
        sleep 2
        waited=$((waited + 2))
        (( waited < max )) || { printf '\n[APT] ERROR: lock ocupado después de %ss.\n' "$max" >&2; return 1; }
    done
}

# Alias de compatibilidad para módulos de revisiones anteriores.
golden_wait_apt() { golden_apt_wait "$@"; }

golden_apt_stamp_fresh() {
    [[ -f "$GOLDEN_APT_STAMP" ]] || return 1
    find "$GOLDEN_APT_STAMP" -mmin "-$GOLDEN_APT_CACHE_MINUTES" -print -quit 2>/dev/null | grep -q .
}

golden_ubuntu_archived() {
    case "$GOLDEN_OS_VERSION" in
        10.*|11.*|12.04|12.10|13.*|14.04|14.10|15.*|16.04|16.10|17.*|18.04|18.10|19.*|20.10|21.*|22.10|23.*|24.10|25.*) return 0 ;;
        *) return 1 ;;
    esac
}

golden_debian_archived() {
    local m="${GOLDEN_OS_VERSION%%.*}"
    [[ "$m" =~ ^[0-9]+$ ]] && (( m <= 10 ))
}

golden_repair_eol_sources() {
    local f changed=1 backup="/var/backups/golden-apt-$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$backup" 2>/dev/null || true
    cp -a /etc/apt/sources.list "$backup/" 2>/dev/null || true
    cp -a /etc/apt/sources.list.d "$backup/" 2>/dev/null || true
    if [[ "$GOLDEN_OS_ID" == ubuntu ]] && golden_ubuntu_archived; then
        for f in /etc/apt/sources.list /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources; do
            [[ -f "$f" ]] || continue
            sed -Ei \
              -e 's#https?://([a-z]{2}\.)?archive\.ubuntu\.com/ubuntu/?#http://old-releases.ubuntu.com/ubuntu/#g' \
              -e 's#https?://security\.ubuntu\.com/ubuntu/?#http://old-releases.ubuntu.com/ubuntu/#g' \
              -e 's#https?://ports\.ubuntu\.com/ubuntu-ports/?#http://old-releases.ubuntu.com/ubuntu/#g' "$f" || true
        done
        mkdir -p /etc/apt/apt.conf.d
        printf 'Acquire::Check-Valid-Until "false";\n' >/etc/apt/apt.conf.d/99golden-archive
        changed=0
    elif [[ "$GOLDEN_OS_ID" == debian ]] && golden_debian_archived; then
        for f in /etc/apt/sources.list /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources; do
            [[ -f "$f" ]] || continue
            sed -Ei \
              -e 's#https?://(deb|ftp)\.debian\.org/debian/?#http://archive.debian.org/debian/#g' \
              -e 's#https?://[a-z]{2}\.deb\.debian\.org/debian/?#http://archive.debian.org/debian/#g' \
              -e 's#https?://security\.debian\.org/debian-security/?#http://archive.debian.org/debian-security/#g' \
              -e 's#https?://security\.debian\.org/?#http://archive.debian.org/debian-security/#g' "$f" || true
            sed -Ei '/^[[:space:]]*deb .*-(updates|backports)[[:space:]]/ s/^/# Golden EOL: /' "$f" || true
        done
        mkdir -p /etc/apt/apt.conf.d
        cat >/etc/apt/apt.conf.d/99golden-archive <<'EOAPT'
Acquire::Check-Valid-Until "false";
Acquire::AllowInsecureRepositories "true";
EOAPT
        changed=0
    fi
    return "$changed"
}

golden_apt_base() {
    [[ -n "$GOLDEN_APT_GET_BIN" && -x "$GOLDEN_APT_GET_BIN" ]] || return 127
    golden_run_timeout "$GOLDEN_APT_STEP_TIMEOUT" "$GOLDEN_APT_GET_BIN" \
      -o DPkg::Lock::Timeout="$GOLDEN_APT_LOCK_WAIT" \
      -o Acquire::Retries=3 \
      -o Acquire::http::Timeout=25 \
      -o Acquire::https::Timeout=25 \
      -o Acquire::ftp::Timeout=25 \
      -o Dpkg::Use-Pty=0 \
      -o Dpkg::Options::=--force-confold "$@"
}

golden_apt_update() {
    local force="${1:-0}"
    golden_apt_wait "$GOLDEN_APT_LOCK_WAIT" || return 1
    if [[ "$force" != 1 ]] && golden_apt_stamp_fresh; then
        printf '[APT] Índices recientes: se reutilizan (<%s min).\n' "$GOLDEN_APT_CACHE_MINUTES" >&2
        return 0
    fi
    if golden_apt_base update; then touch "$GOLDEN_APT_STAMP" 2>/dev/null || true; return 0; fi
    printf '[APT] update falló; comprobando mirrors históricos...\n' >&2
    if golden_repair_eol_sources && golden_apt_base -o Acquire::Check-Valid-Until=false update; then
        touch "$GOLDEN_APT_STAMP" 2>/dev/null || true
        return 0
    fi
    return 1
}

golden_pkg_installed() { dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q 'ok installed'; }
golden_pkg_available() {
    local c
    c="$(apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/ {print $2; exit}')"
    [[ -n "$c" && "$c" != '(none)' ]]
}

golden_apt_install() {
    golden_apt_wait "$GOLDEN_APT_LOCK_WAIT" || return 1
    golden_apt_base install -y --no-install-recommends "$@"
}

golden_install_available() {
    local -a todo=(); local p
    for p in "$@"; do
        golden_pkg_installed "$p" && continue
        if golden_pkg_available "$p"; then todo+=("$p"); else printf '[APT] opcional no disponible: %s\n' "$p" >&2; fi
    done
    ((${#todo[@]})) || return 0
    golden_apt_install "${todo[@]}"
}

golden_install_required() {
    local -a todo=(); local p
    for p in "$@"; do
        golden_pkg_installed "$p" && continue
        golden_pkg_available "$p" || { printf '[APT] requerido no disponible: %s\n' "$p" >&2; return 1; }
        todo+=("$p")
    done
    ((${#todo[@]})) || return 0
    golden_apt_install "${todo[@]}"
}

golden_install_iproute() {
    command -v ip >/dev/null 2>&1 && return 0
    if golden_pkg_available iproute2; then golden_apt_install iproute2; elif golden_pkg_available iproute; then golden_apt_install iproute; else return 1; fi
}

golden_apt_command() {
    local a
    for a in "$@"; do [[ "$a" == update ]] && { golden_apt_update "${GOLDEN_FORCE_APT_UPDATE:-0}"; return; }; done
    golden_apt_wait "$GOLDEN_APT_LOCK_WAIT" || return 1
    golden_apt_base "$@"
}

# Wrappers transparentes para scripts heredados.
apt-get() { golden_apt_command "$@"; }
apt() { golden_apt_command "$@"; }

curl() {
    [[ -n "$GOLDEN_CURL_BIN" && -x "$GOLDEN_CURL_BIN" ]] || return 127
    "$GOLDEN_CURL_BIN" --connect-timeout "$GOLDEN_NET_CONNECT_TIMEOUT" --max-time "$GOLDEN_NET_TOTAL_TIMEOUT" --retry 3 --retry-delay 2 "$@"
}
wget() {
    [[ -n "$GOLDEN_WGET_BIN" && -x "$GOLDEN_WGET_BIN" ]] || return 127
    "$GOLDEN_WGET_BIN" --timeout=25 --read-timeout=60 --tries=3 "$@"
}
git() {
    [[ -n "$GOLDEN_GIT_BIN" && -x "$GOLDEN_GIT_BIN" ]] || return 127
    "$GOLDEN_GIT_BIN" -c http.lowSpeedLimit=1024 -c http.lowSpeedTime=60 "$@"
}

# Servicios heredados también quedan limitados: un start/stop defectuoso no puede
# dejar el menú congelado durante minutos indefinidamente.
systemctl() {
    if golden_has_systemd; then
        golden_run_timeout 60 "$GOLDEN_SYSTEMCTL_BIN" "$@"
    else
        golden_systemctl_legacy "$@"
    fi
}
service() {
    [[ -n "$GOLDEN_SERVICE_BIN" && -x "$GOLDEN_SERVICE_BIN" ]] || return 1
    golden_run_timeout 60 "$GOLDEN_SERVICE_BIN" "$@"
}

golden_fetch() {
    local url="$1" out="$2" allow_empty="${3:-0}"
    rm -f -- "$out.part" 2>/dev/null || true
    if [[ -n "$GOLDEN_CURL_BIN" && -x "$GOLDEN_CURL_BIN" ]]; then
        "$GOLDEN_CURL_BIN" -fL --connect-timeout "$GOLDEN_NET_CONNECT_TIMEOUT" --max-time "$GOLDEN_NET_TOTAL_TIMEOUT" --retry 3 --retry-delay 2 "$url" -o "$out.part" || { rm -f -- "$out.part"; return 1; }
    elif [[ -n "$GOLDEN_WGET_BIN" && -x "$GOLDEN_WGET_BIN" ]]; then
        "$GOLDEN_WGET_BIN" -q --timeout=25 --read-timeout=60 --tries=3 -O "$out.part" "$url" || { rm -f -- "$out.part"; return 1; }
    else
        return 127
    fi
    [[ -s "$out.part" || ( "$allow_empty" == 1 && -e "$out.part" ) ]] || { rm -f -- "$out.part"; return 1; }
    mv -f -- "$out.part" "$out"
}

golden_proc_same() {
    local pid="$1" start="$2" now=""
    [[ -r "/proc/$pid/stat" ]] || return 1
    now="$(awk '{print $22}' "/proc/$pid/stat" 2>/dev/null || true)"
    [[ -n "$now" && "$now" == "$start" ]]
}

golden_kill_tree() {
    local pid="$1" child
    for child in $(pgrep -P "$pid" 2>/dev/null || true); do golden_kill_tree "$child"; done
    kill -TERM "$pid" 2>/dev/null || true
    sleep 1
    kill -KILL "$pid" 2>/dev/null || true
}

golden_progress_command() {
    local label="$1" command_text="$2" log="${3:-/tmp/golden-protocol-step.log}"
    local pid start rc=0 elapsed=0 spinner='-' line="" status watchdog=""
    status="$(mktemp /tmp/golden-protocol-status.XXXXXX)" || return 1
    rm -f "$status"
    : >"$log"
    (
        set +e
        eval "$command_text"
        rc=$?
        printf '%s\n' "$rc" >"$status"
        exit "$rc"
    ) >"$log" 2>&1 &
    pid=$!
    start="$(awk '{print $22}' "/proc/$pid/stat" 2>/dev/null || true)"

    # Watchdog duro: ningún paso no interactivo puede quedar infinito.
    (
        sleep "$GOLDEN_PROTOCOL_STEP_TIMEOUT"
        if golden_proc_same "$pid" "$start" && [[ ! -s "$status" ]]; then
            printf '124\n' >"$status.timeout"
            golden_kill_tree "$pid"
        fi
    ) &
    watchdog=$!

    while golden_proc_same "$pid" "$start" && [[ ! -s "$status" ]]; do
        case "$spinner" in '-' ) spinner='\\' ;; '\\' ) spinner='|' ;; '|' ) spinner='/' ;; '/' ) spinner='-' ;; esac
        line="$(tail -n 1 "$log" 2>/dev/null | tr '\r\n' '  ' | sed 's/[[:space:]]\+/ /g' | cut -c1-64)"
        if [[ -n "$line" ]]; then
            printf '\r\033[K[%s] %-24s %4ss | %s' "$spinner" "$label" "$elapsed" "$line"
        else
            printf '\r\033[K[%s] %-24s %4ss' "$spinner" "$label" "$elapsed"
        fi
        sleep 1
        elapsed=$((elapsed + 1))
    done
    wait "$pid" 2>/dev/null || rc=$?
    kill "$watchdog" 2>/dev/null || true
    wait "$watchdog" 2>/dev/null || true
    if [[ -s "$status.timeout" ]]; then rc=124; elif [[ -s "$status" ]]; then rc="$(cat "$status" 2>/dev/null || echo 1)"; fi
    rm -f "$status" "$status.timeout"
    [[ "$rc" =~ ^[0-9]+$ ]] || rc=1
    if (( rc == 0 )); then
        printf '\r\033[K[OK] %s (%ss)\n' "$label" "$elapsed"
    elif (( rc == 124 )); then
        printf '\r\033[K[TIMEOUT] %s superó %ss y fue detenido de forma segura.\n' "$label" "$GOLDEN_PROTOCOL_STEP_TIMEOUT"
        tail -n 30 "$log" 2>/dev/null || true
    else
        printf '\r\033[K[ERROR] %s (rc=%s, %ss)\n' "$label" "$rc" "$elapsed"
        tail -n 30 "$log" 2>/dev/null || true
    fi
    return "$rc"
}

golden_public_ip() {
    local ip=""
    if [[ -n "$GOLDEN_CURL_BIN" && -x "$GOLDEN_CURL_BIN" ]]; then
        ip=$("$GOLDEN_CURL_BIN" -4fsS --connect-timeout 3 --max-time 6 https://api.ipify.org 2>/dev/null || true)
        [[ -n "$ip" ]] || ip=$("$GOLDEN_CURL_BIN" -4fsS --connect-timeout 3 --max-time 6 https://ipv4.icanhazip.com 2>/dev/null || true)
    fi
    [[ -n "$ip" ]] || ip=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
    [[ -n "$ip" ]] || ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    printf '%s\n' "$ip"
}

golden_public_ip_cached() {
    local cache="$GOLDEN_STATE_DIR/public-ip" ip=""
    if [[ -s "$cache" ]] && find "$cache" -mmin -10 -print -quit 2>/dev/null | grep -q .; then
        cat "$cache"
        return 0
    fi
    ip="$(golden_public_ip 2>/dev/null || true)"
    if [[ -n "$ip" ]]; then
        printf '%s
' "$ip" >"$cache" 2>/dev/null || true
        printf '%s
' "$ip"
        return 0
    fi
    return 1
}

golden_default_iface() { ip -4 route show default 2>/dev/null | awk '{print $5; exit}'; }

golden_port_in_use() {
    local proto="${1:-tcp}" port="$2"
    case "$proto" in
        tcp) ss -H -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${port}$" ;;
        udp) ss -H -lun 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${port}$" ;;
        *) return 2 ;;
    esac
}

golden_restart_ssh() { golden_service restart ssh 2>/dev/null || golden_service restart sshd 2>/dev/null; }

golden_os_load

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    echo "Golden Protocol Self-Test REV25"
    echo "Sistema: ${GOLDEN_OS_PRETTY:-$GOLDEN_OS_ID $GOLDEN_OS_VERSION} | arch=$GOLDEN_ARCH"
    printf 'APT locks: '; _p="$(golden_apt_lock_pids | tr '\n' ' ')"; [[ -n "$_p" ]] && echo "$_p" || echo libre
    printf 'DNS: '; getent ahostsv4 github.com >/dev/null 2>&1 && echo OK || echo FAIL
    printf 'HTTPS GitHub: '
    if [[ -n "$GOLDEN_CURL_BIN" && -x "$GOLDEN_CURL_BIN" ]] && golden_run_timeout 20 "$GOLDEN_CURL_BIN" -fsSI --connect-timeout 5 --max-time 15 https://github.com >/dev/null 2>&1; then echo OK; else echo FAIL; fi
    printf 'APT: '; [[ -n "$GOLDEN_APT_GET_BIN" && -x "$GOLDEN_APT_GET_BIN" ]] && echo OK || echo FAIL
    printf 'Init: '; golden_has_systemd && echo systemd || echo legacy-init
fi
