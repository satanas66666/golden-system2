#!/usr/bin/env bash
# Golden System PRO - biblioteca pequeña de compatibilidad Ubuntu/Debian.
# Se puede cargar con: source /etc/ger-inst/compat.sh
# No cambia la configuración del sistema por sí sola.

export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND="${DEBIAN_FRONTEND:-noninteractive}"

golden_os_load() {
    GOLDEN_OS_ID=unknown
    GOLDEN_OS_VERSION=0
    GOLDEN_OS_CODENAME=""
    if [[ -r /etc/os-release ]]; then
        # shellcheck disable=SC1091
        . /etc/os-release
        GOLDEN_OS_ID="${ID:-unknown}"
        GOLDEN_OS_VERSION="${VERSION_ID:-0}"
        GOLDEN_OS_CODENAME="${VERSION_CODENAME:-${UBUNTU_CODENAME:-}}"
    fi
    GOLDEN_ARCH="$(dpkg --print-architecture 2>/dev/null || uname -m)"
}

golden_has_systemd() {
    command -v systemctl >/dev/null 2>&1 && [[ -d /run/systemd/system ]]
}

golden_service() {
    local action="$1" name="$2"
    if golden_has_systemd; then
        systemctl "$action" "$name"
    elif command -v service >/dev/null 2>&1; then
        service "$name" "$action"
    elif [[ -x "/etc/init.d/$name" ]]; then
        "/etc/init.d/$name" "$action"
    else
        return 1
    fi
}

golden_service_active() {
    local name="$1"
    if golden_has_systemd; then
        systemctl is-active --quiet "$name"
    elif command -v service >/dev/null 2>&1; then
        service "$name" status >/dev/null 2>&1
    else
        pgrep -x "$name" >/dev/null 2>&1
    fi
}

golden_apt_wait() {
    local waited=0 max="${1:-300}"
    while pgrep -x apt >/dev/null 2>&1 ||
          pgrep -x apt-get >/dev/null 2>&1 ||
          pgrep -x dpkg >/dev/null 2>&1 ||
          pgrep -x unattended-upgr >/dev/null 2>&1; do
        sleep 2
        waited=$((waited + 2))
        (( waited < max )) || return 1
    done
}

golden_apt_update() {
    golden_apt_wait 300 || return 1
    apt-get -o Acquire::Retries=3 update
}

golden_apt_install() {
    golden_apt_wait 300 || return 1
    apt-get -o Acquire::Retries=3 -o Dpkg::Options::=--force-confold install -y "$@"
}

golden_public_ip() {
    local ip=""
    if command -v curl >/dev/null 2>&1; then
        ip=$(curl -4fsS --connect-timeout 3 --max-time 6 https://api.ipify.org 2>/dev/null || true)
        [[ -n "$ip" ]] || ip=$(curl -4fsS --connect-timeout 3 --max-time 6 https://ipv4.icanhazip.com 2>/dev/null || true)
    fi
    [[ -n "$ip" ]] || ip=$(ip -4 route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src"){print $(i+1); exit}}')
    [[ -n "$ip" ]] || ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    printf '%s\n' "$ip"
}

golden_default_iface() {
    ip -4 route show default 2>/dev/null | awk '{print $5; exit}'
}

golden_port_in_use() {
    local proto="${1:-tcp}" port="$2"
    case "$proto" in
        tcp) ss -H -ltn 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${port}$" ;;
        udp) ss -H -lun 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]${port}$" ;;
        *) return 2 ;;
    esac
}

golden_restart_ssh() {
    golden_service restart ssh 2>/dev/null ||
    golden_service restart sshd 2>/dev/null
}

golden_os_load
