#!/bin/bash

# Golden REV25: compatibilidad común, APT no interactivo, timeouts de red y progreso.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export PATH=/usr/local/go/bin:/root/go/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
shopt -s extglob

DIR="/etc/newadm/dnstt"
CFG="$DIR/dnstt.conf"
KEY_DIR="/etc/dnstt"
SRC_DIR="/opt/dnstt-src"
BIN="/usr/local/bin/dnstt-server"
SERVICE="dnstt-udp.service"

DEFAULT_PUBKEY="e5d2a44b70474c6ffd35e4128480ba89865daba4bc3db369f9c8fb0ab0236905"
FIXED_PRIVKEY_B64="M2YzNTE3OTE4NDVjOTc3YWM3ODcxZDZmODdhNmQ3YmQ3M2FkYWU2OTI0Y2JjNmY5YTBiOWZlYzkxODFhMDViMwo="

DEFAULT_UDP_PORT="53"
DEFAULT_LOCAL_PORT="22"
DEFAULT_DOH="https://cloudflare-dns.com/dns-query"
DEFAULT_DOT="cloudflare-dns.com:853"

mkdir -p "$DIR" "$KEY_DIR" /etc/iptables

VERDE="\033[1;32m"
ROJO="\033[1;31m"
AMARILLO="\033[1;33m"
AZUL="\033[1;34m"
CYAN="\033[1;36m"
BLANCO="\033[1;37m"
RESET="\033[0m"

bar(){ echo -e "${AMARILLO}════════════════════════════════════════════════════════════${RESET}"; }
ok(){ echo -e "${VERDE}$1${RESET}"; }
err(){ echo -e "${ROJO}$1${RESET}"; }
info(){ echo -e "${AZUL}$1${RESET}"; }
pause(){ echo; read -r -p "Enter para continuar..." enter; }

valid_port(){
[[ "$1" =~ ^[0-9]+$ ]] && [[ "$1" -ge 1 ]] && [[ "$1" -le 65535 ]]
}

get_public_ip(){
    golden_public_ip_cached 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}'
}

status_onoff(){
local svc="$1"
if systemctl is-active --quiet "$svc"; then
echo -e "${VERDE}ON${RESET}"
else
echo -e "${ROJO}OFF${RESET}"
fi
}

load_config(){
APP_PUBKEY="$DEFAULT_PUBKEY"

if [[ -e "$CFG" ]]; then
source "$CFG"
else
NS_DOMAIN=""
LOCAL_PORT=""
UDP_PORT=""
DOH_RESOLVER=""
DOT_RESOLVER=""
APP_PUBKEY="$DEFAULT_PUBKEY"
fi
}

save_config(){
cat > "$CFG" <<EOF
NS_DOMAIN="$NS_DOMAIN"
LOCAL_PORT="$LOCAL_PORT"
UDP_PORT="$UDP_PORT"
DOH_RESOLVER="$DOH_RESOLVER"
DOT_RESOLVER="$DOT_RESOLVER"
APP_PUBKEY="$APP_PUBKEY"
EOF
}

install_deps(){
    golden_apt_update || return 1
    golden_install_required curl wget git ca-certificates iptables lsof jq tar || return 1
    golden_install_available build-essential iptables-persistent netfilter-persistent dnsutils || true
}

install_go_new(){
local arch goarch goversion current major minor
goversion="1.22.6"

arch="$(uname -m)"

case "$arch" in
x86_64|amd64) goarch="amd64" ;;
aarch64|arm64) goarch="arm64" ;;
armv7l|armv6l) goarch="armv6l" ;;
*) err "Arquitectura no soportada: $arch"; return 1 ;;
esac

if command -v go >/dev/null 2>&1; then
current="$(go version | awk '{print $3}' | sed 's/go//')"
major="$(echo "$current" | cut -d. -f1)"
minor="$(echo "$current" | cut -d. -f2)"

if [[ "$major" -gt 1 || "$minor" -ge 21 ]]; then
ok "Go compatible detectado: $(go version)"
return 0
fi
fi

info "Instalando Go $goversion para $goarch..."

rm -rf /usr/local/go

wget -q -O /tmp/go.tar.gz "https://go.dev/dl/go${goversion}.linux-${goarch}.tar.gz" || {
err "No se pudo descargar Go."
return 1
}

tar -C /usr/local -xzf /tmp/go.tar.gz || {
err "No se pudo instalar Go."
return 1
}

ln -sf /usr/local/go/bin/go /usr/bin/go
ln -sf /usr/local/go/bin/gofmt /usr/bin/gofmt

export PATH=/usr/local/go/bin:/root/go/bin:$PATH

ok "Go instalado: $(go version)"
}

open_udp(){
local p="$1"
valid_port "$p" || return 1

iptables -C INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null || \
iptables -I INPUT -p udp --dport "$p" -j ACCEPT

iptables-save > /etc/iptables/rules.v4 2>/dev/null

if command -v ufw >/dev/null 2>&1; then
ufw allow "$p"/udp >/dev/null 2>&1
fi
}

close_udp(){
local p="$1"
valid_port "$p" || return 1

while iptables -C INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null; do
iptables -D INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null
done

iptables-save > /etc/iptables/rules.v4 2>/dev/null

if command -v ufw >/dev/null 2>&1; then
ufw delete allow "$p"/udp >/dev/null 2>&1
fi
}

free_port_53(){
clear
bar
info " LIBERANDO PUERTO 53 UDP"
bar

systemctl stop systemd-resolved >/dev/null 2>&1
systemctl disable systemd-resolved >/dev/null 2>&1
systemctl mask systemd-resolved >/dev/null 2>&1

rm -f /etc/resolv.conf

cat > /etc/resolv.conf <<EOF
nameserver 8.8.8.8
nameserver 1.1.1.1
EOF

ok "Puerto 53 liberado correctamente."
bar
pause
menu
}

install_bin(){
install_deps
install_go_new || return 1

if [[ -x "$BIN" ]]; then
ok "DNSTT ya está instalado."
return 0
fi

rm -rf "$SRC_DIR"
golden_run_timeout 180 git clone https://www.bamsoftware.com/git/dnstt.git "$SRC_DIR" || {
err "No se pudo descargar DNSTT."
return 1
}

cd "$SRC_DIR" || {
err "No se pudo entrar al código DNSTT."
return 1
}

export PATH=/usr/local/go/bin:/root/go/bin:$PATH
go clean -modcache >/dev/null 2>&1

golden_run_timeout 300 go build -o "$BIN" ./dnstt-server || {
err "No se pudo compilar dnstt-server."
return 1
}

chmod +x "$BIN"
cd - >/dev/null 2>&1

ok "DNSTT instalado correctamente."
}

gen_key(){
mkdir -p "$KEY_DIR"

echo "$FIXED_PRIVKEY_B64" | base64 -d > "$KEY_DIR/server.key"
chmod 600 "$KEY_DIR/server.key"

echo "$DEFAULT_PUBKEY" > "$KEY_DIR/server.pub"
chmod 644 "$KEY_DIR/server.pub"
}

write_service(){
cat > "/etc/systemd/system/$SERVICE" <<EOF
[Unit]
Description=DNSTT UDP Golden MX
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
ExecStart=$BIN -udp :$UDP_PORT -privkey-file $KEY_DIR/server.key $NS_DOMAIN 127.0.0.1:$LOCAL_PORT
Restart=always
RestartSec=2
LimitNOFILE=1048576
LimitNPROC=1048576

[Install]
WantedBy=multi-user.target
EOF
}

restart_service(){
systemctl daemon-reload >/dev/null 2>&1
systemctl enable "$SERVICE" >/dev/null 2>&1
systemctl restart "$SERVICE" >/dev/null 2>&1
sleep 2
}

show_header(){
clear
load_config

bar
echo -e "${CYAN}        SLOWDNS / DNSTT ${ROJO}[ GOLDEN MX ]${RESET}"
bar

[[ -x "$BIN" ]] && ok "DNSTT BINARIO : INSTALADO" || err "DNSTT BINARIO : NO INSTALADO"
echo -e "SERVICIO UDP  : $(status_onoff "$SERVICE")"
bar

if [[ -x "$BIN" && -e "$CFG" ]]; then
echo -e "Host DNS VPS  : ${VERDE}$(get_public_ip)${RESET}"
echo -e "Nameserver    : ${BLANCO}$NS_DOMAIN${RESET}"
echo -e "Destino SSH   : ${BLANCO}127.0.0.1:$LOCAL_PORT${RESET}"
echo -e "Puerto UDP    : ${BLANCO}$UDP_PORT${RESET}"
echo -e "DoH App       : ${BLANCO}$DOH_RESOLVER${RESET}"
echo -e "DoT App       : ${BLANCO}$DOT_RESOLVER${RESET}"
else
local_ip="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo "Host DNS VPS  : ${local_ip:-se detectará al instalar}"
echo "Nameserver    : NO CONFIGURADO"
echo "Destino SSH   : NO CONFIGURADO"
echo "Puerto UDP    : NO CONFIGURADO"
echo "DoH App       : NO CONFIGURADO"
echo "DoT App       : NO CONFIGURADO"
fi

echo -e "PubKey App    : ${AZUL}$APP_PUBKEY${RESET}"
bar
}

install_dnstt(){
golden_require_systemd || { err "SlowDNS/DNSTT requiere systemd en esta versión del módulo."; pause; return 1; }
show_header
info " INSTALAR / RECONFIGURAR DNSTT"
bar

install_bin || {
pause
menu
}

echo -ne "Nameserver / Dominio NS: "
read -r NS_DOMAIN

[[ -z "$NS_DOMAIN" ]] && {
err "Dominio inválido."
pause
menu
}

echo -ne "Puerto interno SSH ENTER para 22: "
read -r LOCAL_PORT
[[ -z "$LOCAL_PORT" ]] && LOCAL_PORT="$DEFAULT_LOCAL_PORT"

if ! valid_port "$LOCAL_PORT"; then
LOCAL_PORT="22"
fi

echo -ne "Puerto DNSTT UDP ENTER para 53: "
read -r UDP_PORT
[[ -z "$UDP_PORT" ]] && UDP_PORT="$DEFAULT_UDP_PORT"

if ! valid_port "$UDP_PORT"; then
UDP_PORT="53"
fi

echo -ne "DoH para tu app ENTER default: "
read -r DOH_RESOLVER
[[ -z "$DOH_RESOLVER" ]] && DOH_RESOLVER="$DEFAULT_DOH"

echo -ne "DoT para tu app ENTER default: "
read -r DOT_RESOLVER
[[ -z "$DOT_RESOLVER" ]] && DOT_RESOLVER="$DEFAULT_DOT"

echo -ne "PubKey APP ENTER para usar default: "
read -r input_pubkey
[[ -z "$input_pubkey" ]] && APP_PUBKEY="$DEFAULT_PUBKEY" || APP_PUBKEY="$input_pubkey"

save_config
gen_key
write_service
open_udp "$UDP_PORT"
restart_service

bar

if systemctl is-active --quiet "$SERVICE"; then
ok "DNSTT INSTALADO Y ACTIVO"
else
err "DNSTT NO INICIÓ"
systemctl status "$SERVICE" --no-pager -l
fi

bar
echo "Host DNS VPS : $(get_public_ip)"
echo "Nameserver   : $NS_DOMAIN"
echo "Puerto SSH   : $LOCAL_PORT"
echo "Puerto UDP   : $UDP_PORT"
echo "DoH App      : $DOH_RESOLVER"
echo "DoT App      : $DOT_RESOLVER"
echo "PubKey App   : $APP_PUBKEY"
bar
pause
menu
}

show_info(){
show_header
info " DATOS PARA TU APP"
bar

echo "Host DNS VPS:"
echo "$(get_public_ip)"
bar

echo "Nameserver:"
echo "${NS_DOMAIN:-NO CONFIGURADO}"
bar

echo "PubKey:"
echo "$APP_PUBKEY"
bar

echo "Puerto SSH interno:"
echo "${LOCAL_PORT:-NO CONFIGURADO}"
bar

echo "Puerto UDP:"
echo "${UDP_PORT:-NO CONFIGURADO}"
bar

echo "DoH App:"
echo "${DOH_RESOLVER:-NO CONFIGURADO}"
bar

echo "DoT App:"
echo "${DOT_RESOLVER:-NO CONFIGURADO}"
bar

pause
menu
}

show_keys(){
show_header
info " LLAVES DNSTT"
bar

echo "PubKey App:"
echo "$APP_PUBKEY"
bar

echo "PubKey Real del Servidor:"
cat "$KEY_DIR/server.pub" 2>/dev/null || echo "NO EXISTE"
echo
bar

echo "PrivateKey Base64:"
base64 -w0 "$KEY_DIR/server.key" 2>/dev/null || echo "NO EXISTE"
echo
bar

pause
menu
}

change_domain(){
show_header
info " CAMBIAR NAMESERVER"
bar

echo "Actual: ${NS_DOMAIN:-NO CONFIGURADO}"
echo -ne "Nuevo Nameserver: "
read -r NS_DOMAIN

[[ -z "$NS_DOMAIN" ]] && {
err "Nameserver inválido."
pause
menu
}

save_config
write_service
restart_service

ok "Nameserver actualizado."
pause
menu
}

change_internal(){
show_header
info " CAMBIAR PUERTO INTERNO"
bar

echo "Actual: ${LOCAL_PORT:-NO CONFIGURADO}"
echo -ne "Nuevo puerto interno ENTER para 22: "
read -r LOCAL_PORT
[[ -z "$LOCAL_PORT" ]] && LOCAL_PORT="22"

if ! valid_port "$LOCAL_PORT"; then
err "Puerto inválido."
pause
menu
fi

save_config
write_service
restart_service

ok "Puerto interno actualizado."
pause
menu
}

change_udp(){
show_header
info " CAMBIAR PUERTO UDP"
bar

old="$UDP_PORT"

echo "Actual: ${UDP_PORT:-NO CONFIGURADO}"
echo -ne "Nuevo puerto UDP ENTER para 53: "
read -r UDP_PORT
[[ -z "$UDP_PORT" ]] && UDP_PORT="53"

if ! valid_port "$UDP_PORT"; then
err "Puerto inválido."
pause
menu
fi

[[ -n "$old" ]] && close_udp "$old"

save_config
write_service
open_udp "$UDP_PORT"
restart_service

ok "Puerto UDP actualizado."
pause
menu
}

change_pubkey(){
show_header
info " CAMBIAR PUBKEY APP"
bar

echo "Actual:"
echo "$APP_PUBKEY"
bar

echo -ne "Nueva PubKey ENTER para default: "
read -r input_pubkey

[[ -z "$input_pubkey" ]] && APP_PUBKEY="$DEFAULT_PUBKEY" || APP_PUBKEY="$input_pubkey"

save_config

ok "PubKey actualizada."
bar
echo "$APP_PUBKEY"
bar
pause
menu
}

change_resolvers(){
show_header
info " CAMBIAR DoH / DoT APP"
bar

echo "DoH actual: ${DOH_RESOLVER:-NO CONFIGURADO}"
echo -ne "Nuevo DoH ENTER default: "
read -r DOH_RESOLVER
[[ -z "$DOH_RESOLVER" ]] && DOH_RESOLVER="$DEFAULT_DOH"

echo "DoT actual: ${DOT_RESOLVER:-NO CONFIGURADO}"
echo -ne "Nuevo DoT ENTER default: "
read -r DOT_RESOLVER
[[ -z "$DOT_RESOLVER" ]] && DOT_RESOLVER="$DEFAULT_DOT"

save_config

ok "DoH / DoT actualizado."
pause
menu
}

status_dnstt(){
show_header
info " ESTADO GENERAL"
bar

systemctl status "$SERVICE" --no-pager -l
bar

echo "Puertos escuchando:"
ss -lunp | grep -E "dnstt|:$UDP_PORT" || err "No hay puerto DNSTT escuchando."
bar

pause
menu
}

repair_dnstt(){
show_header
info " REPARAR DNSTT"
bar

install_bin
gen_key

[[ -z "$NS_DOMAIN" ]] && {
err "No hay Nameserver configurado. Instala primero."
pause
menu
}

[[ -z "$LOCAL_PORT" ]] && LOCAL_PORT="22"
[[ -z "$UDP_PORT" ]] && UDP_PORT="53"

save_config
write_service
open_udp "$UDP_PORT"
restart_service

systemctl status "$SERVICE" --no-pager -l
bar
pause
menu
}

logs_dnstt(){
clear
bar
info " LOGS DNSTT"
bar

journalctl -u "$SERVICE" -n 100 --no-pager

bar
pause
menu
}

uninstall_dnstt(){
show_header
info " DESINSTALAR DNSTT COMPLETO"
bar

read -p "Confirmar [s/n]: " resp
[[ "$resp" != "s" && "$resp" != "S" ]] && menu

systemctl stop "$SERVICE" >/dev/null 2>&1
systemctl disable "$SERVICE" >/dev/null 2>&1
rm -f "/etc/systemd/system/$SERVICE"
systemctl daemon-reload >/dev/null 2>&1
systemctl reset-failed >/dev/null 2>&1

[[ -n "$UDP_PORT" ]] && close_udp "$UDP_PORT"

pkill -f dnstt-server >/dev/null 2>&1
rm -f "$BIN"
rm -rf "$KEY_DIR" "$DIR" "$SRC_DIR"

ok "DNSTT eliminado completamente."
pause
menu
}

menu(){
show_header

echo -e "${VERDE}[1]${RESET} INSTALAR / RECONFIGURAR DNSTT"
echo -e "${VERDE}[2]${RESET} MOSTRAR DATOS PARA APP"
echo -e "${VERDE}[3]${RESET} VER LLAVES"
echo -e "${VERDE}[4]${RESET} CAMBIAR NAMESERVER"
echo -e "${VERDE}[5]${RESET} CAMBIAR PUERTO INTERNO"
echo -e "${VERDE}[6]${RESET} CAMBIAR PUERTO UDP"
echo -e "${VERDE}[7]${RESET} CAMBIAR PUBKEY APP"
echo -e "${VERDE}[8]${RESET} CAMBIAR DoH / DoT APP"
echo -e "${VERDE}[9]${RESET} LIBERAR PUERTO 53"
echo -e "${VERDE}[10]${RESET} ESTADO GENERAL"
echo -e "${VERDE}[11]${RESET} REPARAR SERVICIO"
echo -e "${VERDE}[12]${RESET} VER LOGS"
echo -e "${VERDE}[13]${RESET} DESINSTALAR COMPLETO"
echo -e "${VERDE}[0]${RESET} SALIR"
bar

echo -ne "Seleccione: "
read -r op

case "$op" in
1) install_dnstt ;;
2) show_info ;;
3) show_keys ;;
4) change_domain ;;
5) change_internal ;;
6) change_udp ;;
7) change_pubkey ;;
8) change_resolvers ;;
9) free_port_53 ;;
10) status_dnstt ;;
11) repair_dnstt ;;
12) logs_dnstt ;;
13) uninstall_dnstt ;;
0) exit ;;
*) menu ;;
esac
}

menu