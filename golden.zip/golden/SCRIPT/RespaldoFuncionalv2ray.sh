#!/bin/bash

# Golden REV22: capa comun anti-bloqueo / compatibilidad Ubuntu-Debian.
golden_load_compat() {
    local f here
    here="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
    for f in /etc/ger-inst/compat.sh /etc/ger-frm/compat.sh /etc/SCRIPT/compat.sh "$here/compat.sh"; do
        if [[ -r "$f" ]]; then
            # shellcheck disable=SC1090
            . "$f"
            declare -F golden_apt_wait >/dev/null 2>&1 && return 0
        fi
    done
    return 1
}
if ! golden_load_compat; then
    echo "[ERROR] Falta compat.sh de Golden. Actualiza/reinstala los archivos del proyecto." >&2
    exit 1
fi
unset -f golden_load_compat
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export DEBIAN_FRONTEND=noninteractive
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
shopt -s extglob

SCPinst="/etc/ger-inst"
REG="/etc/newadm/RegV2ray"
DIR="/etc/newadm/v2ray"
CFG="/usr/local/etc/v2ray/config.json"
BIN="/usr/local/bin/v2ray"
SERVICE="v2ray"

mkdir -p "$DIR" /etc/newadm /usr/local/etc/v2ray /etc/iptables

VERDE="\033[1;32m"
ROJO="\033[1;31m"
AMARILLO="\033[1;33m"
AZUL="\033[1;34m"
BLANCO="\033[1;37m"
RESET="\033[0m"

bar(){ echo -e "${AMARILLO}============================================================${RESET}"; }
ok(){ echo -e "${VERDE}$1${RESET}"; }
err(){ echo -e "${ROJO}$1${RESET}"; }
info(){ echo -e "${AZUL}$1${RESET}"; }
pause(){ echo -ne "${BLANCO}Enter para continuar: ${RESET}"; read -r enter; }

install_deps(){
apt update -y
apt install -y curl wget unzip zip jq uuid-runtime lsof screen \
iptables iptables-persistent netfilter-persistent ca-certificates \
cron openssl socat chrony locales
locale-gen C.UTF-8 >/dev/null 2>&1
}

fix_time(){
systemctl enable chrony >/dev/null 2>&1
systemctl restart chrony >/dev/null 2>&1
timedatectl set-ntp true >/dev/null 2>&1
}

fix_service(){
mkdir -p /etc/systemd/system/v2ray.service.d

cat >/etc/systemd/system/v2ray.service <<'EOF'
[Unit]
Description=V2Ray Service
After=network.target nss-lookup.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/v2ray run -c /usr/local/etc/v2ray/config.json
Restart=always
RestartSec=3
LimitNOFILE=1048576
LimitNPROC=1048576

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload >/dev/null 2>&1
}

open_port(){
local p="$1"
[[ -z "$p" ]] && return

iptables -C INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null || iptables -I INPUT -p tcp --dport "$p" -j ACCEPT
iptables -C INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null || iptables -I INPUT -p udp --dport "$p" -j ACCEPT
iptables-save > /etc/iptables/rules.v4 2>/dev/null

if command -v ufw >/dev/null 2>&1; then
ufw allow "$p"/tcp >/dev/null 2>&1
ufw allow "$p"/udp >/dev/null 2>&1
fi
}

close_port(){
local p="$1"
[[ -z "$p" ]] && return

while iptables -C INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null; do
iptables -D INPUT -p tcp --dport "$p" -j ACCEPT 2>/dev/null
done

while iptables -C INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null; do
iptables -D INPUT -p udp --dport "$p" -j ACCEPT 2>/dev/null
done

iptables-save > /etc/iptables/rules.v4 2>/dev/null

if command -v ufw >/dev/null 2>&1; then
ufw delete allow "$p"/tcp >/dev/null 2>&1
ufw delete allow "$p"/udp >/dev/null 2>&1
fi
}

restart_v2ray(){
fix_service
fix_time
systemctl enable v2ray >/dev/null 2>&1
systemctl daemon-reload >/dev/null 2>&1
systemctl restart v2ray >/dev/null 2>&1
sleep 2
}

vps_ip(){
local ip
ip=$(curl -s4 ifconfig.me)
[[ -z "$ip" ]] && ip=$(hostname -I | awk '{print $1}')
echo "$ip"
}

create_config(){
cat >"$CFG" <<'EOF'
{
  "log": {
    "loglevel": "warning"
  },
  "inbounds": [],
  "outbounds": [
    {
      "protocol": "freedom",
      "settings": {}
    }
  ]
}
EOF
}

add_inbound(){
local port="$1"
local path="$2"

tmp=$(mktemp)

jq --arg p "$path" --argjson port "$port" '
.inbounds += [
{
"port": $port,
"listen": "0.0.0.0",
"protocol": "vmess",
"settings": {
"clients": []
},
"streamSettings": {
"network": "ws",
"security": "none",
"wsSettings": {
"path": $p
}
}
}
]
' "$CFG" > "$tmp" && mv "$tmp" "$CFG"
}

show_ports(){
[[ ! -e "$CFG" ]] && {
err "No existe configuración V2Ray"
return
}

jq -r '
.inbounds[]? |
"Puerto: \(.port) | TLS: \(.streamSettings.security // "none") | Path: [\(.streamSettings.wsSettings.path // "-")] | Usuarios: \(.settings.clients|length)"
' "$CFG"
}

install_v2ray(){
clear
bar
info " INSTALANDO V2RAY MODERNO"
bar

install_deps

systemctl stop v2ray >/dev/null 2>&1
bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh)

ln -sf /usr/local/bin/v2ray /usr/bin/v2ray

mkdir -p /usr/local/etc/v2ray
create_config
add_inbound 80 "/vmess"

open_port 80
restart_v2ray

bar
/usr/local/bin/v2ray test -c "$CFG"
bar

if ss -lntp | grep -q ':80'; then
ok " V2RAY INSTALADO Y ESCUCHANDO EN PUERTO 80"
else
err " V2RAY INSTALADO, PERO NO ESTA ESCUCHANDO"
fi

bar
pause
menu
}

agregar_puerto(){
clear
bar
info " AGREGAR PUERTO"
bar

[[ ! -e "$CFG" ]] && {
err "Primero instala V2Ray"
pause
menu
}

echo -ne "Puerto nuevo: "
read -r port

if [[ -z "$port" || "$port" != +([0-9]) || "$port" -gt 65535 ]]; then
err "PUERTO INVALIDO"
pause
menu
fi

if jq -e --arg p "$port" '.inbounds[]? | select((.port|tostring)==$p)' "$CFG" >/dev/null; then
err "Ese puerto ya existe"
pause
menu
fi

printf "Path WebSocket EXACTO con espacios/emojis: "
IFS= read -r path

[[ -z "$path" ]] && path="/vmess"

first_char="${path:0:1}"
if [[ "$first_char" != "/" && "$first_char" != " " ]]; then
path="/$path"
fi

add_inbound "$port" "$path"
open_port "$port"
restart_v2ray

bar
if ss -lntp | grep -q ":$port"; then
ok " PUERTO $port AGREGADO Y ACTIVO"
echo -e " PATH EXACTO ENTRE CORCHETES:"
echo -e "[$path]"
else
err " PUERTO AGREGADO, PERO NO ESCUCHA"
fi
bar

pause
menu
}

eliminar_puerto(){
clear
bar
info " ELIMINAR PUERTO"
bar

show_ports
bar

echo -ne "Puerto a eliminar: "
read -r port

if [[ -z "$port" || "$port" != +([0-9]) ]]; then
err "PUERTO INVALIDO"
pause
menu
fi

tmp=$(mktemp)
jq --arg p "$port" '.inbounds |= map(select((.port|tostring)!=$p))' "$CFG" > "$tmp" && mv "$tmp" "$CFG"

grep -v "|$port|" "$REG" > "$REG.tmp" 2>/dev/null
mv "$REG.tmp" "$REG" 2>/dev/null

close_port "$port"
restart_v2ray

bar
ok "PUERTO $port ELIMINADO Y CERRADO DEL FIREWALL"
bar

pause
menu
}

activar_tls(){
clear
bar
info " ACTIVAR TLS EN PUERTO"
bar

show_ports
bar

echo -ne "Puerto donde activar TLS: "
read -r port

if ! jq -e --arg p "$port" '.inbounds[]? | select((.port|tostring)==$p)' "$CFG" >/dev/null; then
err "PUERTO NO EXISTE"
pause
menu
fi

echo -ne "Dominio apuntado a la VPS: "
read -r domain

[[ -z "$domain" ]] && {
err "DOMINIO INVALIDO"
pause
menu
}

install_deps
open_port 80
open_port "$port"

mkdir -p /usr/local/etc/v2ray/cert/$port

bar
info " Deteniendo V2Ray para liberar puerto 80 y generar certificado..."
bar

systemctl stop v2ray >/dev/null 2>&1
sleep 2

curl -s https://get.acme.sh | sh -s email=admin@$domain
~/.acme.sh/acme.sh --set-default-ca --server letsencrypt
~/.acme.sh/acme.sh --issue -d "$domain" --standalone --force --keylength ec-256

if [[ ! -f "/root/.acme.sh/${domain}_ecc/${domain}.key" ]]; then
err "NO SE GENERO EL CERTIFICADO. Verifica que el dominio apunte a esta VPS y que el puerto 80 esté libre."
restart_v2ray
pause
menu
fi

~/.acme.sh/acme.sh --install-cert -d "$domain" --ecc \
--key-file /usr/local/etc/v2ray/cert/$port/private.key \
--fullchain-file /usr/local/etc/v2ray/cert/$port/cert.crt

if [[ ! -s "/usr/local/etc/v2ray/cert/$port/private.key" || ! -s "/usr/local/etc/v2ray/cert/$port/cert.crt" ]]; then
err "CERTIFICADO NO INSTALADO CORRECTAMENTE"
restart_v2ray
pause
menu
fi

tmp=$(mktemp)

jq --arg p "$port" --arg d "$domain" --arg cert "/usr/local/etc/v2ray/cert/$port/cert.crt" --arg key "/usr/local/etc/v2ray/cert/$port/private.key" '
.inbounds |= map(
if (.port|tostring)==$p then
.streamSettings.security = "tls" |
.streamSettings.tlsSettings = {
"serverName": $d,
"certificates": [
{
"certificateFile": $cert,
"keyFile": $key
}
]
}
else . end
)
' "$CFG" > "$tmp" && mv "$tmp" "$CFG"

restart_v2ray

bar
ok " TLS ACTIVADO CORRECTAMENTE EN PUERTO $port"
ok " DOMINIO: $domain"
bar

pause
menu
}

desactivar_tls(){
clear
bar
info " DESACTIVAR TLS EN PUERTO"
bar

show_ports
bar

echo -ne "Puerto: "
read -r port

tmp=$(mktemp)

jq --arg p "$port" '
.inbounds |= map(
if (.port|tostring)==$p then
.streamSettings.security = "none" |
del(.streamSettings.tlsSettings)
else . end
)
' "$CFG" > "$tmp" && mv "$tmp" "$CFG"

restart_v2ray

bar
ok "TLS DESACTIVADO EN PUERTO $port"
bar
pause
menu
}

crear_usuario(){
clear
bar
info " CREAR USUARIO VMESS"
bar

[[ ! -e "$CFG" ]] && {
err "Primero instala V2Ray"
pause
menu
}

show_ports
bar

while true; do
echo -ne "Puerto: "
read -r port

if [[ -z "$port" || "$port" != +([0-9]) ]]; then
err "PUERTO INVALIDO"
continue
fi

if ! jq -e --arg p "$port" '.inbounds[] | select((.port|tostring)==$p)' "$CFG" >/dev/null; then
err "PUERTO NO EXISTE"
continue
fi

break
done

echo -ne "Usuario: "
read -r user
user="$(echo "$user" | sed 's/[^a-zA-Z0-9_-]//g')"

if [[ ${#user} -lt 2 || ${#user} -gt 20 ]]; then
err "USUARIO INVALIDO"
pause
menu
fi

echo -ne "Dias: "
read -r dias

if [[ -z "$dias" || "$dias" != +([0-9]) || "$dias" -gt 365 ]]; then
err "DIAS INVALIDOS"
pause
menu
fi

echo -ne "Host funcional para HTTP Custom: "
IFS= read -r hostcustom

printf "Path EXACTO con espacios/emojis ENTER para usar el del puerto: "
IFS= read -r pathcustom

if [[ -n "$pathcustom" ]]; then
first_char="${pathcustom:0:1}"
if [[ "$first_char" != "/" && "$first_char" != " " ]]; then
pathcustom="/$pathcustom"
fi

tmp_path=$(mktemp)
jq --arg p "$port" --arg path "$pathcustom" '
.inbounds |= map(
if (.port|tostring)==$p then
.streamSettings.wsSettings.path=$path
else . end
)
' "$CFG" > "$tmp_path" && mv "$tmp_path" "$CFG"
fi

echo -ne "UUID personalizado ENTER para automático: "
IFS= read -r uuidcustom

if [[ -z "$uuidcustom" ]]; then
uuid=$(uuidgen)
else
uuid="$uuidcustom"
fi

if ! [[ "$uuid" =~ ^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ]]; then
err "UUID INVALIDO. Usa formato UUID correcto o deja vacío para automático."
pause
menu
fi

expire=$(date '+%F' -d "+$dias days")
email="$user@golden"

tmp=$(mktemp)

jq --arg p "$port" --arg id "$uuid" --arg email "$email" '
.inbounds |= map(
if (.port|tostring)==$p then
.settings.clients += [{
"id":$id,
"alterId":0,
"security":"auto",
"level":0,
"email":$email
}]
else . end
)
' "$CFG" > "$tmp" && mv "$tmp" "$CFG"

echo "$uuid|$user|$expire|$port|$hostcustom" >> "$REG"

restart_v2ray

bar
ok " USUARIO CREADO"
echo "Usuario: $user"
echo "UUID: $uuid"
echo "Puerto: $port"
echo "Expira: $expire"
echo "Host: $hostcustom"
echo -n "Path: "
jq -r --arg p "$port" '.inbounds[] | select((.port|tostring)==$p) | .streamSettings.wsSettings.path' "$CFG"
bar

generar_link "$uuid" "$user" "$port" "$hostcustom"

bar
pause
menu
}

generar_link(){
local uuid="$1"
local user="$2"
local port="$3"
local hostcustom="$4"

ip=$(vps_ip)

path=$(jq -r --arg p "$port" '
.inbounds[] |
select((.port|tostring)==$p) |
.streamSettings.wsSettings.path // "/vmess"
' "$CFG")

tls=$(jq -r --arg p "$port" '
.inbounds[] |
select((.port|tostring)==$p) |
.streamSettings.security // "none"
' "$CFG")

[[ "$tls" == "none" ]] && tls=""

json=$(jq -n \
--arg v "2" \
--arg ps "$user" \
--arg add "$ip" \
--arg port "$port" \
--arg id "$uuid" \
--arg aid "0" \
--arg scy "auto" \
--arg net "ws" \
--arg type "none" \
--arg host "$hostcustom" \
--arg path "$path" \
--arg tls "$tls" \
'{
"v":$v,
"ps":$ps,
"add":$add,
"port":$port,
"id":$id,
"aid":$aid,
"scy":$scy,
"net":$net,
"type":$type,
"host":$host,
"path":$path,
"tls":$tls
}')

echo "vmess://$(printf '%s' "$json" | base64 -w0)"
}

mostrar_usuarios(){
clear
bar
info " USUARIOS REGISTRADOS + VMESS"
bar

[[ ! -e "$REG" ]] && touch "$REG"

if [[ ! -s "$REG" ]]; then
err "NO HAY USUARIOS"
bar
pause
menu
fi

while IFS='|' read -r uuid user expire port hostcustom; do
echo -e "${VERDE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${VERDE}USUARIO :${RESET} $user"
echo -e "${VERDE}UUID    :${RESET} $uuid"
echo -e "${VERDE}PUERTO  :${RESET} $port"
echo -e "${VERDE}EXPIRA  :${RESET} $expire"
echo -e "${VERDE}HOST    :${RESET} $hostcustom"
echo ""
generar_link "$uuid" "$user" "$port" "$hostcustom"
echo ""
done < "$REG"

echo -e "${VERDE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
pause
menu
}

eliminar_usuario(){
clear
bar
info " ELIMINAR USUARIO"
bar

[[ ! -e "$REG" ]] && touch "$REG"

cat "$REG" | awk -F'|' '{print NR") "$2" | "$1" | Puerto:"$4" | Expira:"$3}'
bar

echo -ne "UUID: "
read -r uuid

line=$(grep "$uuid" "$REG")
port=$(echo "$line" | cut -d'|' -f4)

if [[ -z "$uuid" || -z "$port" ]]; then
err "UUID INVALIDO"
pause
menu
fi

tmp=$(mktemp)

jq --arg p "$port" --arg id "$uuid" '
.inbounds |= map(
if (.port|tostring)==$p then
.settings.clients |= map(select(.id != $id))
else . end
)
' "$CFG" > "$tmp" && mv "$tmp" "$CFG"

grep -v "$uuid" "$REG" > "$REG.tmp"
mv "$REG.tmp" "$REG"

restart_v2ray

bar
ok " USUARIO ELIMINADO"
bar
pause
menu
}

limpiar_expirados(){
clear
bar
info " LIMPIAR EXPIRADOS"
bar

[[ ! -e "$REG" ]] && touch "$REG"

now=$(date +%s)
tmpreg=$(mktemp)

while IFS='|' read -r uuid user expire port hostcustom; do
[[ -z "$uuid" ]] && continue

expsec=$(date +%s -d "$expire" 2>/dev/null)

if [[ -n "$expsec" && "$now" -gt "$expsec" ]]; then
tmp=$(mktemp)
jq --arg p "$port" --arg id "$uuid" '
.inbounds |= map(
if (.port|tostring)==$p then
.settings.clients |= map(select(.id != $id))
else . end
)
' "$CFG" > "$tmp" && mv "$tmp" "$CFG"
echo "Eliminado: $user"
else
echo "$uuid|$user|$expire|$port|$hostcustom" >> "$tmpreg"
fi
done < "$REG"

mv "$tmpreg" "$REG"
restart_v2ray

bar
ok " LIMPIEZA COMPLETADA"
bar
pause
menu
}

estado_panel(){
clear
bar
info " ESTADO GENERAL"
bar

if [[ -x "$BIN" ]]; then
ok "V2RAY INSTALADO"
$BIN version | head -1
else
err "V2RAY NO INSTALADO"
fi

if systemctl is-active --quiet v2ray; then
ok "SERVICIO ACTIVO"
else
err "SERVICIO INACTIVO"
fi

bar
info "PUERTOS CONFIGURADOS"
show_ports

bar
info "PUERTOS ESCUCHANDO"
ss -lntp | grep v2ray || err "NO HAY PUERTOS ESCUCHANDO"

bar
pause
menu
}

test_config(){
clear
bar
info " TEST CONFIG"
bar

if [[ -x "$BIN" && -e "$CFG" ]]; then
$BIN test -c "$CFG"
else
err "V2Ray no instalado o config no existe"
fi

bar
pause
menu
}

reparar_servicio(){
clear
bar
info " REPARANDO SERVICIO V2RAY"
bar

fix_service
fix_time

for p in $(jq -r '.inbounds[]?.port' "$CFG" 2>/dev/null); do
open_port "$p"
done

restart_v2ray

systemctl status v2ray --no-pager -l
bar
ss -lntp | grep v2ray || err "NO ESTA ESCUCHANDO"
bar
pause
menu
}

unistallv2_completo(){
clear
bar
info " DESINSTALANDO V2RAY COMPLETAMENTE"
bar

PORTS="$(jq -r '.inbounds[]?.port' "$CFG" 2>/dev/null)"

read -p " Confirmar desinstalación completa [s/n]: " resp
[[ "$resp" != "s" ]] && menu

systemctl stop v2ray >/dev/null 2>&1
sleep 1
systemctl disable v2ray >/dev/null 2>&1

pkill -9 -x v2ray >/dev/null 2>&1

for p in $PORTS 80 443; do
close_port "$p"
done

rm -f /etc/systemd/system/v2ray.service
rm -rf /etc/systemd/system/v2ray.service.d
systemctl daemon-reload >/dev/null 2>&1

rm -f /usr/local/bin/v2ray
rm -f /usr/bin/v2ray

rm -rf /etc/v2ray
rm -rf /usr/local/etc/v2ray
rm -rf /usr/local/share/v2ray
rm -rf /var/log/v2ray
rm -rf ~/.acme.sh

rm -rf /etc/newadm/v2ray
rm -f /etc/newadm/RegV2ray

crontab -r >/dev/null 2>&1
screen -wipe >/dev/null 2>&1

iptables-save > /etc/iptables/rules.v4 2>/dev/null
apt autoremove -y >/dev/null 2>&1

bar
ok " V2RAY ELIMINADO COMPLETAMENTE"
ok " PUERTOS DEL PANEL CERRADOS DEL FIREWALL"
bar

pause
menu
}

menu(){
clear

bar
echo -e "${AZUL} PANEL V2RAY PROFESIONAL ${ROJO}[ GOLDEN MX ]${RESET}"
bar

if [[ -x "$BIN" ]]; then
ok "V2RAY: INSTALADO"
else
err "V2RAY: NO INSTALADO"
fi

if systemctl is-active --quiet v2ray; then
ok "SERVICIO: ACTIVO"
else
err "SERVICIO: INACTIVO"
fi

bar
info "PUERTOS CONFIGURADOS"
show_ports

bar
echo -e "${VERDE}[1]${RESET} INSTALAR V2RAY"
echo -e "${VERDE}[2]${RESET} AGREGAR PUERTO"
echo -e "${VERDE}[3]${RESET} ELIMINAR PUERTO"
echo -e "${VERDE}[4]${RESET} ACTIVAR TLS EN PUERTO"
echo -e "${VERDE}[5]${RESET} DESACTIVAR TLS EN PUERTO"
bar
echo -e "${VERDE}[6]${RESET} CREAR USUARIO"
echo -e "${VERDE}[7]${RESET} ELIMINAR USUARIO"
echo -e "${VERDE}[8]${RESET} MOSTRAR USUARIOS + VMESS"
echo -e "${VERDE}[9]${RESET} LIMPIAR EXPIRADOS"
bar
echo -e "${VERDE}[10]${RESET} ESTADO GENERAL"
echo -e "${VERDE}[11]${RESET} TEST CONFIG"
echo -e "${VERDE}[12]${RESET} REPARAR SERVICIO"
echo -e "${VERDE}[13]${RESET} DESINSTALAR COMPLETO"
echo -e "${VERDE}[0]${RESET} SALIR"
bar

echo -ne "Seleccione: "
read -r op

case "$op" in
1) install_v2ray ;;
2) agregar_puerto ;;
3) eliminar_puerto ;;
4) activar_tls ;;
5) desactivar_tls ;;
6) crear_usuario ;;
7) eliminar_usuario ;;
8) mostrar_usuarios ;;
9) limpiar_expirados ;;
10) estado_panel ;;
11) test_config ;;
12) reparar_servicio ;;
13) unistallv2_completo ;;
0) exit ;;
*) menu ;;
esac
}

menu